@echo off
chcp 65001 >nul
setlocal
title Cap nhat Tien ich Tom tat CLS

set "TARGET_DIR=%~dp0"
echo ============================================
echo   CAP NHAT TIEN ICH TOM TAT CLS
echo ============================================
echo.
echo Dang tai ban moi nhat tu GitHub...

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ErrorActionPreference = 'Stop'; " ^
  "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; " ^
  "$target = $env:TARGET_DIR.TrimEnd('\'); " ^
  "$zip = Join-Path $env:TEMP ('cls-auto-' + (Get-Date).Ticks + '.zip'); " ^
  "$tmp = Join-Path $env:TEMP ('cls-auto-ext-' + (Get-Date).Ticks); " ^
  "$url = 'https://qtrungyb.github.io/ttcls/cls-auto.zip?t=' + (Get-Date).Ticks; " ^
  "function Parse-Ver([string]$s) { try { if ($s -match '^\d+(\.\d+){1,3}$') { return [version]$s } } catch {}; return [version]'0.0.0' }; " ^
  "try { " ^
  "  $oldVer = ''; " ^
  "  $oldMf = Join-Path $target 'manifest.json'; " ^
  "  if (Test-Path $oldMf) { $oldVer = [string](Get-Content $oldMf -Raw -Encoding UTF8 | ConvertFrom-Json).version }; " ^
  "  Invoke-WebRequest -Uri $url -OutFile $zip -UseBasicParsing; " ^
  "  Expand-Archive -Path $zip -DestinationPath $tmp -Force; " ^
  "  $mf = Get-ChildItem -Path $tmp -Filter 'manifest.json' -Recurse | Select-Object -First 1; " ^
  "  if (-not $mf) { throw 'Khong tim thay manifest.json trong file zip!' }; " ^
  "  $newVer = [string](Get-Content $mf.FullName -Raw -Encoding UTF8 | ConvertFrom-Json).version; " ^
  "  $vOld = Parse-Ver $oldVer; $vNew = Parse-Ver $newVer; " ^
  "  if ($oldVer -and ($vNew -lt $vOld)) { " ^
  "    Write-Host ''; " ^
  "    Write-Host ('[CANH BAO] Ban tren GitHub (v' + $newVer + ') CU HON ban tren may (v' + $oldVer + ')!') -ForegroundColor Yellow; " ^
  "    $ans = Read-Host 'De chong mat code, nhap chinh xac YES de ha cap (Enter de huy)'; " ^
  "    if ($ans -cne 'YES') { Write-Host ('[HUY] Da giu nguyen ban v' + $oldVer) -ForegroundColor Cyan; exit 2 }; " ^
  "  } elseif ($oldVer -and ($vNew -eq $vOld)) { " ^
  "    Write-Host ''; " ^
  "    Write-Host ('[THONG BAO] May da o ban moi nhat (v' + $newVer + ').') -ForegroundColor Cyan; " ^
  "    $ans = Read-Host 'Ban co muon cai de lai khong? (Y/N, Enter de huy)'; " ^
  "    if ($ans -notmatch '^[yY]$') { Write-Host '[HUY] Khong thay doi tep nao.' -ForegroundColor Cyan; exit 2 }; " ^
  "  }; " ^
  "  $backup = Join-Path $env:TEMP ('cls-auto-backup-' + (Get-Date -Format 'yyyyMMdd-HHmmss')); " ^
  "  New-Item -ItemType Directory -Path $backup -Force | Out-Null; " ^
  "  Get-ChildItem -Path $target | Copy-Item -Destination $backup -Recurse -Force; " ^
  "  Get-ChildItem -Path $mf.DirectoryName | Where-Object { $_.Name -ne 'Update.bat' } | Copy-Item -Destination $target -Recurse -Force; " ^
  "  Write-Host ''; " ^
  "  Write-Host ('[OK] Da cap nhat: v' + $(if ($oldVer) { $oldVer } else { '0' }) + ' -> v' + $newVer) -ForegroundColor Green; " ^
  "  Write-Host ('[BACKUP] Ban sao luu cu tai: ' + $backup) -ForegroundColor DarkGray; " ^
  "  $chrome = @($env:ProgramFiles, ${env:ProgramFiles(x86)}, $env:LOCALAPPDATA) | Where-Object { $_ } | ForEach-Object { Join-Path $_ 'Google\Chrome\Application\chrome.exe' } | Where-Object { Test-Path $_ } | Select-Object -First 1; " ^
  "  if ($chrome) { Start-Process $chrome 'chrome://extensions/' }; " ^
  "} catch { " ^
  "  Write-Host ('[LOI] ' + $_.Exception.Message) -ForegroundColor Red; " ^
  "  exit 1; " ^
  "} finally { " ^
  "  Remove-Item $zip, $tmp -Recurse -Force -ErrorAction SilentlyContinue; " ^
  "}"

if errorlevel 2 (
  echo.
  pause
  exit /b 0
)
if errorlevel 1 (
  echo.
  echo Cap nhat that bai. Kiem tra ket noi mang roi thu lai.
  pause
  exit /b 1
)

echo.
echo Buoc cuoi: Bam nut Tai lai (vong tron) tren the "Tom tat CLS" trong Chrome.
timeout /t 4 >nul