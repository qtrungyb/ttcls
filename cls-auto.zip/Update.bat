@echo off
chcp 65001 >nul
setlocal EnableExtensions
title Cap nhat Tien ich Tom tat CLS

set "BAT_FILE=%~f0"
set "TARGET_DIR=%~dp0"
if "%TARGET_DIR:~-1%"=="\" set "TARGET_DIR=%TARGET_DIR:~0,-1%"

echo ============================================
echo   CAP NHAT TIEN ICH TOM TAT CLS
echo ============================================
echo.

:: 1. Kiem tra quyen ghi trong thu muc cls-auto
set "TEST_FILE=%TARGET_DIR%\._cls_write_test_%RANDOM%.tmp"
(echo ok > "%TEST_FILE%") 2>nul
if not exist "%TEST_FILE%" (
  echo [LOI] Khong co quyen ghi vao thu muc:
  echo   %TARGET_DIR%
  echo.
  echo Cach khac phuc:
  echo   1. Chuot phai vao Update.bat -^> Run as administrator
  echo   2. Hoac chuyen thu muc cls-auto ra noi khac ^(VD: D:\cls-auto hoac Desktop\cls-auto^)
  echo.
  pause
  exit /b 1
)
del /f /q "%TEST_FILE%" >nul 2>&1

:: 2. Kiem tra PowerShell co bi chan khong
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "exit 0" >nul 2>&1
if "%ERRORLEVEL%"=="0" goto RUN_PS

echo [CANH BAO] May dang chan PowerShell ^(Access is denied^).
echo Dang tu dong chuyen sang che do tai bang curl + tar...
echo.
goto RUN_FALLBACK

:RUN_PS
echo Dang tai ban moi nhat tu GitHub...
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Invoke-Expression (([System.IO.File]::ReadAllText($env:BAT_FILE, [System.Text.Encoding]::UTF8) -split ('###'+'PS'+'###'), 2)[1])"
set "RC=%ERRORLEVEL%"
if "%RC%"=="2" (
  echo.
  pause
  exit /b 0
)
if not "%RC%"=="0" (
  echo.
  echo Cap nhat that bai ^(ma loi: %RC%^). Kiem tra ket noi mang hoac quyen thu muc roi thu lai.
  pause
  exit /b 1
)
echo.
echo Buoc cuoi: Bam nut Tai lai ^(vong tron^) tren the "Tom tat CLS" trong Chrome.
timeout /t 4 >nul
exit /b 0

:RUN_FALLBACK
where curl.exe >nul 2>&1
if errorlevel 1 (
  echo [LOI] May vua chan PowerShell vua khong co curl.exe.
  echo Vui long tai thu cong tai: https://qtrungyb.github.io/ttcls/cls-auto.zip
  pause
  exit /b 1
)
where tar.exe >nul 2>&1
if errorlevel 1 (
  echo [LOI] May vua chan PowerShell vua khong co tar.exe.
  echo Vui long tai thu cong tai: https://qtrungyb.github.io/ttcls/cls-auto.zip
  pause
  exit /b 1
)

set "ZIP_TMP=%TEMP%\cls-auto-%RANDOM%%RANDOM%.zip"
set "EXT_TMP=%TEMP%\cls-auto-ext-%RANDOM%%RANDOM%"
set "BAK_TMP=%TEMP%\cls-auto-backup-%RANDOM%"

echo Dang tai cls-auto.zip tu GitHub...
curl.exe -fsSL "https://qtrungyb.github.io/ttcls/cls-auto.zip?t=%RANDOM%%RANDOM%" -o "%ZIP_TMP%"
if errorlevel 1 (
  echo [LOI] Khong tai duoc file tu GitHub. Kiem tra ket noi mang!
  del /f /q "%ZIP_TMP%" >nul 2>&1
  pause
  exit /b 1
)

mkdir "%EXT_TMP%" >nul 2>&1
tar.exe -xf "%ZIP_TMP%" -C "%EXT_TMP%"
if errorlevel 1 (
  echo [LOI] Khong giai nen duoc file zip!
  del /f /q "%ZIP_TMP%" >nul 2>&1
  rmdir /s /q "%EXT_TMP%" >nul 2>&1
  pause
  exit /b 1
)

set "SRC_DIR="
if exist "%EXT_TMP%\manifest.json" set "SRC_DIR=%EXT_TMP%"
if "%SRC_DIR%"=="" (
  for /d %%D in ("%EXT_TMP%\*") do (
    if exist "%%~fD\manifest.json" set "SRC_DIR=%%~fD"
  )
)

if "%SRC_DIR%"=="" (
  echo [LOI] Khong tim thay manifest.json trong goi tai ve!
  del /f /q "%ZIP_TMP%" >nul 2>&1
  rmdir /s /q "%EXT_TMP%" >nul 2>&1
  pause
  exit /b 1
)

:: Sao luu ban cu
mkdir "%BAK_TMP%" >nul 2>&1
xcopy "%TARGET_DIR%\*" "%BAK_TMP%" /E /Y /I /Q >nul 2>&1

:: Ghi de ban moi (tru Update.bat dang chay)
del /f /q "%SRC_DIR%\Update.bat" >nul 2>&1
xcopy "%SRC_DIR%\*" "%TARGET_DIR%" /E /Y /I /Q >nul
if errorlevel 1 (
  echo [LOI] Khong ghi de duoc tep vao %TARGET_DIR% ^(co tep dang bi khoa hoac thieu quyen^).
  echo Ban sao luu cu nam tai: %BAK_TMP%
  del /f /q "%ZIP_TMP%" >nul 2>&1
  rmdir /s /q "%EXT_TMP%" >nul 2>&1
  pause
  exit /b 1
)

del /f /q "%ZIP_TMP%" >nul 2>&1
rmdir /s /q "%EXT_TMP%" >nul 2>&1

echo.
echo [OK] Da cap nhat xong bang che do du phong!
echo [BACKUP] Ban sao luu cu tai: %BAK_TMP%
echo.
echo Buoc cuoi: Mo chrome://extensions/ va bam nut Tai lai ^(vong tron^) tren the "Tom tat CLS".
start "" chrome.exe "chrome://extensions/" >nul 2>&1
timeout /t 4 >nul
exit /b 0

###PS###
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$target = $env:TARGET_DIR.TrimEnd('\')
$zip    = Join-Path $env:TEMP ('cls-auto-' + (Get-Date).Ticks + '.zip')
$tmp    = Join-Path $env:TEMP ('cls-auto-ext-' + (Get-Date).Ticks)
$url    = 'https://qtrungyb.github.io/ttcls/cls-auto.zip?t=' + (Get-Date).Ticks

function Parse-Ver([string]$s) {
  try {
    if ($s -match '^\d+(\.\d+){1,3}$') { return [version]$s }
  } catch {}
  return [version]'0.0.0'
}

try {
  $oldVer = ''
  $oldMf = Join-Path $target 'manifest.json'
  if (Test-Path -LiteralPath $oldMf) {
    $oldVer = [string](Get-Content -LiteralPath $oldMf -Raw -Encoding UTF8 | ConvertFrom-Json).version
  }

  Invoke-WebRequest -Uri $url -OutFile $zip -UseBasicParsing
  Expand-Archive -LiteralPath $zip -DestinationPath $tmp -Force

  $mf = Get-ChildItem -LiteralPath $tmp -Filter 'manifest.json' -Recurse | Select-Object -First 1
  if (-not $mf) { throw 'Khong tim thay manifest.json trong file zip!' }

  $newVer = [string](Get-Content -LiteralPath $mf.FullName -Raw -Encoding UTF8 | ConvertFrom-Json).version
  $vOld = Parse-Ver $oldVer
  $vNew = Parse-Ver $newVer

  if ($oldVer -and ($vNew -lt $vOld)) {
    Write-Host ''
    Write-Host ("[CANH BAO] Ban tren GitHub (v$newVer) CU HON ban tren may (v$oldVer)!") -ForegroundColor Yellow
    $ans = Read-Host 'De chong mat code, nhap chinh xac YES de ha cap (Enter de huy)'
    if ($ans -cne 'YES') {
      Write-Host ("[HUY] Da giu nguyen ban v$oldVer") -ForegroundColor Cyan
      exit 2
    }
  } elseif ($oldVer -and ($vNew -eq $vOld)) {
    Write-Host ''
    Write-Host ("[THONG BAO] May da o ban moi nhat (v$newVer).") -ForegroundColor Cyan
    $ans = Read-Host 'Ban co muon cai de lai khong? (Y/N, Enter de huy)'
    if ($ans -notmatch '^[yY]$') {
      Write-Host '[HUY] Khong thay doi tep nao.' -ForegroundColor Cyan
      exit 2
    }
  }

  $backup = Join-Path $env:TEMP ('cls-auto-backup-' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
  New-Item -ItemType Directory -Path $backup -Force | Out-Null
  Get-ChildItem -LiteralPath $target | Copy-Item -Destination $backup -Recurse -Force
  Get-ChildItem -LiteralPath $mf.DirectoryName | Where-Object { $_.Name -ne 'Update.bat' } | Copy-Item -Destination $target -Recurse -Force

  Write-Host ''
  $fromVer = if ($oldVer) { $oldVer } else { '0' }
  Write-Host ("[OK] Da cap nhat: v$fromVer -> v$newVer") -ForegroundColor Green
  Write-Host ("[BACKUP] Ban sao luu cu tai: $backup") -ForegroundColor DarkGray

  $chrome = @($env:ProgramFiles, ${env:ProgramFiles(x86)}, $env:LOCALAPPDATA) |
    Where-Object { $_ } |
    ForEach-Object { Join-Path $_ 'Google\Chrome\Application\chrome.exe' } |
    Where-Object { Test-Path -LiteralPath $_ } |
    Select-Object -First 1
  if ($chrome) { Start-Process $chrome 'chrome://extensions/' }
} catch {
  Write-Host ('[LOI] ' + $_.Exception.Message) -ForegroundColor Red
  exit 1
} finally {
  Remove-Item -LiteralPath $zip, $tmp -Recurse -Force -ErrorAction SilentlyContinue
}