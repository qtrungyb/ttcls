/* =========================================================
   BRIDGE — Cầu nối giữa qtrungyb.github.io (kể cả PiP)
            và Chrome Extension (v1.5.0)
   ========================================================= */
(function() {
  const SHARED_SETTINGS_KEY = 'cls_shared_settings';
  const MERGE_SESSION_KEY = 'cls_merge_session_v1';

  document.documentElement.dataset.clsExtReady = '1';
  try {
    document.documentElement.dataset.clsExtVersion = chrome.runtime.getManifest().version || '';
  } catch {}

  function parseDetail(ev) {
    try {
      return typeof ev.detail === 'string' ? JSON.parse(ev.detail) : ev.detail;
    } catch {
      return null;
    }
  }

  function pushSettingsToPage(settings) {
    if (!settings || typeof settings !== 'object') return;
    document.dispatchEvent(
      new CustomEvent('cls-settings-sync', { detail: JSON.stringify(settings) })
    );
  }

  function pushMergeToPage(session) {
    if (!session || typeof session !== 'object') return;
    document.dispatchEvent(
      new CustomEvent('cls-merge-sync', { detail: JSON.stringify(session) })
    );
  }

  function pullAndDispatchSettings() {
    try {
      chrome.storage.local.get(SHARED_SETTINGS_KEY, (data) => {
        if (chrome.runtime.lastError) return;
        if (data && data[SHARED_SETTINGS_KEY]) {
          pushSettingsToPage(data[SHARED_SETTINGS_KEY]);
        }
      });
    } catch {}
  }

  function pullAndDispatchMerge() {
    try {
      chrome.storage.local.get(MERGE_SESSION_KEY, (data) => {
        if (chrome.runtime.lastError) return;
        if (data && data[MERGE_SESSION_KEY]) {
          pushMergeToPage(data[MERGE_SESSION_KEY]);
        }
      });
    } catch {}
  }

  pullAndDispatchSettings();
  pullAndDispatchMerge();

  document.addEventListener('cls-settings-request', pullAndDispatchSettings);
  document.addEventListener('cls-merge-request', pullAndDispatchMerge);

  document.addEventListener('cls-settings-save', (event) => {
    const incoming = parseDetail(event);
    if (!incoming || typeof incoming !== 'object') return;
    try {
      chrome.storage.local.get(SHARED_SETTINGS_KEY, (data) => {
        if (chrome.runtime.lastError) return;
        const merged = { ...(data?.[SHARED_SETTINGS_KEY] || {}), ...incoming };
        chrome.storage.local.set({ [SHARED_SETTINGS_KEY]: merged }, () => {
          void chrome.runtime.lastError;
        });
      });
    } catch {}
  });

  document.addEventListener('cls-merge-save', (event) => {
    const incoming = parseDetail(event);
    if (!incoming || typeof incoming !== 'object') return;
    try {
      chrome.storage.local.set({ [MERGE_SESSION_KEY]: incoming }, () => {
        void chrome.runtime.lastError;
      });
    } catch {}
  });

  try {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== 'local') return;
      if (changes[SHARED_SETTINGS_KEY]?.newValue) {
        pushSettingsToPage(changes[SHARED_SETTINGS_KEY].newValue);
      }
      if (changes[MERGE_SESSION_KEY]?.newValue) {
        pushMergeToPage(changes[MERGE_SESSION_KEY].newValue);
      }
    });
  } catch {}

  // Kênh quét HIS
  document.addEventListener('cls-scan-request', (event) => {
    const req = parseDetail(event);
    if (!req || !req.requestId) return;

    const requestId = req.requestId;
    const mode = req.mode || 'manual';

    document.dispatchEvent(
      new CustomEvent('cls-scan-ack', { detail: JSON.stringify({ requestId }) })
    );

    const reply = (payload) => {
      document.dispatchEvent(
        new CustomEvent('cls-scan-response', {
          detail: JSON.stringify({ requestId, ...payload })
        })
      );
    };

    try {
      chrome.runtime.sendMessage({ type: 'CLS_SCAN_HIS', mode }, (response) => {
        if (chrome.runtime.lastError) {
          reply({
            ok: false,
            error: 'Lỗi kết nối Extension: ' + chrome.runtime.lastError.message
          });
          return;
        }
        reply(response || { ok: false, error: 'Background không trả về dữ liệu.' });
      });
    } catch {
      reply({
        ok: false,
        error: 'Extension vừa tải lại — hãy F5 trang Tóm tắt CLS rồi thử lại.'
      });
    }
  });

  // Kênh copy dự phòng
  document.addEventListener('cls-copy-request', (event) => {
    const req = parseDetail(event);
    if (!req || !req.text) return;
    try {
      chrome.runtime.sendMessage({ type: 'CLS_COPY_TEXT', text: req.text }, () => {
        void chrome.runtime.lastError;
      });
    } catch {}
  });

  // Kênh chèn trực tiếp vào ô văn bản đang trỏ trên HIS
  document.addEventListener('cls-insert-request', (event) => {
    const req = parseDetail(event);
    if (!req || !req.text) return;
    try {
      chrome.runtime.sendMessage({ type: 'CLS_INSERT_HIS', text: req.text }, (response) => {
        if (!req.requestId) return;
        const payload = chrome.runtime.lastError
          ? { ok: false, error: chrome.runtime.lastError.message }
          : (response || { ok: false });
        document.dispatchEvent(
          new CustomEvent('cls-insert-response', {
            detail: JSON.stringify({ requestId: req.requestId, ...payload })
          })
        );
      });
    } catch {}
  });
})();