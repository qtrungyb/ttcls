/* =========================================================
   SHARED CLS — Logic xử lý dùng chung cho Background & Popup
   ========================================================= */
(function(root) {
  const CLS_WEB_URL = 'https://qtrungyb.github.io/ttcls/';
  const ABBR_ENDPOINT = 'https://tomtatcls-default-rtdb.asia-southeast1.firebasedatabase.app/abbreviations.json';
  const SHARED_SETTINGS_KEY = 'cls_shared_settings';
  const MERGE_SESSION_KEY = 'cls_merge_session_v1';
  const ABBR_CACHE_KEY = 'cls_abbr_cache';

  const MERGE_PRIORITY = {
    CTM: 1, SHM: 2, ĐGĐ: 3, XN: 4, MD: 5, ĐM: 6, KM: 7, VS: 8, TPTNT: 9,
    CĐHA: 10, TDCN: 11
  };
  const DEFAULT_PRIORITY = 9;

  const SPECIAL_NAMES = [
    'Số lượng hồng cầu', 'Huyết sắc tố', 'Hematocrit',
    'Số lượng tiểu cầu', 'Số lượng bạch cầu', 'Tỷ lệ bạch cầu GR'
  ];

  const DEFAULT_ABBR = {
    'Số lượng hồng cầu': 'HC',
    'Huyết sắc tố': 'Hb',
    'Hematocrit': 'HTC',
    'Số lượng tiểu cầu': 'TC',
    'Số lượng bạch cầu': 'BC',
    'Tỷ lệ bạch cầu GR': 'N%'
  };

  const SEP_INNER = { T3: ': ', T4: ': ', TSH: ': ', Tg: ': ' };
  const VALID_KEEP = ['inr', 'bệnh/ chứng r', 'bệnh/chứng r', 'alt', 'ast'];

  const RANGE_RE = /(\d+[.,]?\d*)\s*[-–]\s*(\d+[.,]?\d*)/;
  const LE_RE = /(<=|≤)\s*(\d+[.,]?\d*)/;
  const L_RE = /<\s*(\d+[.,]?\d*)/;
  const GE_RE = /(>=|≥)\s*(\d+[.,]?\d*)/;
  const G_RE = />\s*(\d+[.,]?\d*)/;

  const NAME_PREFIX_RE = /^\([^)]+\)\s*(.*)/;
  const INNER_PAREN_RE = /\s*\(([^)]+)\)/g;
  const GENERIC_IMG_RE = /^(cđha|tdcn|siêu âm|chụp x-quang|x-quang|điện tim|nội soi)$/i;

  function escapeHtml(str) {
    return str ? String(str).replace(/[&<>]/g, (m) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[m])) : '';
  }

  function escapeAttr(str) {
    return str ? String(str).replace(/[&<>"']/g, (m) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[m])) : '';
  }

  function parseNumber(str) {
    const m = str && String(str).replace(/,/g, '.').replace(/\s+/g, '').match(/-?\d+(?:\.\d+)?/);
    return m ? parseFloat(m[0]) : NaN;
  }

  function cleanName(raw) {
    if (!raw) return '';
    const str = raw.trim().replace(/^["']|["']$/g, '');
    const m = str.match(NAME_PREFIX_RE);
    let name = m ? m[1].trim() : str;
    name = name.replace(INNER_PAREN_RE, (match, inner) =>
      VALID_KEEP.includes(inner.trim().toLowerCase()) ? match : ''
    );
    return name.trim();
  }

  function getStatus(valStr, rangeStr) {
    const val = parseNumber(valStr);
    if (isNaN(val) || !rangeStr) return 'unknown';
    let m;
    if ((m = rangeStr.match(RANGE_RE))) return (val < parseNumber(m[1]) || val > parseNumber(m[2])) ? 'abnormal' : 'normal';
    if ((m = rangeStr.match(LE_RE)))    return val <= parseNumber(m[2]) ? 'normal' : 'abnormal';
    if ((m = rangeStr.match(L_RE)))     return val <  parseNumber(m[1]) ? 'normal' : 'abnormal';
    if ((m = rangeStr.match(GE_RE)))    return val >= parseNumber(m[2]) ? 'normal' : 'abnormal';
    if ((m = rangeStr.match(G_RE)))     return val >  parseNumber(m[1]) ? 'normal' : 'abnormal';
    return 'unknown';
  }

  function parseInputToRows(rawText) {
    const lines = String(rawText || '').split(/\r?\n/);
    const rows = [];
    for (const line of lines) {
      if (!line.trim()) continue;
      const cols = line.split('\t').map((c) => c.trim()).filter(Boolean);
      if (cols.length >= 3 && /^\d+$/.test(cols[0])) {
        const refRange = cols[3] || '';
        rows.push({
          stt: cols[0],
          cleanName: cleanName(cols[1]),
          value: cols[2],
          refRange,
          unit: cols[4] || '',
          _status: getStatus(cols[2], refRange)
        });
      }
    }
    return rows;
  }

  function getRowOverlapRatio(rowsA, rowsB) {
    if (!rowsA?.length || !rowsB?.length) return 0;
    const setA = new Set(rowsA.map((r) => r.cleanName.toLowerCase()));
    const setB = new Set(rowsB.map((r) => r.cleanName.toLowerCase()));
    let common = 0;
    for (const n of setA) if (setB.has(n)) common++;
    return common / Math.min(setA.size, setB.size);
  }

  function getShortServiceLabel(serviceName, rows) {
    if ((rows || []).length > 0 && rows.every((r) => r.refRange === 'CĐHA' || r.refRange === 'TDCN')) {
      return rows[0].refRange;
    }
    const names = (rows || []).map((r) => r.cleanName.toLowerCase()).join(' | ');
    const svc = String(serviceName || '').toLowerCase();

    if (svc.includes('nước tiểu') || svc.includes('tptnt') || names.includes('tỷ trọng') || names.includes('urobilinogen') || names.includes('nitrit') || names.includes('cetonic') || names.includes('keton')) return 'TPTNT';
    if (names.includes('huyết sắc tố') || names.includes('hematocrit') || names.includes('số lượng hồng cầu') || names.includes('số lượng tiểu cầu') || names.includes('số lượng bạch cầu') || names.includes('thể tích trung bình hồng cầu') || /\bmcv\b|\bmch\b|\bmchc\b/.test(names)) return 'CTM';
    if (/\binr\b|\baptt\b/.test(names) || names.includes('fibrinogen') || names.includes('prothrombin') || names.includes('d-dimer')) return 'ĐM';
    if (/\bpco2\b|\bpo2\b|\bhco3\b/.test(names)) return 'KM';
    if (svc.includes('miễn dịch') || names.includes('ferritin') || names.includes('procalcitonin') || names.includes('troponin') || names.includes('pro-bnp') || names.includes('hbsag') || names.includes('anti-hbs') || names.includes('anti-hcv') || names.includes('dengue') || names.includes('beta-hcg') || names.includes('cortisol') || names.includes('insulin') || names.includes('vitamin d') || names.includes('vitamin b12') || names.includes('acid folic') || /\b(tsh|ft3|ft4|afp|cea|psa|hiv|ns1|ige|igg|igm|aso|anti-ccp)\b/.test(names)) return 'MD';
    if (names.includes('sgpt') || names.includes('sgot') || /\b(alt|ast|ggt|crp|hdl|ldl|ldh|ck-mb|alp|tibc|nh3)\b/.test(names) || names.includes('creatinin') || names.includes('urê') || names.includes('urea') || names.includes('glucose') || names.includes('cholesterol') || names.includes('triglycerid') || names.includes('acid uric') || names.includes('hba1c') || names.includes('amylase') || names.includes('lipase') || names.includes('albumin') || names.includes('protein') || names.includes('bilirubin') || names.includes('sắt huyết thanh') || names.includes('định lượng sắt') || names.includes('transferrin') || names.includes('canxi') || names.includes('calcium') || names.includes('magie') || names.includes('phospho') || names.includes('lactat')) return 'SHM';
    if (svc.includes('điện giải') || names.includes('natri') || names.includes('kali') || names.includes('clo') || names.includes('na+') || names.includes('k+')) return 'ĐGĐ';
    if (svc.includes('huyết học') || svc.includes('công thức máu') || svc.includes('tế bào máu')) return 'CTM';
    if (svc.includes('hóa sinh') || svc.includes('sinh hóa')) return 'SHM';
    if (svc.includes('đông máu')) return 'ĐM';
    if (svc.includes('vi sinh')) return 'VS';
    if (svc.includes('khí máu')) return 'KM';
    if (serviceName) return serviceName.replace(/^xét nghiệm\s+/i, '').trim().slice(0, 18);
    return 'XN';
  }

  function makeSheetKey(label, resultTime, rows) {
    const grp = String(label || 'XN').toLowerCase().trim();
    const time = String(resultTime || '').trim();
    const sig = (rows || []).slice(0, 3).map((r) => r.cleanName.toLowerCase()).join('|');
    return [grp, time, sig].filter(Boolean).join('__');
  }

  function sortSheets(sheets) {
    return sheets.sort(
      (a, b) => (MERGE_PRIORITY[a.label] || DEFAULT_PRIORITY) - (MERGE_PRIORITY[b.label] || DEFAULT_PRIORITY)
    );
  }

  function isGenericImgName(name) {
    return GENERIC_IMG_RE.test(String(name || '').trim());
  }

  function findMatchingSheetIndex(sheets, { rawText, label, resultTime, rows }) {
    let idx = sheets.findIndex((s) => s.rawText === rawText);
    if (idx !== -1) return idx;

    return sheets.findIndex((s) => {
      if (s.label !== label) return false;
      if (s.resultTime && resultTime && s.resultTime !== resultTime) return false;
      const sRows = Array.isArray(s.rows) ? s.rows : parseInputToRows(s.rawText);

      if (label === 'CĐHA' || label === 'TDCN') {
        const oldName = sRows[0]?.cleanName || '';
        const newName = rows[0]?.cleanName || '';
        if (!oldName || !newName || isGenericImgName(newName)) return false;
        return oldName.toLowerCase() === newName.toLowerCase();
      }
      return getRowOverlapRatio(sRows, rows) >= 0.5;
    });
  }

  function filterRows(rows, filterName) {
    if (filterName === 'abnormal') return rows.filter((r) => r._status === 'abnormal');
    if (filterName === 'all') return rows;
    const main = rows.filter((r) => SPECIAL_NAMES.includes(r.cleanName));
    return main.length ? main : rows;
  }

  function formatRows(rows, settings, abbrMap) {
    const showUnit = Boolean(settings?.showUnit);
    const showAbbr = settings?.showAbbr !== false;
    const copyFormat = settings?.copyFormat || 'comma';
    const isAllConclusion = rows.length > 0 && rows.every((r) => r.refRange === 'CĐHA' || r.refRange === 'TDCN');

    const htmlParts = [];
    const plainParts = [];
    for (const r of rows) {
      if (!r.value || r.value.trim().toLowerCase() === '- neg') continue;
      const isConclusion = r.refRange === 'CĐHA' || r.refRange === 'TDCN';
      const isAbbr = showAbbr && abbrMap && abbrMap[r.cleanName];
      const name = isAbbr ? abbrMap[r.cleanName] : r.cleanName;
      const sep = isConclusion ? ': ' : (SEP_INNER[name] || ' ');
      const unit = (!isConclusion && showUnit && r.unit) ? ' ' + r.unit : '';

      const ev = escapeHtml(r.value);
      const hv = r._status === 'abnormal' ? `<span class="abnormal-value">${ev}</span>` : ev;
      const nHtml = isAbbr
        ? `<span class="abbr-tip" title="${escapeAttr(r.cleanName)}">${escapeHtml(name)}</span>`
        : escapeHtml(name);

      htmlParts.push(`${nHtml}${sep}${hv}${escapeHtml(unit)}`);
      plainParts.push(`${name}${sep}${r.value}${unit}`);
    }

    const sepHtml  = copyFormat === 'newline' ? '<br>' : (isAllConclusion || copyFormat === 'semicolon' ? '; ' : ', ');
    const sepPlain = copyFormat === 'newline' ? '\n'   : (isAllConclusion || copyFormat === 'semicolon' ? '; ' : ', ');
    return {
      html: htmlParts.join(sepHtml),
      plain: plainParts.join(sepPlain),
      count: plainParts.length
    };
  }

  function formatMergedSheets(sheets, settings, abbrMap) {
    const filterName = settings?.mergeFilter || 'main';
    const copyFormat = settings?.copyFormat || 'comma';
    const outputGroups = [];
    let total = 0;
    let abnTotal = 0;

    for (const sheet of sheets) {
      const rows = Array.isArray(sheet.rows) ? sheet.rows : parseInputToRows(sheet.rawText);
      total += rows.length;
      abnTotal += rows.filter((r) => r._status === 'abnormal').length;

      const filtered = filterRows(rows, filterName);
      if (!filtered.length) continue;

      const target = outputGroups.find(
        (g) => g.label === sheet.label && getRowOverlapRatio(g.rows, filtered) === 0
      );
      if (target) target.rows.push(...filtered);
      else outputGroups.push({ label: sheet.label, rows: [...filtered] });
    }

    const htmlBlocks = [];
    const plainBlocks = [];
    for (const g of outputGroups) {
      if (g.label === 'CĐHA' || g.label === 'TDCN') {
        for (const r of g.rows) {
          const { html, plain } = formatRows([r], settings, abbrMap);
          if (!plain) continue;
          const colonPos = html.indexOf(': ');
          const formattedHtml = colonPos !== -1
            ? `<span class="grp-label">- ${html.slice(0, colonPos + 1)}</span>${html.slice(colonPos + 1)}`
            : `<span class="grp-label">-</span> ${html}`;
          htmlBlocks.push(formattedHtml);
          plainBlocks.push(`- ${plain}`);
        }
        continue;
      }

      const { html, plain } = formatRows(g.rows, settings, abbrMap);
      if (!plain) continue;
      if (copyFormat === 'newline') {
        htmlBlocks.push(`<span class="grp-label">- ${escapeHtml(g.label)}:</span><br>${html}`);
        plainBlocks.push(`- ${g.label}:\n${plain}`);
      } else {
        htmlBlocks.push(`<span class="grp-label">- ${escapeHtml(g.label)}:</span> ${html}`);
        plainBlocks.push(`- ${g.label}: ${plain}`);
      }
    }

    return {
      total,
      abnTotal,
      html: htmlBlocks.join('<br>'),
      plain: plainBlocks.join('\n')
    };
  }

  root.CLSShared = {
    CLS_WEB_URL,
    ABBR_ENDPOINT,
    SHARED_SETTINGS_KEY,
    MERGE_SESSION_KEY,
    ABBR_CACHE_KEY,
    MERGE_PRIORITY,
    DEFAULT_PRIORITY,
    SPECIAL_NAMES,
    DEFAULT_ABBR,
    SEP_INNER,
    VALID_KEEP,
    escapeHtml,
    escapeAttr,
    parseNumber,
    cleanName,
    getStatus,
    parseInputToRows,
    getRowOverlapRatio,
    getShortServiceLabel,
    makeSheetKey,
    sortSheets,
    isGenericImgName,
    findMatchingSheetIndex,
    filterRows,
    formatRows,
    formatMergedSheets
  };
})(typeof globalThis !== 'undefined' ? globalThis : self);