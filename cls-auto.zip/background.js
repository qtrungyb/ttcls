/* =========================================================
   BACKGROUND — Quét CLS + Gộp ngầm HIS + Alt+Q + Chèn HIS
   ========================================================= */
importScripts('shared_cls.js');

const CLS = globalThis.CLSShared;
const {
  ABBR_ENDPOINT,
  SHARED_SETTINGS_KEY,
  MERGE_SESSION_KEY,
  ABBR_CACHE_KEY,
  CAPTURE_PAUSED_KEY,
  DEFAULT_ABBR
} = CLS;

const HIS_HOST_ALLOWLIST = ['172.16.0.7'];

function isScannableUrl(url) {
  if (typeof url !== 'string') return false;
  if (!/^https?:\/\//i.test(url)) return false;
  if (/^https?:\/\/qtrungyb\.github\.io\b/i.test(url)) return false;
  return true;
}

function isHisUrl(url) {
  if (!isScannableUrl(url)) return false;
  try {
    const u = new URL(url);
    return HIS_HOST_ALLOWLIST.includes(u.hostname.toLowerCase());
  } catch {
    return false;
  }
}
function withTimeout(promise, ms, msg) {
  return Promise.race([
    promise,
    new Promise((_, reject) => setTimeout(() => reject(new Error(msg)), ms))
  ]);
}

async function ensureDefaultSettings() {
  try {
    const data = await chrome.storage.local.get(SHARED_SETTINGS_KEY);
    const cur = data?.[SHARED_SETTINGS_KEY] || {};
    if (
      typeof cur.mergeEnabled !== 'boolean' ||
      !cur.mergeFilter ||
      typeof cur.darkMode !== 'boolean' ||
      typeof cur.compactUrine !== 'boolean'
    ) {
      await chrome.storage.local.set({
        [SHARED_SETTINGS_KEY]: {
          showUnit: false,
          showAbbr: true,
          compactUrine: true,
          copyFormat: 'comma',
          darkMode: true,
          themeMode: 'dark',
          ...cur,
          mergeEnabled: typeof cur.mergeEnabled === 'boolean' ? cur.mergeEnabled : true,
          mergeFilter: cur.mergeFilter || 'main',
          compactUrine: typeof cur.compactUrine === 'boolean' ? cur.compactUrine : true,
          darkMode: typeof cur.darkMode === 'boolean' ? cur.darkMode : true,
          themeMode: cur.themeMode || 'dark'
        }
      });
    }
  } catch {}
}

async function refreshMergeBadge() {
  try {
    const data = await chrome.storage.local.get([SHARED_SETTINGS_KEY, MERGE_SESSION_KEY, CAPTURE_PAUSED_KEY]);
    const mergeOn = data?.[SHARED_SETTINGS_KEY]?.mergeEnabled !== false;
    const paused = Boolean(data?.[CAPTURE_PAUSED_KEY]);
    const count = Array.isArray(data?.[MERGE_SESSION_KEY]?.sheets)
      ? data[MERGE_SESSION_KEY].sheets.length
      : 0;

    if (mergeOn && paused) {
      await chrome.action.setBadgeText({ text: '||' });
      await chrome.action.setBadgeBackgroundColor({ color: '#d97706' });
    } else if (mergeOn && count > 0) {
      await chrome.action.setBadgeText({ text: String(count) });
      await chrome.action.setBadgeBackgroundColor({ color: '#0d9488' });
    } else if (mergeOn) {
      await chrome.action.setBadgeText({ text: '+' });
      await chrome.action.setBadgeBackgroundColor({ color: '#0d9488' });
    } else {
      await chrome.action.setBadgeText({ text: '' });
    }
  } catch {}
}

async function ensureWatcherInOpenTabs() {
  try {
    const tabs = await chrome.tabs.query({});
    for (const t of tabs) {
      if (!t.id || t.discarded || !isHisUrl(t.url)) continue;
      chrome.scripting.executeScript({
        target: { tabId: t.id, allFrames: true },
        files: ['his_watcher.js']
      }).catch(() => {});
    }
  } catch {}
}

chrome.runtime.onInstalled.addListener(() => {
  ensureDefaultSettings().then(() => {
    refreshMergeBadge();
    ensureWatcherInOpenTabs();
  });
});
chrome.runtime.onStartup.addListener(() => {
  ensureDefaultSettings().then(() => {
    refreshMergeBadge();
    ensureWatcherInOpenTabs();
  });
});
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local') return;
  if (changes[SHARED_SETTINGS_KEY] || changes[MERGE_SESSION_KEY] || changes[CAPTURE_PAUSED_KEY]) {
    refreshMergeBadge();
  }
  if (
    changes[SHARED_SETTINGS_KEY]?.newValue?.mergeEnabled !== false &&
    changes[SHARED_SETTINGS_KEY]?.oldValue?.mergeEnabled === false
  ) {
    ensureWatcherInOpenTabs();
  }
});
ensureDefaultSettings().then(() => {
  refreshMergeBadge();
});

async function findTargetTabForScan(senderTabId) {
  try {
    const win = await chrome.windows.getLastFocused({ populate: true, windowTypes: ['normal'] });
    const activeHis = win?.tabs?.find(
      (t) => t.active && !t.discarded && t.id !== senderTabId && isHisUrl(t.url)
    );
    if (activeHis) return activeHis;

    const anyWinHis = win?.tabs
      ?.filter((t) => t.id && !t.discarded && t.id !== senderTabId && isHisUrl(t.url))
      .sort((a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0));
    if (anyWinHis?.length) return anyWinHis[0];
  } catch {}

  try {
    const allTabs = await chrome.tabs.query({});
    const validHis = allTabs
      .filter((t) => t.id && !t.discarded && t.id !== senderTabId && isHisUrl(t.url))
      .sort((a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0));
    if (validHis.length) return validHis[0];

    const activeTabs = await chrome.tabs.query({ active: true });
    const validActive = activeTabs
      .filter((t) => t.id && !t.discarded && t.id !== senderTabId && isScannableUrl(t.url))
      .sort((a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0));
    if (validActive.length) return validActive[0];

    const validAll = allTabs
      .filter((t) => t.id && !t.discarded && t.id !== senderTabId && isScannableUrl(t.url))
      .sort((a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0));
    if (validAll.length) return validAll[0];
  } catch {}

  return null;
}

function extractDataFromHIS() {
  const clean = (s) => String(s || '').replace(/\s+/g, ' ').trim();

  function isVisible(node) {
    if (!node || !node.getBoundingClientRect) return false;
    const style = window.getComputedStyle(node);
    if (style.display === 'none' || style.visibility === 'hidden' || parseFloat(style.opacity) === 0) {
      return false;
    }
    const rect = node.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  }

  function getCellText(cell) {
    if (!cell) return '';
    const field = cell.querySelector('input:not([type="checkbox"]):not([type="radio"]), textarea, select');
    if (field) {
      if (field.tagName === 'SELECT') {
        return clean(field.options[field.selectedIndex]?.text || '');
      }
      return clean(field.value);
    }
    return clean(cell.innerText || cell.textContent);
  }

  function extractHISMetadata() {
    let patientName = '';
    let patientId = '';

    const headerNodes = Array.from(document.querySelectorAll('div, span, header, h1, h2, h3, h4, p, td'));
    let bestHeaderText = '';
    for (const node of headerNodes) {
      if (!isVisible(node)) continue;
      const txt = clean(node.innerText || node.textContent);
      if (txt.length < 15 || txt.length > 350) continue;
      if (/người bệnh\s*:/i.test(txt) && /mã\s*:/i.test(txt)) {
        if (!bestHeaderText || txt.length < bestHeaderText.length) {
          bestHeaderText = txt;
        }
      }
    }

    if (bestHeaderText) {
      const mName = bestHeaderText.match(/người bệnh\s*:\s*([^|\n\r]+)/i);
      const mId = bestHeaderText.match(/mã(?:\s*(?:bn|bệnh nhân|người bệnh))?\s*:\s*([^\s|\n\r]+)/i);
      if (mName) patientName = clean(mName[1]);
      if (mId) patientId = clean(mId[1]);
    }

    // Dự phòng trang Hồ sơ điều trị ngoại trú: "TÊN BN (Nam/Nữ-XX tuổi)" + "Mã: XXXXX"
    if (!patientId) {
      let bestCardText = '';
      const ageRe = /(?:^|[\s(|])(?:nam|nữ)\s*[-–]\s*\d+\s*tuổi/i;
      const codeRe = /(?:^|[\s|])mã(?:\s*(?:bn|bệnh nhân|người bệnh|yt|y tế))?\s*:\s*([A-Za-z0-9_-]{4,20})/i;
      for (const node of headerNodes) {
        if (!isVisible(node)) continue;
        const txt = clean(node.innerText || node.textContent);
        if (txt.length < 10 || txt.length > 260) continue;
        if (ageRe.test(txt) && codeRe.test(txt)) {
          if (!bestCardText || txt.length < bestCardText.length) {
            bestCardText = txt;
          }
        }
      }
      if (bestCardText) {
        const mId = bestCardText.match(codeRe);
        const mName = bestCardText.match(/^([^(\n\r|:]{2,60})\s*\(\s*(?:nam|nữ)\s*[-–]\s*\d+\s*tuổi/i);
        if (mId) patientId = clean(mId[1]);
        if (mName && !patientName) patientName = clean(mName[1]);
      }
    }

    function findFieldByLabel(patterns) {
      const ignoredLabels = [
        'loại dịch vụ', 'loại xét nghiệm', 'nhóm dịch vụ', 'tên dịch vụ',
        'thời gian trả kết quả', 'ngày trả kết quả', 'tg trả kết quả',
        'thời gian thực hiện', 'người thực hiện', 'nơi thực hiện', 'danh sách chỉ số',
        'người chỉ định', 'bác sĩ chỉ định', 'bác sĩ đọc', 'kỹ thuật viên',
        'nơi chỉ định', 'khoa chỉ định', 'đồng bộ diễn biến', 'dịch vụ', 'kết quả', 'kết luận', 'mô tả', 'stt',
        'trạng thái', 'tình trạng', 'ghi chú', 'đã duyệt', 'đã trả kết quả', 'đã thực hiện'
      ];

      function isAnotherLabel(val) {
        const low = val.toLowerCase().replace(/:$/, '').trim();
        return ignoredLabels.includes(low);
      }

      const nodes = Array.from(document.querySelectorAll('label, div, span, td, th, p'));
      for (const node of nodes) {
        if (!isVisible(node)) continue;
        if (node.querySelector('input, textarea, select')) continue;
        const txt = clean(node.innerText || node.textContent).toLowerCase().replace(/:$/, '').trim();
        if (!txt || txt.length > 40) continue;
        if (!patterns.some((p) => txt === p)) continue;

        const candidates = [
          node.nextElementSibling,
          node.parentElement,
          node.parentElement?.nextElementSibling
        ].filter(Boolean);

        for (const box of candidates) {
          const field = box.matches?.('input, textarea, select')
            ? box
            : box.querySelector?.('input:not([type="checkbox"]):not([type="radio"]):not([type="hidden"]), textarea, select');
          if (field && isVisible(field)) {
            const val = field.tagName === 'SELECT'
              ? clean(field.options[field.selectedIndex]?.text || '')
              : clean(field.value);
            if (val) return val;
          }
        }

        const next = node.nextElementSibling;
        if (next && isVisible(next)) {
          const val = clean(next.innerText || next.textContent);
          if (val && val.length <= 120 && !isAnotherLabel(val)) return val;
        }

        const parent = node.parentElement;
        if (parent) {
          const parentText = clean(parent.innerText || parent.textContent);
          if (parentText.toLowerCase().replace(/:$/, '').trim() === txt) {
            const pNext = parent.nextElementSibling;
            if (pNext && isVisible(pNext)) {
              const val = clean(pNext.innerText || pNext.textContent);
              if (val && val.length <= 120 && !isAnotherLabel(val)) return val;
            }
          } else if (parentText.length > txt.length && parentText.length <= 140) {
            const stripped = clean(parentText.replace(new RegExp('^' + txt.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\s*:?\\s*', 'i'), ''));
            if (stripped && stripped.length <= 100 && !isAnotherLabel(stripped)) return stripped;
          }
        }
      }
      return '';
    }

    const serviceName = findFieldByLabel([
      'loại dịch vụ', 'loại xét nghiệm', 'nhóm dịch vụ',
      'tên dịch vụ', 'tên kỹ thuật', 'tên cđha', 'tên tdcn'
    ]);
    const resultTime = findFieldByLabel([
      'thời gian trả kết quả',
      'ngày trả kết quả',
      'tg trả kết quả',
      'thời gian thực hiện'
    ]);

    return { patientName, patientId, serviceName, resultTime };
  }

  function mapHeaderRow(row) {
    const map = { stt: -1, name: -1, value: -1, ref: -1, unit: -1 };
    const cells = Array.from(row.cells || []);

    cells.forEach((cell, idx) => {
      const h = getCellText(cell).toLowerCase();
      if (!h) return;

      if (map.stt === -1 && /^(stt|tt|#)$/.test(h)) {
        map.stt = idx;
      } else if (
        map.name === -1 &&
        !h.includes('loại xét nghiệm') &&
        (h === 'chỉ số' || h.includes('chỉ số') || h.includes('tên xét nghiệm') ||
         h.includes('tên xn') || h.includes('thông số'))
      ) {
        map.name = idx;
      } else if (
        map.value === -1 &&
        !h.includes('tiền sử') && !h.includes('cũ') && !h.includes('trước') &&
        (h === 'kết quả' || h.includes('kết quả') || h === 'kq' || h === 'giá trị' || h === 'result')
      ) {
        map.value = idx;
      } else if (
        map.ref === -1 &&
        (h.includes('tham chiếu') || h.includes('trị số') || h.includes('bình thường') ||
         h.includes('csbt') || h.includes('ngưỡng') || h.includes('reference'))
      ) {
        map.ref = idx;
      } else if (
        map.unit === -1 &&
        (h.includes('đơn vị') || h === 'đv' || h === 'unit')
      ) {
        map.unit = idx;
      }
    });

    let score = 0;
    if (map.name !== -1) score += 3;
    if (map.value !== -1) score += 3;
    if (map.ref !== -1) score += 2;
    if (map.unit !== -1) score += 1;
    if (map.stt !== -1) score += 1;

    return { map, score, colCount: cells.length };
  }

  function findPairedBodyTable(headerTable, expectedCols) {
    let container = headerTable.parentElement;
    for (let depth = 0; depth < 3 && container && container !== document.body; depth++) {
      const candidates = Array.from(container.querySelectorAll('table')).filter((t) => {
        if (t === headerTable || !isVisible(t)) return false;
        if (!(headerTable.compareDocumentPosition(t) & Node.DOCUMENT_POSITION_FOLLOWING)) return false;
        const rows = t.tBodies.length ? Array.from(t.tBodies[0].rows) : Array.from(t.rows);
        return rows.length > 0;
      });

      if (candidates.length) {
        const exact = candidates.find((t) => {
          const firstRow = (t.tBodies[0]?.rows[0]) || t.rows[0];
          return firstRow && firstRow.cells.length === expectedCols;
        });
        return exact || candidates[0];
      }
      container = container.parentElement;
    }
    return null;
  }

  const meta = extractHISMetadata();

  const selection = window.getSelection()?.toString() || '';
  if (selection.trim() && /[\t\n]/.test(selection) && /\d/.test(selection)) {
    return { type: 'selection', text: selection.trim(), meta };
  }

  const visibleTables = Array.from(document.querySelectorAll('table')).filter(isVisible);
  let bestCls = null;

  for (const table of visibleTables) {
    const headerCandidates = table.tHead
      ? Array.from(table.tHead.rows)
      : Array.from(table.rows).slice(0, 2);

    let bestHeader = null;
    let headerRowRef = null;
    for (const hRow of headerCandidates) {
      const res = mapHeaderRow(hRow);
      if (!bestHeader || res.score > bestHeader.score) {
        bestHeader = res;
        headerRowRef = hRow;
      }
    }

    if (!bestHeader || bestHeader.map.name === -1 || bestHeader.map.value === -1) continue;

    let dataRows = [];
    if (table.tBodies && table.tBodies.length) {
      for (const tb of table.tBodies) dataRows.push(...Array.from(tb.rows));
    } else {
      dataRows = Array.from(table.rows);
    }
    dataRows = dataRows.filter((r) => r !== headerRowRef && isVisible(r));

    if (!dataRows.length) {
      const bodyTable = findPairedBodyTable(table, bestHeader.colCount);
      if (bodyTable) {
        const bodyRows = bodyTable.tBodies?.length
          ? Array.from(bodyTable.tBodies[0].rows)
          : Array.from(bodyTable.rows);
        dataRows = bodyRows.filter(isVisible);
      }
    }

    const { map } = bestHeader;
    const lines = [];
    let autoStt = 1;

    for (const row of dataRows) {
      const cells = Array.from(row.cells || []);
      if (cells.length <= Math.max(map.name, map.value)) continue;

      const name = getCellText(cells[map.name]);
      const value = getCellText(cells[map.value]);
      if (!name || !value) continue;

      const nameLower = name.toLowerCase();
      if (nameLower === 'chỉ số' || nameLower === 'tên xét nghiệm') continue;

      let stt = map.stt !== -1 && cells[map.stt] ? getCellText(cells[map.stt]) : '';
      if (!/^\d+$/.test(stt)) stt = String(autoStt);
      autoStt++;

      const ref = map.ref !== -1 && cells[map.ref] ? getCellText(cells[map.ref]) : '';
      const unit = map.unit !== -1 && cells[map.unit] ? getCellText(cells[map.unit]) : '';

      lines.push([stt, name, value, ref || '—', unit].join('\t'));
    }

    if (lines.length > 0) {
      const candidate = {
        type: 'cls_table',
        score: bestHeader.score,
        rowCount: lines.length,
        text: lines.join('\n'),
        meta
      };
      if (
        !bestCls ||
        candidate.score > bestCls.score ||
        (candidate.score === bestCls.score && candidate.rowCount > bestCls.rowCount)
      ) {
        bestCls = candidate;
      }
    }
  }

  if (bestCls) return bestCls;

  // --- Mở rộng: Đọc ô "Kết luận" ở tab Lịch sử CĐHA / Lịch sử TDCN-Khác ---
  function extractConclusionFromHIS() {
    const ignoredVals = new Set([
      'kết luận', 'mô tả', 'lời dặn', 'đề nghị', 'ghi chú',
      'người thực hiện', 'người chỉ định', 'bác sĩ chỉ định', 'bác sĩ đọc',
      'kỹ thuật viên', 'nơi thực hiện', 'thời gian trả kết quả', 'thời gian thực hiện',
      'đồng bộ diễn biến', 'dịch vụ', 'kết quả', 'stt', 'xem'
    ]);

    function isBadServiceName(val) {
      const low = clean(val).toLowerCase().replace(/:$/, '').trim();
      if (!low || low.length < 3 || /^\d+$/.test(low)) return true;
      if (/^\d{1,2}:\d{2}\b/.test(low) || /^\d{1,2}\/\d{1,2}\/\d{2,4}/.test(low)) return true;
      return /^(người chỉ định|bác sĩ chỉ định|người thực hiện|bác sĩ đọc|kỹ thuật viên|nơi thực hiện|nơi chỉ định|khoa phòng|khoa chỉ định|thời gian|ngày|mô tả|kết luận|kết quả|dịch vụ|stt|đồng bộ|xem|tìm kiếm|trong ngày|cđha|cdha|tdcn|chẩn đoán hình ảnh|thăm dò chức năng|khác)$/.test(low);
    }

    function cleanConclusionText(raw) {
      if (!raw) return '';
      let s = String(raw).replace(/\r/g, '');
      s = s.replace(/^\s*kết luận(?:\s+(?:cđha|tdcn|chung))?\s*:?\s*/i, '');
      const parts = s
        .split('\n')
        .map((line) => line.replace(/^\s*[-•+*]\s*/, '').replace(/\s+/g, ' ').trim())
        .filter((line) => line && !/^[-–—.]+$/.test(line));
      return parts.join('; ').replace(/\s*;\s*;\s*/g, '; ').trim();
    }

    function cleanServiceTitle(raw) {
      if (!raw) return '';
      let s = clean(raw).replace(/^\s*(?:\([^)]+\)|\[[^\]]+\])\s*/, '');
      // Lược bỏ phần chú thích kỹ thuật trong ngoặc đơn/ngoặc vuông, giữ nguyên "Chụp ..."
      s = s.replace(/\s*\([^)]*\)?/g, '').replace(/\s*\[[^\]]*\]?/g, '');
      s = s.replace(/[\s,.;:-]+$/, '').trim();
      if (isBadServiceName(s)) return '';
      return s.slice(0, 75);
    }

    function detectActiveTabCategory() {
      const tabs = Array.from(document.querySelectorAll(
        '[role="tab"], .nav-link, .tab, .ant-tabs-tab, .k-item, .el-tabs__item, li, button, a'
      ));
      for (const node of tabs) {
        if (!isVisible(node)) continue;
        const isActive =
          node.getAttribute('aria-selected') === 'true' ||
          /\b(active|selected|current|is-active|ant-tabs-tab-active|k-state-active)\b/i.test(node.className || '');
        if (!isActive) continue;
        const txt = clean(node.innerText || node.textContent).toLowerCase();
        if (!txt || txt.length > 45) continue;
        if (txt.includes('tdcn') || txt.includes('thăm dò')) return 'TDCN';
        if (txt.includes('cđha') || txt.includes('cdha') || txt.includes('chẩn đoán hình ảnh')) return 'CĐHA';
      }
      return '';
    }

    function hasImagingPageContext() {
      const bodySample = (document.body?.innerText || '').slice(0, 6000).toLowerCase();
      return /lịch sử cđha|lịch sử tdcn|chẩn đoán hình ảnh|thăm dò chức năng|nơi thực hiện|kỹ thuật viên|đồng bộ diễn biến|thời gian trả kết quả/.test(bodySample);
    }

    function readFieldValue(box) {
      if (!box) return { text: '', isEditableInput: false };
      const field = box.matches?.('textarea, input:not([type="checkbox"]):not([type="radio"]):not([type="hidden"]), [contenteditable="true"]')
        ? box
        : box.querySelector?.('textarea, input:not([type="checkbox"]):not([type="radio"]):not([type="hidden"]), [contenteditable="true"]');

      if (field && isVisible(field)) {
        if (field === document.activeElement && !field.readOnly && !field.disabled) {
          return { text: '', isEditableInput: true };
        }
        const isEditableInput = !field.readOnly && !field.disabled;
        const raw = field.isContentEditable ? (field.innerText || field.textContent) : field.value;
        return { text: cleanConclusionText(raw), isEditableInput };
      }

      if (isVisible(box)) {
        const raw = cleanConclusionText(box.innerText || box.textContent);
        if (raw && raw.length <= 1200 && !ignoredVals.has(raw.toLowerCase())) {
          return { text: raw, isEditableInput: false };
        }
      }
      return { text: '', isEditableInput: false };
    }

    const activeTabCat = detectActiveTabCategory();
    const pageHasContext = Boolean(activeTabCat) || hasImagingPageContext();
    if (!pageHasContext) return null;

    // 1. Tìm ô / khối văn bản "Kết luận"
    let bestConclusion = '';
    const labelNodes = Array.from(document.querySelectorAll('label, div, span, td, th, p, h3, h4, h5, strong, b, legend'));
    for (const node of labelNodes) {
      if (!isVisible(node)) continue;
      if (node.querySelector('textarea, input, select')) continue;
      const lbl = clean(node.innerText || node.textContent).toLowerCase().replace(/:$/, '').trim();
      if (!lbl || lbl.length > 35) continue;
      if (!/^kết luận(?:\s+(?:cđha|tdcn|siêu âm|x-?quang|điện tim|nội soi|chung))?$/.test(lbl)) continue;

      const candidates = [];
      const forId = node.getAttribute?.('for');
      if (forId) candidates.push(document.getElementById(forId));
      candidates.push(
        node.nextElementSibling,
        node.parentElement,
        node.parentElement?.nextElementSibling,
        node.closest?.('tr')?.nextElementSibling
      );

      for (const box of candidates.filter(Boolean)) {
        if (box === node.parentElement && !box.querySelector('textarea, input, [contenteditable="true"]')) {
          const pTxt = clean(box.innerText || box.textContent);
          if (pTxt.length > lbl.length + 2 && pTxt.length <= 1200) {
            const stripped = cleanConclusionText(pTxt);
            if (stripped && !ignoredVals.has(stripped.toLowerCase())) {
              bestConclusion = stripped;
              break;
            }
          }
          continue;
        }
        const res = readFieldValue(box);
        if (res.text) {
          bestConclusion = res.text;
          break;
        }
      }
      if (bestConclusion) break;
    }

    if (!bestConclusion) {
      const tas = Array.from(document.querySelectorAll('textarea')).filter(isVisible);
      for (const ta of tas) {
        if (ta === document.activeElement && !ta.readOnly && !ta.disabled) continue;
        const hint = `${ta.placeholder || ''} ${ta.name || ''} ${ta.id || ''}`.toLowerCase();
        if (/kết luận|ketluan|ket_luan|conclusion/.test(hint)) {
          const val = cleanConclusionText(ta.value);
          if (val) { bestConclusion = val; break; }
        }
      }
    }

    if (!bestConclusion) return null;

    // 2. Lấy chuẩn Tên dịch vụ:
    // Ưu tiên 1: Bảng chi tiết ngay dưới nhãn "Dịch vụ" ở khung bên phải (VD: "1 | Siêu âm tim, màng tim qua thành ngực")
    let examName = '';
    let tableTime = '';

    function extractFromDetailServiceTable(tbl) {
      if (!tbl || !isVisible(tbl)) return '';
      const headerRow = tbl.tHead?.rows?.[0] || tbl.rows?.[0];
      const rows = (tbl.tBodies?.length ? Array.from(tbl.tBodies[0].rows) : Array.from(tbl.rows))
        .filter((r) => r !== headerRow && isVisible(r));
      for (const r of rows) {
        const cells = Array.from(r.cells || []);
        for (const c of cells) {
          const cleaned = cleanServiceTitle(getCellText(c));
          if (cleaned) return cleaned;
        }
      }
      return '';
    }

    for (const node of labelNodes) {
      if (!isVisible(node)) continue;
      if (node.querySelector('table, input, textarea, select')) continue;
      const lbl = clean(node.innerText || node.textContent).toLowerCase().replace(/:$/, '').trim();
      if (lbl !== 'dịch vụ' && lbl !== 'tên dịch vụ' && lbl !== 'danh sách dịch vụ') continue;

      const containers = [
        node.nextElementSibling,
        node.parentElement,
        node.parentElement?.nextElementSibling
      ].filter(Boolean);

      for (const box of containers) {
        const tbl = box.matches?.('table') ? box : box.querySelector?.('table');
        const found = extractFromDetailServiceTable(tbl);
        if (found) {
          examName = found;
          break;
        }
      }
      if (examName) break;
    }

    // Ưu tiên 2: Dòng đang chọn (active hoặc chữ in đậm) trong bảng danh sách bên trái
    if (!examName) {
      for (const tbl of visibleTables) {
        const headerRow = tbl.tHead?.rows?.[0] || tbl.rows?.[0];
        if (!headerRow) continue;
        const hCells = Array.from(headerRow.cells || []);
        const hTexts = hCells.map((c) => getCellText(c).toLowerCase());

        let svcColIdx = hTexts.findIndex((h) =>
          !h.includes('loại xét nghiệm') && !h.includes('chỉ số') &&
          (h.includes('tên dịch vụ') || h === 'dịch vụ' || h.includes('tên kỹ thuật') ||
           h.includes('kỹ thuật') || h.includes('tên cđha') || h.includes('tên tdcn') || h.includes('loại dịch vụ'))
        );
        const timeColIdx = hTexts.findIndex((h) => h.includes('thời gian') || h.includes('ngày'));

        // Bảng bên trái HIS có cột STT + Thời gian chỉ định + cột thứ 3 là Tên dịch vụ
        if (svcColIdx === -1 && timeColIdx !== -1 && hCells.length > timeColIdx + 1) {
          svcColIdx = timeColIdx + 1;
        }
        if (svcColIdx === -1) continue;

        let bodyRows = (tbl.tBodies?.length ? Array.from(tbl.tBodies[0].rows) : Array.from(tbl.rows).slice(1))
          .filter((r) => r !== headerRow && isVisible(r) && r.cells && r.cells.length > svcColIdx);

        if (!bodyRows.length) {
          const paired = findPairedBodyTable(tbl, hCells.length);
          if (paired) {
            bodyRows = (paired.tBodies?.length ? Array.from(paired.tBodies[0].rows) : Array.from(paired.rows))
              .filter((r) => isVisible(r) && r.cells && r.cells.length > svcColIdx);
          }
        }
        if (!bodyRows.length) continue;

        let selRow = bodyRows.find((r) =>
          r.getAttribute('aria-selected') === 'true' ||
          /\b(active|selected|current|highlight|checked|k-state-selected|ant-table-row-selected|el-table__row--current)\b/i.test(r.className || '') ||
          r.querySelector('input[type="radio"]:checked, input[type="checkbox"]:checked')
        );

        // Nhận diện dòng in đậm (font-weight >= 600 hoặc thẻ <b>/<strong>) như HIS
        if (!selRow) {
          const boldRows = bodyRows.filter((r) => {
            const cell = r.cells[svcColIdx];
            if (!cell) return false;
            if (cell.querySelector('b, strong')) return true;
            const fw = window.getComputedStyle(cell).fontWeight;
            const numFw = parseInt(fw, 10);
            return fw === 'bold' || (!isNaN(numFw) && numFw >= 600);
          });
          if (boldRows.length === 1) selRow = boldRows[0];
        }

        if (!selRow && bodyRows.length === 1) selRow = bodyRows[0];

        if (selRow) {
          const found = cleanServiceTitle(getCellText(selRow.cells[svcColIdx]));
          if (found) {
            examName = found;
            if (timeColIdx !== -1 && selRow.cells[timeColIdx]) {
              tableTime = getCellText(selRow.cells[timeColIdx]);
            }
            break;
          }
        }
      }
    }

    // Ưu tiên 3: Lấy từ meta nếu hợp lệ
    if (!examName) {
      examName = cleanServiceTitle(meta.serviceName);
    }

    // 3. Phân loại CĐHA hay TDCN và dự phòng tên nếu thật sự không đọc được
    const probe = `${examName} ${bestConclusion}`.toLowerCase();
    let category = activeTabCat;

    if (!examName) {
      if (/nhịp xoang|block nhánh|điện tâm đồ|\becg\b|sóng t|đoạn st|trục trung gian|ck\/ph/.test(probe)) {
        examName = 'Điện tim';
      } else if (/nội soi|niêm mạc dạ dày|hang vị|thực quản|tá tràng|đại tràng|màng nhĩ|cuốn mũi/.test(probe)) {
        examName = 'Nội soi';
      } else if (/cắt lớp|\bct\b|tỷ trọng/.test(probe)) {
        examName = 'Chụp cắt lớp vi tính';
      } else if (/cộng hưởng từ|\bmri\b|đĩa đệm/.test(probe)) {
        examName = 'Chụp MRI';
      } else if (/x-?quang|phế trường|góc sườn hoành|bóng tim|cung động mạch chủ/.test(probe)) {
        examName = 'Chụp X-quang';
      } else if (/siêu âm|nhu mô gan|túi mật|lách|thận|bàng quang|tuyến giáp|ổ bụng|tâm thu|van ba lá|thất phải/.test(probe)) {
        examName = 'Siêu âm';
      } else if (/điện não|\beeg\b/.test(probe)) {
        examName = 'Điện não';
      } else {
        examName = activeTabCat || 'CĐHA';
      }
    }

    if (!category) {
      if (/điện tim|đtđ|\becg\b|nội soi|điện não|\beeg\b|điện cơ|hô hấp ký|chức năng hô hấp|thăm dò|tdcn|holter|loãng xương/.test(probe)) {
        category = 'TDCN';
      } else {
        category = 'CĐHA';
      }
    }

    return {
      type: 'cls_conclusion',
      score: 10,
      rowCount: 1,
      text: ['1', examName, bestConclusion, category, ''].join('\t'),
      meta: {
        ...meta,
        serviceName: examName,
        resultTime: meta.resultTime || tableTime
      }
    };
  }

  const conclusionHit = extractConclusionFromHIS();
  if (conclusionHit) return conclusionHit;
  if (visibleTables.length > 0) {
    let bestTable = visibleTables[0];
    for (const t of visibleTables) {
      if ((t.innerText || '').length > (bestTable.innerText || '').length) {
        bestTable = t;
      }
    }
    let resultText = '';
    for (const row of bestTable.rows) {
      if (!isVisible(row)) continue;
      resultText += Array.from(row.cells).map(getCellText).join('\t') + '\n';
    }
    return { type: 'table', text: resultText.trim(), meta };
  }

  if (meta.patientId || meta.patientName || meta.serviceName) {
    return { type: 'meta_only', text: '', meta };
  }

  return null;
}

function pickBestResult(results, mode = 'manual') {
  const validResults = (results || []).map((r) => r.result).filter(Boolean);
  const clsTableHit = validResults
    .filter((r) => r.type === 'cls_table' && r.text.trim())
    .sort((a, b) => (b.score - a.score) || (b.rowCount - a.rowCount))[0];

  const conclusionHit = validResults
    .filter((r) => r.type === 'cls_conclusion' && r.text.trim())
    .sort((a, b) => (b.score - a.score) || (b.text.length - a.text.length))[0];

  if (mode === 'auto') {
    return clsTableHit || conclusionHit || null;
  }

  const selectionHit = validResults.find((r) => r.type === 'selection' && r.text.trim());
  const fallbackTableHit = validResults
    .filter((r) => r.type === 'table' && r.text.trim())
    .sort((a, b) => b.text.length - a.text.length)[0];

  return selectionHit || clsTableHit || conclusionHit || fallbackTableHit || null;
}

function buildContextKeyFromTab(tab) {
  if (!tab) return '';
  const urlStr = String(tab.url || '');
  try {
    const u = new URL(urlStr);
    const params = [];

    for (const [k, v] of u.searchParams.entries()) {
      if (v) params.push([k.toLowerCase(), v.trim()]);
    }
    const rawHash = (u.hash || '').replace(/^#/, '');
    if (rawHash) {
      const hashQuery = rawHash.includes('?') ? rawHash.split('?').slice(1).join('&') : rawHash;
      for (const part of hashQuery.split('&')) {
        const eq = part.indexOf('=');
        if (eq > 0) {
          const k = decodeURIComponent(part.slice(0, eq)).toLowerCase().trim();
          const v = decodeURIComponent(part.slice(eq + 1)).trim();
          if (k && v) params.push([k, v]);
        }
      }
    }

    const ignoredKeyRe = /^(scope|lang|bpid|tab|tabid|page|menu|menuid|module|moduleid|appid|mode)$|(khoa|phong|donvi|coso|user|bacsi|nhanvien)/;
    const uuidRe = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

    // Ưu tiên 1: Mã/ID bệnh nhân hoặc hồ sơ trong URL
    const pParam = params.find(([k]) => !ignoredKeyRe.test(k) && /(mabenhnhan|mabn|benhnhanid|patientid|bnid|hosoid|hsbaid|hsid)/.test(k));
    if (pParam) return `url:${pParam[0]}=${pParam[1]}`;

    // Ưu tiên 2: ID lượt khám / y lệnh ngoại trú (VD: raodylenhsid, raodtrngoaitruid...)
    const encParam = params.find(([k]) => !ignoredKeyRe.test(k) && /(raod|ylenh|ngoaitru|noitru|kham|kcb|dtr|chidinh)/.test(k));
    if (encParam) return `url:${encParam[0]}=${encParam[1]}`;

    // Ưu tiên 3: Tham số dạng GUID bất kỳ khác
    const guidParam = params.find(([k, v]) => !ignoredKeyRe.test(k) && uuidRe.test(v));
    if (guidParam) return `url:${guidParam[0]}=${guidParam[1]}`;
  } catch {}

  return tab.id ? `tab:${tab.id}` : '';
}

function attachContextKey(tab, meta) {
  const m = { ...(meta || {}) };
  if (m.patientId) {
    m.contextKey = 'pid:' + m.patientId;
  } else if (!m.contextKey) {
    m.contextKey = buildContextKeyFromTab(tab);
  }
  return m;
}

function mergeMeta(primary, fallback) {
  const a = primary || {};
  const b = fallback || {};
  return {
    patientName: a.patientName || b.patientName || '',
    patientId: a.patientId || b.patientId || '',
    serviceName: a.serviceName || b.serviceName || '',
    resultTime: a.resultTime || b.resultTime || '',
    contextKey: a.contextKey || b.contextKey || ''
  };
}

async function scanSpecificTab(tab, mode = 'manual') {
  if (!tab || !tab.id) {
    if (mode === 'auto') return { ok: true, empty: true };
    return { ok: false, error: 'Không tìm thấy tab trang bệnh án (HIS) đang mở.' };
  }

  let mainHit = null;
  let mainMeta = null;
  try {
    const mainRes = await withTimeout(
      chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: extractDataFromHIS
      }),
      mode === 'auto' ? 1500 : 2500,
      'Quét khung chính quá thời gian.'
    );
    mainMeta = mainRes?.[0]?.result?.meta || null;
    mainHit = pickBestResult(mainRes, mode);
  } catch (err) {
    if (mode === 'auto') return { ok: true, empty: true };
    return { ok: false, error: `Không đọc được tab "${tab.title || tab.url}": ${err.message}` };
  }

  // 👇 Hàm kiểm tra chung cho cả 2 chỗ (đã bổ sung cls_conclusion)
  const isStrongHit = (hit) =>
    hit && (hit.type === 'selection' || hit.type === 'cls_table' || hit.type === 'cls_conclusion');

  // Chỗ 1 (mainHit):
  if (isStrongHit(mainHit)) {
    return {
      ok: true,
      tabId: tab.id,
      text: mainHit.text,
      type: mainHit.type,
      meta: attachContextKey(tab, mergeMeta(mainHit.meta, mainMeta))
    };
  }

  let frameHit = null;
  try {
    const frameRes = await withTimeout(
      chrome.scripting.executeScript({
        target: { tabId: tab.id, allFrames: true },
        func: extractDataFromHIS
      }),
      mode === 'auto' ? 2000 : 3000,
      'iframe phản hồi chậm.'
    );
    frameHit = pickBestResult(frameRes, mode);
  } catch {}

  // 👇 Chỗ 2: kiểm tra frameHit
  const best = isStrongHit(frameHit)
    ? frameHit
    : (mainHit || frameHit);

  if (best && best.text && best.text.trim()) {
    return {
      ok: true,
      tabId: tab.id,
      text: best.text,
      type: best.type,
      meta: attachContextKey(tab, mergeMeta(best.meta, mainMeta))
    };
  }

  if (mode === 'auto') return { ok: true, empty: true };
  return { ok: false, tabId: tab.id, error: `Không thấy bảng xét nghiệm hoặc kết luận CĐHA/TDCN ở tab: ${tab.title || tab.url}` };
}

async function handleScanHIS(senderTabId, mode = 'manual') {
  const tab = await findTargetTabForScan(senderTabId);
  return scanSpecificTab(tab, mode);
}

function copyTextInPage(text) {
  const prevActive = document.activeElement;
  const ta = document.createElement('textarea');
  ta.id = 'cls-ext-copy-tmp';
  ta.value = text;
  ta.setAttribute('readonly', '');
  ta.style.cssText = 'position:fixed;top:0;left:0;opacity:0;pointer-events:none;';
  document.body.appendChild(ta);
  ta.focus({ preventScroll: true });
  ta.select();
  ta.setSelectionRange(0, text.length);
  let ok = false;
  try { ok = document.execCommand('copy'); } catch {}
  ta.remove();
  try {
    if (prevActive && prevActive !== document.body && prevActive.focus) {
      prevActive.focus({ preventScroll: true });
    }
  } catch {}
  return ok;
}

function insertTextInPage(text) {
  function getDeepActiveElement(root) {
    let active = root.activeElement;
    while (active && active.shadowRoot && active.shadowRoot.activeElement) {
      active = active.shadowRoot.activeElement;
    }
    return active;
  }

  const target = getDeepActiveElement(document);
  if (!target || target === document.body || target === document.documentElement) {
    return { ok: false };
  }

  const tag = (target.tagName || '').toUpperCase();
  const isTextInput =
    tag === 'TEXTAREA' ||
    (tag === 'INPUT' && ['text', 'search', 'url', 'tel', 'email', ''].includes((target.type || 'text').toLowerCase()));
  const isEditable = Boolean(target.isContentEditable);

  if ((!isTextInput && !isEditable) || target.disabled || target.readOnly) {
    return { ok: false };
  }

  target.focus({ preventScroll: true });

  let inserted = false;
  try {
    inserted = document.execCommand('insertText', false, text);
  } catch {}

  if (!inserted && isTextInput) {
    const start = typeof target.selectionStart === 'number' ? target.selectionStart : target.value.length;
    const end = typeof target.selectionEnd === 'number' ? target.selectionEnd : target.value.length;
    const nextVal = target.value.slice(0, start) + text + target.value.slice(end);
    const proto = tag === 'TEXTAREA' ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
    if (setter) setter.call(target, nextVal);
    else target.value = nextVal;

    try {
      target.setSelectionRange(start + text.length, start + text.length);
    } catch {}
    target.dispatchEvent(new Event('input', { bubbles: true }));
    target.dispatchEvent(new Event('change', { bubbles: true }));
    inserted = true;
  } else if (!inserted && isEditable) {
    const sel = window.getSelection();
    if (sel && sel.rangeCount) {
      const range = sel.getRangeAt(0);
      range.deleteContents();
      const node = document.createTextNode(text);
      range.insertNode(node);
      range.setStartAfter(node);
      range.collapse(true);
      sel.removeAllRanges();
      sel.addRange(range);
      target.dispatchEvent(new Event('input', { bubbles: true }));
      inserted = true;
    }
  }

  return { ok: Boolean(inserted) };
}

function showPageToast(message, isError = false, isDark = false) {
  const id = 'cls-ext-page-toast';
  const old = document.getElementById(id);
  if (old) old.remove();

  const el = document.createElement('div');
  el.id = id;
  el.textContent = message;
  const bg = isError ? '#dc2626' : (isDark ? '#0f766e' : '#0d9488');
  const border = isDark ? 'rgba(255,255,255,0.14)' : 'rgba(15,23,42,0.08)';
  el.style.cssText = [
    'position:fixed',
    'bottom:64px',
    'right:24px',
    'z-index:2147483647',
    'padding:9px 15px',
    'border-radius:10px',
    'font:600 12.5px/1.4 system-ui,-apple-system,Segoe UI,sans-serif',
    'color:#ffffff',
    `background:${bg}`,
    `border:1px solid ${border}`,
    'box-shadow:0 8px 24px rgba(0,0,0,0.22)',
    'transition:opacity 220ms ease',
    'pointer-events:none'
  ].join(';');
  document.body.appendChild(el);

  setTimeout(() => { el.style.opacity = '0'; }, 2200);
  setTimeout(() => { el.remove(); }, 2500);
}

async function notifyTab(tabId, message, isError = false) {
  if (!tabId) return;
  try {
    const stored = await chrome.storage.local.get(SHARED_SETTINGS_KEY);
    const isDark = stored?.[SHARED_SETTINGS_KEY]?.darkMode !== false;
    await chrome.scripting.executeScript({
      target: { tabId },
      func: showPageToast,
      args: [message, isError, isDark]
    });
  } catch {}
}

let creatingOffscreen = null;

async function ensureOffscreenDocument() {
  const offscreenUrl = chrome.runtime.getURL('offscreen.html');
  if (chrome.runtime.getContexts) {
    const contexts = await chrome.runtime.getContexts({
      contextTypes: ['OFFSCREEN_DOCUMENT'],
      documentUrls: [offscreenUrl]
    });
    if (contexts.length > 0) return;
  }

  if (creatingOffscreen) {
    await creatingOffscreen;
    return;
  }

  creatingOffscreen = chrome.offscreen.createDocument({
    url: 'offscreen.html',
    reasons: ['CLIPBOARD'],
    justification: 'Ghi chuỗi tóm tắt CLS vào clipboard khi tự động quét và gộp ngầm'
  });

  try {
    await creatingOffscreen;
  } catch (err) {
    if (!String(err?.message || err).includes('Only a single offscreen')) throw err;
  } finally {
    creatingOffscreen = null;
  }
}

async function copyTextReliable(text, fallbackTabId = null) {
  if (!text) return false;
  try {
    await ensureOffscreenDocument();
    const res = await chrome.runtime.sendMessage({
      target: 'offscreen',
      type: 'COPY_TO_CLIPBOARD',
      text
    });
    if (res && res.ok) return true;
  } catch {}

  if (fallbackTabId) {
    try {
      const res = await chrome.scripting.executeScript({
        target: { tabId: fallbackTabId },
        func: copyTextInPage,
        args: [text]
      });
      return Boolean(res?.[0]?.result);
    } catch {}
  }
  return false;
}

async function handleCopyInActiveTab(senderTabId, text) {
  const tab = await findTargetTabForScan(senderTabId);
  const ok = await copyTextReliable(text, tab?.id || null);
  return { ok };
}

async function handleInsertToHIS(senderTabId, text, explicitTab = null) {
  const tab = explicitTab || await findTargetTabForScan(senderTabId);
  if (!tab || !tab.id) {
    return { ok: false, error: 'Không tìm thấy tab HIS đang mở.' };
  }

  try {
    const mainRes = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: insertTextInPage,
      args: [text]
    });
    if (mainRes?.[0]?.result?.ok) return { ok: true };

    const frameRes = await chrome.scripting.executeScript({
      target: { tabId: tab.id, allFrames: true },
      func: insertTextInPage,
      args: [text]
    });
    if ((frameRes || []).some((r) => r?.result?.ok)) return { ok: true };

    return { ok: false, error: 'Hãy click đặt con trỏ vào ô văn bản trên HIS trước khi bấm Chèn.' };
  } catch (err) {
    return { ok: false, error: 'Không thể chèn vào trang này: ' + (err?.message || err) };
  }
}

/* ---------- Xử lý tóm tắt & gộp ngầm trong Background ---------- */
async function getAbbrMapForBackground() {
  const stored = await chrome.storage.local.get(ABBR_CACHE_KEY);
  if (stored?.[ABBR_CACHE_KEY] && Object.keys(stored[ABBR_CACHE_KEY]).length) {
    return stored[ABBR_CACHE_KEY];
  }
  try {
    const res = await withTimeout(fetch(ABBR_ENDPOINT, { cache: 'no-store' }), 2000, 'timeout');
    if (res.ok) {
      const data = await res.json();
      const map = {};
      Object.values(data || {}).forEach((item) => {
        if (item && item.raw != null && item.short != null) map[item.raw] = item.short;
      });
      if (Object.keys(map).length) {
        await chrome.storage.local.set({ [ABBR_CACHE_KEY]: map });
        return map;
      }
    }
  } catch {}
  return { ...DEFAULT_ABBR };
}

async function upsertMergeInBackground(rawText, meta, settings, abbrMap, forceNotify = false) {
  const rows = CLS.parseInputToRows(rawText);
  if (!rows.length) return { empty: true };

  const stored = await chrome.storage.local.get(MERGE_SESSION_KEY);
  const session = stored?.[MERGE_SESSION_KEY] || { patient: { id: '', name: '' }, sheets: [] };
  let patient = {
    id: session.patient?.id || '',
    name: session.patient?.name || '',
    contextKey: session.patient?.contextKey || (session.patient?.id ? 'pid:' + session.patient.id : '')
  };
  let sheets = Array.isArray(session.sheets) ? [...session.sheets] : [];

  const incomingId = meta?.patientId || '';
  const incomingName = meta?.patientName || '';
  const incomingKey = incomingId ? 'pid:' + incomingId : (meta?.contextKey || '');
  let patientSwitched = false;

  if (incomingKey && patient.contextKey && incomingKey !== patient.contextKey) {
    sheets = [];
    patient = { id: '', name: '', contextKey: '' };
    patientSwitched = true;
  }

  if (!patientSwitched && !forceNotify && sheets.some((s) => s.rawText === rawText)) {
    return { unchanged: true };
  }

  if (incomingId) patient.id = incomingId;
  if (incomingName) patient.name = incomingName;
  if (incomingKey) patient.contextKey = incomingKey;

  const label = CLS.getShortServiceLabel(meta?.serviceName, rows);
  const resultTime = (meta?.resultTime || '').trim();
  const key = CLS.makeSheetKey(label, resultTime, rows);

  const sheetObj = {
    key,
    label,
    serviceName: meta?.serviceName || label,
    resultTime,
    rawText
  };

  const existingIdx = CLS.findMatchingSheetIndex(sheets, { rawText, label, resultTime, rows });
  const isUpdated = existingIdx !== -1;
  if (isUpdated) {
    if (!sheetObj.resultTime && sheets[existingIdx].resultTime) {
      sheetObj.resultTime = sheets[existingIdx].resultTime;
      sheetObj.key = CLS.makeSheetKey(label, sheetObj.resultTime, rows);
    }
    sheets[existingIdx] = sheetObj;
  } else {
    sheets.push(sheetObj);
  }

  CLS.sortSheets(sheets);

  const nextSession = { patient, sheets, updatedAt: Date.now() };
  await chrome.storage.local.set({ [MERGE_SESSION_KEY]: nextSession });

  const { plain } = CLS.formatMergedSheets(sheets, settings, abbrMap);
  const displayLabel = (label === 'CĐHA' || label === 'TDCN') ? (rows[0]?.cleanName || label) : label;
  return { plain, label: displayLabel, isUpdated, patientSwitched, patient, count: sheets.length };
}

let bgCaptureChain = Promise.resolve();
let bgCaptureQueued = 0;

async function runBackgroundAutoCapture(tab) {
  if (!tab || !tab.id || !isHisUrl(tab.url)) return { ok: true };
  const stored = await chrome.storage.local.get([SHARED_SETTINGS_KEY, CAPTURE_PAUSED_KEY]);
  const settings = stored?.[SHARED_SETTINGS_KEY] || {};
  if (settings.mergeEnabled === false || stored?.[CAPTURE_PAUSED_KEY]) return { ok: true };

  const scanRes = await scanSpecificTab(tab, 'auto');
  if (!scanRes.ok || scanRes.empty || !scanRes.text?.trim()) return { ok: true };

  const abbrMap = await getAbbrMapForBackground();
  const res = await upsertMergeInBackground(scanRes.text.trim(), scanRes.meta, settings, abbrMap, false);
  if (res.empty || res.unchanged || !res.plain) return { ok: true };

  const copied = await copyTextReliable(res.plain, tab.id);
  const suffix = copied ? ' & copy' : ' (chưa copy được)';

  const bnLabel = res.patient.name || res.patient.id || 'mới';
  const toastMsg = res.patientSwitched
    ? `✓ Đổi BN ${bnLabel} — gộp mới (${res.label})${suffix}`
    : (res.isUpdated
      ? `✓ Cập nhật ${res.label} (${res.count} phiếu)${suffix}`
      : `✓ Đã gộp +${res.label} (${res.count} phiếu)${suffix}`);

  await notifyTab(tab.id, toastMsg, !copied);
  return { ok: true, captured: true };
}

function handleBackgroundAutoCapture(tab, forceWait = false) {
  if (!tab || !tab.id || !isHisUrl(tab.url)) return Promise.resolve({ ok: true });
  if (!forceWait && bgCaptureQueued >= 1) return Promise.resolve({ ok: true, skipped: true });

  bgCaptureQueued++;
  const job = bgCaptureChain
    .catch(() => {})
    .then(async () => {
      bgCaptureQueued = Math.max(0, bgCaptureQueued - 1);
      return runBackgroundAutoCapture(tab);
    });
  bgCaptureChain = job;
  return job;
}

async function handleQuickScanCommand() {
  const scanRes = await handleScanHIS(null, 'manual');
  if (!scanRes.ok || !scanRes.text?.trim()) {
    const tab = await findTargetTabForScan(null);
    await notifyTab(tab?.id, scanRes.error || 'Không tìm thấy bảng xét nghiệm trên trang này', true);
    return;
  }

  const stored = await chrome.storage.local.get(SHARED_SETTINGS_KEY);
  const settings = stored?.[SHARED_SETTINGS_KEY] || {};
  const abbrMap = await getAbbrMapForBackground();

  if (settings.mergeEnabled !== false) {
    const res = await upsertMergeInBackground(scanRes.text.trim(), scanRes.meta, settings, abbrMap, true);
    if (!res.plain) {
      await notifyTab(scanRes.tabId, 'Không có chỉ số hợp lệ để gộp', true);
      return;
    }
    const copied = await copyTextReliable(res.plain, scanRes.tabId);
    await notifyTab(
      scanRes.tabId,
      copied ? `✓ Đã gộp ${res.label} (${res.count} phiếu) & copy` : 'Đã gộp nhưng không copy được',
      !copied
    );
    return;
  }

  const rows = CLS.parseInputToRows(scanRes.text);
  const picked = CLS.filterRows(rows, settings?.mergeFilter || 'main');
  const { plain, count } = CLS.formatRows(picked, settings, abbrMap);

  if (!plain) {
    await notifyTab(scanRes.tabId, 'Không có chỉ số hợp lệ để tóm tắt', true);
    return;
  }

  const copied = await copyTextReliable(plain, scanRes.tabId);
  await notifyTab(
    scanRes.tabId,
    copied ? `✓ Đã quét & copy (${count} chỉ số)` : 'Đã quét xong nhưng không copy được',
    !copied
  );
}

async function handleCopyMergedCommand(targetTabId = null) {
  const stored = await chrome.storage.local.get([SHARED_SETTINGS_KEY, MERGE_SESSION_KEY]);
  const settings = stored?.[SHARED_SETTINGS_KEY] || {};
  const sheets = Array.isArray(stored?.[MERGE_SESSION_KEY]?.sheets)
    ? stored[MERGE_SESSION_KEY].sheets
    : [];

  let tabId = targetTabId;
  if (!tabId) {
    const tab = await findTargetTabForScan(null);
    tabId = tab?.id || null;
  }

  if (!sheets.length) {
    await notifyTab(tabId, 'Chưa có phiếu nào trong bộ gộp', true);
    return { ok: false };
  }

  const abbrMap = await getAbbrMapForBackground();
  const { plain } = CLS.formatMergedSheets(sheets, settings, abbrMap);
  if (!plain) {
    await notifyTab(tabId, 'Không có chỉ số nào khớp bộ lọc hiện tại', true);
    return { ok: false };
  }

  const copied = await copyTextReliable(plain, tabId);
  await notifyTab(
    tabId,
    copied ? `✓ Đã copy lại bộ gộp (${sheets.length} phiếu)` : 'Không thể copy vào clipboard',
    !copied
  );
  return { ok: copied };
}

async function handleClearMergeCommand(targetTabId = null) {
  const stored = await chrome.storage.local.get(MERGE_SESSION_KEY);
  const prevCount = Array.isArray(stored?.[MERGE_SESSION_KEY]?.sheets)
    ? stored[MERGE_SESSION_KEY].sheets.length
    : 0;

  await chrome.storage.local.set({
    [MERGE_SESSION_KEY]: {
      patient: { id: '', name: '', contextKey: '' },
      sheets: [],
      updatedAt: Date.now()
    }
  });
  await refreshMergeBadge();

  let tabId = targetTabId;
  if (!tabId) {
    const tab = await findTargetTabForScan(null);
    tabId = tab?.id || null;
  }
  const msg = prevCount > 0
    ? `✓ Đã xóa sạch bộ gộp (${prevCount} phiếu)`
    : 'Bộ gộp đang trống';
  await notifyTab(tabId, msg, false);
  return { ok: true, cleared: prevCount };
}

chrome.commands.onCommand.addListener((command) => {
  if (command === 'quick-scan-copy') {
    handleQuickScanCommand().catch(() => {});
  } else if (command === 'clear-merge-session') {
    handleClearMergeCommand().catch(() => {});
  }
});

async function buildMergedPreviewPayload() {
  const stored = await chrome.storage.local.get([SHARED_SETTINGS_KEY, MERGE_SESSION_KEY]);
  const settings = stored?.[SHARED_SETTINGS_KEY] || {};
  const session = stored?.[MERGE_SESSION_KEY] || { patient: { id: '', name: '' }, sheets: [] };
  const sheets = Array.isArray(session.sheets) ? session.sheets : [];
  const abbrMap = await getAbbrMapForBackground();
  const { plain } = CLS.formatMergedSheets(sheets, settings, abbrMap);

  return {
    ok: true,
    plain,
    patient: session.patient || { id: '', name: '' },
    sheets: sheets.map((s) => {
      const rows = CLS.parseInputToRows(s.rawText);
      const isImg = s.label === 'CĐHA' || s.label === 'TDCN';
      return {
        label: s.label,
        serviceName: s.serviceName || s.label,
        displayName: isImg ? (rows[0]?.cleanName || s.label) : s.label,
        resultTime: s.resultTime || '',
        count: isImg ? 0 : rows.length
      };
    })
  };
}

async function handleRemoveSheetCommand(index, targetTabId = null) {
  const stored = await chrome.storage.local.get([SHARED_SETTINGS_KEY, MERGE_SESSION_KEY]);
  const settings = stored?.[SHARED_SETTINGS_KEY] || {};
  const session = stored?.[MERGE_SESSION_KEY] || { patient: { id: '', name: '', contextKey: '' }, sheets: [] };
  const sheets = Array.isArray(session.sheets) ? [...session.sheets] : [];
  const idx = parseInt(index, 10);

  if (isNaN(idx) || idx < 0 || idx >= sheets.length) {
    return buildMergedPreviewPayload();
  }

  const [removed] = sheets.splice(idx, 1);
  const nextPatient = sheets.length ? session.patient : { id: '', name: '', contextKey: '' };
  await chrome.storage.local.set({
    [MERGE_SESSION_KEY]: { patient: nextPatient, sheets, updatedAt: Date.now() }
  });
  await refreshMergeBadge();

  const payload = await buildMergedPreviewPayload();
  if (payload.plain) {
    await copyTextReliable(payload.plain, targetTabId);
  }
  await notifyTab(
    targetTabId,
    sheets.length
      ? `✓ Đã bỏ ${removed?.label || 'phiếu'} — còn ${sheets.length} phiếu & copy lại`
      : '✓ Đã xóa sạch bộ gộp',
    false
  );
  return payload;
}

async function handleTogglePauseCommand(targetTabId = null) {
  const stored = await chrome.storage.local.get(CAPTURE_PAUSED_KEY);
  const nextPaused = !Boolean(stored?.[CAPTURE_PAUSED_KEY]);
  await chrome.storage.local.set({ [CAPTURE_PAUSED_KEY]: nextPaused });
  await refreshMergeBadge();

  let tabId = targetTabId;
  if (!tabId) {
    const tab = await findTargetTabForScan(null);
    tabId = tab?.id || null;
  }
  await notifyTab(
    tabId,
    nextPaused ? '⏸ Tạm dừng tự động gộp' : '▶ Bật tự động gộp',
    false
  );
  return { ok: true, paused: nextPaused };
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || msg.target === 'offscreen') return;

  if (msg.type === 'CLS_BG_AUTO_CAPTURE') {
    handleBackgroundAutoCapture(sender?.tab, Boolean(msg.forceWait))
      .then((res) => sendResponse(res))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }

  if (msg.type === 'CLS_TOGGLE_PAUSE') {
    handleTogglePauseCommand(sender?.tab?.id || null)
      .then((res) => sendResponse(res))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }

  if (msg.type === 'CLS_GET_MERGED_PREVIEW') {
    buildMergedPreviewPayload()
      .then((res) => sendResponse(res))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }

  if (msg.type === 'CLS_REMOVE_SHEET') {
    handleRemoveSheetCommand(msg.index, sender?.tab?.id || null)
      .then((res) => sendResponse(res))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }

  if (msg.type === 'CLS_COPY_MERGED') {
    handleCopyMergedCommand(sender?.tab?.id || null)
      .then((res) => sendResponse(res))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }

  if (msg.type === 'CLS_CLEAR_MERGE') {
    handleClearMergeCommand(sender?.tab?.id || null)
      .then((res) => sendResponse(res))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }

  if (msg.type === 'CLS_SCAN_HIS') {
    handleScanHIS(sender?.tab?.id, msg.mode || 'manual')
      .then((res) => sendResponse(res))
      .catch((err) => sendResponse({ ok: false, error: err?.message || String(err) }));
    return true;
  }

  if (msg.type === 'CLS_COPY_TEXT' && msg.text) {
    handleCopyInActiveTab(sender?.tab?.id, msg.text)
      .then((res) => sendResponse(res))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }

  if (msg.type === 'CLS_INSERT_HIS' && msg.text) {
    handleInsertToHIS(sender?.tab?.id, msg.text)
      .then((res) => sendResponse(res))
      .catch((err) => sendResponse({ ok: false, error: err?.message || String(err) }));
    return true;
  }
});