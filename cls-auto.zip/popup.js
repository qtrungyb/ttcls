/* =========================================================
   POPUP & SIDE PANEL — Tóm tắt nhanh + Tự quét + Gộp phiếu
   ========================================================= */
(function() {
  const CLS_WEB_URL = 'https://qtrungyb.github.io/ttcls/';
  const ABBR_ENDPOINT = 'https://tomtatcls-default-rtdb.asia-southeast1.firebasedatabase.app/abbreviations.json';
  const MERGE_SESSION_KEY = 'cls_merge_session_v1';
  const SHARED_SETTINGS_KEY = 'cls_shared_settings';
  const ABBR_CACHE_KEY = 'cls_abbr_cache';
  const MERGE_PRIORITY = {
    CTM: 1,
    SHM: 2,
    ĐGĐ: 3,
    XN: 4,
    MD: 5,
    ĐM: 6,
    KM: 7,
    VS: 8,
    TPTNT: 9,
    CĐHA: 10,
    TDCN: 11
  };

  const SPECIAL_NAMES = [
    'Số lượng hồng cầu', 'Huyết sắc tố', 'Hematocrit',
    'Số lượng tiểu cầu', 'Số lượng bạch cầu', 'Tỷ lệ bạch cầu GR'
  ];

  const DEFAULT_ABBR_MAP = {
    'Số lượng hồng cầu': 'HC',
    'Huyết sắc tố': 'Hb',
    'Hematocrit': 'HTC',
    'Số lượng tiểu cầu': 'TC',
    'Số lượng bạch cầu': 'BC',
    'Tỷ lệ bạch cầu GR': 'N%'
  };

  const SEP_INNER = { T3: ': ', T4: ': ', TSH: ': ', Tg: ': ' };
  const FORMAT_ORDER = ['comma', 'semicolon', 'newline'];
  const FORMAT_LABELS = { comma: ',', semicolon: ';', newline: '↵' };

  const RANGE_REGEX = /(\d+[.,]?\d*)\s*[-–]\s*(\d+[.,]?\d*)/;
  const LE_REGEX = /(<=|≤)\s*(\d+[.,]?\d*)/;
  const L_REGEX = /<\s*(\d+[.,]?\d*)/;
  const GE_REGEX = /(>=|≥)\s*(\d+[.,]?\d*)/;
  const G_REGEX = />\s*(\d+[.,]?\d*)/;

  const NAME_PREFIX_REGEX = /^\([^)]+\)\s*(.*)/;
  const INNER_PAREN_REGEX = /\s*\(([^)]+)\)/g;
  const VALID_KEEP_TEXT = ['inr', 'bệnh/ chứng r', 'bệnh/chứng r', 'alt', 'ast'];

  const state = {
    autoScanEnabled: localStorage.getItem('pop_autoScan') !== 'false',
    mergeEnabled: localStorage.getItem('pop_mergeEnabled') !== 'false',
    lastAutoScannedText: '',
    isScanning: false,
    autoScanTimer: null,
    abbrMap: loadCachedAbbr(),
    showUnit: localStorage.getItem('pop_showUnit') === 'true',
    showAbbr: localStorage.getItem('pop_showAbbr') !== 'false',
    copyFormat: localStorage.getItem('pop_copyFormat') || 'comma',
    darkMode: localStorage.getItem('pop_darkMode') === 'true',
    rows: [],
    selectedIndices: [],
    activeFilter: localStorage.getItem('pop_activeFilter') || 'main',
    currentMeta: null,
    mergePatient: { id: '', name: '' },
    mergedSheets: []
  };

  const el = {
	insertBtn: document.getElementById('insertBtn'),
    autoScanBtn: document.getElementById('autoScanBtn'),
    mergeBtn: document.getElementById('mergeBtn'),
    mergeBar: document.getElementById('mergeBar'),
    patientBadge: document.getElementById('patientBadge'),
    mergeChips: document.getElementById('mergeChips'),
    clearMergeBtn: document.getElementById('clearMergeBtn'),
    sidePanelBtn: document.getElementById('sidePanelBtn'),
    dataInput: document.getElementById('dataInput'),
    summaryText: document.getElementById('summaryText'),
    outputCard: document.getElementById('outputCard'),
    totalCount: document.getElementById('totalCount'),
    abnCount: document.getElementById('abnCount'),
    scanBadge: document.getElementById('scanBadge'),
    rescanBtn: document.getElementById('rescanBtn'),
    clearBtn: document.getElementById('clearBtn'),
    formatBtn: document.getElementById('formatBtn'),
    unitBtn: document.getElementById('unitBtn'),
    abbrBtn: document.getElementById('abbrBtn'),
    copyBtn: document.getElementById('copyBtn'),
    openFullBtn: document.getElementById('openFullBtn'),
    themeBtn: document.getElementById('themeBtn'),
    filterBtns: document.querySelectorAll('.filter-btn'),
    toast: document.getElementById('toast')
  };

  function loadCachedAbbr() {
    try {
      const raw = localStorage.getItem('pop_abbr_cache');
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed && Object.keys(parsed).length) return parsed;
      }
    } catch {}
    return { ...DEFAULT_ABBR_MAP };
  }
  
  function sortMergedSheets() {
    state.mergedSheets.sort((a, b) => {
      const pa = MERGE_PRIORITY[a.label] || 5;
      const pb = MERGE_PRIORITY[b.label] || 5;
      return pa - pb;
    });
  }


  function applyMergeSessionPayload(saved) {
    if (!saved || typeof saved !== 'object') return;
    state.mergePatient = {
      id: saved.patient?.id || '',
      name: saved.patient?.name || ''
    };
    state.mergedSheets = Array.isArray(saved.sheets)
      ? saved.sheets
          .map((s) => {
            const rows = parseInputToRows(s.rawText);
            if (!rows.length) return null;
            return {
              key: s.key,
              label: getShortServiceLabel(s.serviceName, rows),
              serviceName: s.serviceName || '',
              resultTime: s.resultTime || '',
              rawText: s.rawText,
              rows
            };
          })
          .filter(Boolean)
      : [];
    sortMergedSheets();
  }

  function saveMergeSession() {
    const payload = {
      patient: state.mergePatient,
      sheets: state.mergedSheets.map((s) => ({
        key: s.key,
        label: s.label,
        serviceName: s.serviceName,
        resultTime: s.resultTime,
        rawText: s.rawText
      })),
      updatedAt: Date.now()
    };
    try { localStorage.setItem(MERGE_SESSION_KEY, JSON.stringify(payload)); } catch {}
    try { chrome.storage?.local?.set({ [MERGE_SESSION_KEY]: payload }); } catch {}
  }

  function loadMergeSession() {
    try {
      const raw = localStorage.getItem(MERGE_SESSION_KEY);
      if (raw) applyMergeSessionPayload(JSON.parse(raw));
    } catch {}
  }

  async function syncAbbrFromFirebase() {
    try {
      const res = await fetch(ABBR_ENDPOINT, { cache: 'no-store' });
      if (!res.ok) return;
      const data = await res.json();
      if (!data) return;

      const map = {};
      Object.values(data).forEach((item) => {
        if (item && item.raw != null && item.short != null) {
          map[item.raw] = item.short;
        }
      });

      if (Object.keys(map).length) {
        state.abbrMap = map;
        localStorage.setItem('pop_abbr_cache', JSON.stringify(map));
		chrome.storage?.local?.set({ [ABBR_CACHE_KEY]: map });
        if (hasAnyData()) renderSummary();
      }
    } catch {}
  }

  function escapeHtml(str) {
    return str ? String(str).replace(/[&<>]/g, (m) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[m])) : '';
  }

  function escapeAttr(str) {
    return str ? String(str).replace(/[&<>"']/g, (m) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[m])) : '';
  }

  function parseNumber(str) {
    const m = str && String(str).replace(/,/g, '.').replace(/\s+/g, '').match(/-?\d+(?:\.\d+)?/);
    return m ? parseFloat(m[0]) : NaN;
  }

  function cleanName(raw) {
    if (!raw) return '';
    const str = raw.trim().replace(/^["']|["']$/g, '');
    const m = str.match(NAME_PREFIX_REGEX);
    let name = m ? m[1].trim() : str;
    name = name.replace(INNER_PAREN_REGEX, (match, inner) =>
      VALID_KEEP_TEXT.includes(inner.trim().toLowerCase()) ? match : ''
    );
    return name.trim();
  }

  function getStatus(valStr, rangeStr) {
    const val = parseNumber(valStr);
    if (isNaN(val) || !rangeStr) return 'unknown';
    let m;
    if ((m = rangeStr.match(RANGE_REGEX))) return (val < parseNumber(m[1]) || val > parseNumber(m[2])) ? 'abnormal' : 'normal';
    if ((m = rangeStr.match(LE_REGEX)))    return val <= parseNumber(m[2]) ? 'normal' : 'abnormal';
    if ((m = rangeStr.match(L_REGEX)))     return val <  parseNumber(m[1]) ? 'normal' : 'abnormal';
    if ((m = rangeStr.match(GE_REGEX)))    return val >= parseNumber(m[2]) ? 'normal' : 'abnormal';
    if ((m = rangeStr.match(G_REGEX)))     return val >  parseNumber(m[1]) ? 'normal' : 'abnormal';
    return 'unknown';
  }

  function parseInputToRows(input) {
    const lines = String(input || '').split(/\r?\n/);
    const rows = [];
    for (const line of lines) {
      if (!line.trim()) continue;
      const cols = line.split('\t').map((c) => c.trim()).filter(Boolean);
      if (cols.length >= 3 && /^\d+$/.test(cols[0])) {
        const refRange = cols[3] || '';
        rows.push({
          stt: cols[0],
          cleanName: cleanName(cols[1]),
          value: cols[2],
          refRange,
          unit: cols[4] || '',
          _status: getStatus(cols[2], refRange)
        });
      }
    }
    return rows;
  }

  function getRowOverlapRatio(rowsA, rowsB) {
    if (!rowsA?.length || !rowsB?.length) return 0;
    const setA = new Set(rowsA.map((r) => r.cleanName.toLowerCase()));
    const setB = new Set(rowsB.map((r) => r.cleanName.toLowerCase()));
    let common = 0;
    for (const name of setA) {
      if (setB.has(name)) common++;
    }
    return common / Math.min(setA.size, setB.size);
  }

  function getShortServiceLabel(serviceName, rows) {
    if ((rows || []).length > 0 && rows.every((r) => r.refRange === 'CĐHA' || r.refRange === 'TDCN')) {
      return rows[0].refRange;
    }
    const names = (rows || []).map((r) => r.cleanName.toLowerCase()).join(' | ');
    const svc = String(serviceName || '').toLowerCase();

    // 1. TPTNT — ưu tiên kiểm tra trước vì nước tiểu cũng có "Hồng cầu", "Bạch cầu", "Glucose"
    if (
      svc.includes('nước tiểu') || svc.includes('tptnt') ||
      names.includes('tỷ trọng') ||
      names.includes('urobilinogen') ||
      names.includes('nitrit') ||
      names.includes('cetonic') ||
      names.includes('keton')
    ) return 'TPTNT';

    // 2. CTM — các chỉ số đặc trưng huyết học
    if (
      names.includes('huyết sắc tố') ||
      names.includes('hematocrit') ||
      names.includes('số lượng hồng cầu') ||
      names.includes('số lượng tiểu cầu') ||
      names.includes('số lượng bạch cầu') ||
      names.includes('thể tích trung bình hồng cầu') ||
      /\bmcv\b|\bmch\b|\bmchc\b/.test(names)
    ) return 'CTM';

    // 3. Đông máu
    if (
      /\binr\b|\baptt\b/.test(names) ||
      names.includes('fibrinogen') ||
      names.includes('prothrombin') ||
      names.includes('d-dimer')
    ) return 'ĐM';

    // 4. Khí máu
    if (/\bpco2\b|\bpo2\b|\bhco3\b/.test(names)) return 'KM';

    // 5. Miễn dịch (MD) — bao gồm Ferritin, hormone, marker, test nhanh...
    if (
      svc.includes('miễn dịch') ||
      names.includes('ferritin') ||
      names.includes('procalcitonin') ||
      names.includes('troponin') ||
      names.includes('pro-bnp') ||
      names.includes('hbsag') ||
      names.includes('anti-hbs') ||
      names.includes('anti-hcv') ||
      names.includes('dengue') ||
      names.includes('beta-hcg') ||
      names.includes('cortisol') ||
      names.includes('insulin') ||
      names.includes('vitamin d') ||
      names.includes('vitamin b12') ||
      names.includes('acid folic') ||
      /\b(tsh|ft3|ft4|afp|cea|psa|hiv|ns1|ige|igg|igm|aso|anti-ccp)\b/.test(names)
    ) return 'MD';

    // 6. Sinh hóa máu (SHM) — bao gồm Sắt huyết thanh, gan, thận, mỡ máu, CRP...
    if (
      names.includes('sgpt') ||
      names.includes('sgot') ||
      /\b(alt|ast|ggt|crp|hdl|ldl|ldh|ck-mb|alp|tibc|nh3)\b/.test(names) ||
      names.includes('creatinin') ||
      names.includes('urê') ||
      names.includes('urea') ||
      names.includes('glucose') ||
      names.includes('cholesterol') ||
      names.includes('triglycerid') ||
      names.includes('acid uric') ||
      names.includes('hba1c') ||
      names.includes('amylase') ||
      names.includes('lipase') ||
      names.includes('albumin') ||
      names.includes('protein') ||
      names.includes('bilirubin') ||
      names.includes('sắt huyết thanh') ||
      names.includes('định lượng sắt') ||
      names.includes('transferrin') ||
      names.includes('canxi') ||
      names.includes('calcium') ||
      names.includes('magie') ||
      names.includes('phospho') ||
      names.includes('lactat')
    ) return 'SHM';

    // 7. Điện giải đồ (khi làm phiếu riêng)
    if (
      svc.includes('điện giải') ||
      names.includes('natri') ||
      names.includes('kali') ||
      names.includes('clo') ||
      names.includes('na+') ||
      names.includes('k+')
    ) return 'ĐGĐ';

    // 8. Dự phòng theo tên Loại dịch vụ của HIS
    if (svc.includes('huyết học') || svc.includes('công thức máu') || svc.includes('tế bào máu')) return 'CTM';
    if (svc.includes('hóa sinh') || svc.includes('sinh hóa')) return 'SHM';
    if (svc.includes('đông máu')) return 'ĐM';
    if (svc.includes('vi sinh')) return 'VS';
    if (svc.includes('khí máu')) return 'KM';
    if (serviceName) {
      return serviceName.replace(/^xét nghiệm\s+/i, '').trim().slice(0, 18);
    }

    return 'XN';
  }

  function makeSheetKey(label, resultTime, rows) {
    const grp = String(label || 'XN').toLowerCase().trim();
    const time = String(resultTime || '').trim();
    const sig = (rows || []).slice(0, 3).map((r) => r.cleanName.toLowerCase()).join('|');
    return [grp, time, sig].filter(Boolean).join('__');
  }

  function filterRowsForSheet(rows, filterName) {
    if (filterName === 'main') {
      const main = rows.filter((r) => SPECIAL_NAMES.includes(r.cleanName));
      return main.length ? main : rows;
    }
    if (filterName === 'abnormal') {
      return rows.filter((r) => r._status === 'abnormal');
    }
    return rows;
  }

  function computeSummary(rows) {
    const htmlParts = [];
    const plainParts = [];
    const isAllConclusion = rows.length > 0 && rows.every((r) => r.refRange === 'CĐHA' || r.refRange === 'TDCN');
    for (const r of rows) {
      if (!r.value || r.value.trim().toLowerCase() === '- neg') continue;
      const isConclusion = r.refRange === 'CĐHA' || r.refRange === 'TDCN';
      const isAbbr = state.showAbbr && state.abbrMap[r.cleanName];
      const name = isAbbr ? state.abbrMap[r.cleanName] : r.cleanName;
      const sep = isConclusion ? ': ' : (SEP_INNER[name] || ' ');
      const unit = (!isConclusion && state.showUnit && r.unit) ? ' ' + r.unit : '';
      const ev = escapeHtml(r.value);
      const hv = r._status === 'abnormal' ? `<span class="abnormal-value">${ev}</span>` : ev;
      const nHtml = isAbbr
        ? `<span class="abbr-tip" title="${escapeAttr(r.cleanName)}">${escapeHtml(name)}</span>`
        : escapeHtml(name);

      htmlParts.push(`${nHtml}${sep}${hv}${escapeHtml(unit)}`);
      plainParts.push(`${name}${sep}${r.value}${unit}`);
    }
    const sepHtml  = state.copyFormat === 'newline' ? '<br>' : (isAllConclusion || state.copyFormat === 'semicolon' ? '; ' : ', ');
    const sepPlain = state.copyFormat === 'newline' ? '\n'   : (isAllConclusion || state.copyFormat === 'semicolon' ? '; ' : ', ');
    return { html: htmlParts.join(sepHtml), plain: plainParts.join(sepPlain) };
  }

  function hasAnyData() {
    return state.mergeEnabled ? state.mergedSheets.length > 0 : state.rows.length > 0;
  }

  let toastTimer = null;
  function showToast(msg, ms = 1800) {
    el.toast.textContent = msg;
    el.toast.classList.remove('hidden');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.toast.classList.add('hidden'), ms);
  }

  function copyText(text) {
    if (!text) return Promise.resolve(false);

    if (!document.hasFocus()) {
      return new Promise((resolve) => {
        chrome.runtime.sendMessage({ type: 'CLS_COPY_TEXT', text }, (res) => {
          void chrome.runtime.lastError;
          resolve(Boolean(res && res.ok));
        });
      });
    }

    if (navigator.clipboard && navigator.clipboard.writeText) {
      return navigator.clipboard.writeText(text).then(() => true).catch(() => fallbackCopy(text));
    }
    return Promise.resolve(fallbackCopy(text));
  }

  function fallbackCopy(text) {
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.style.cssText = 'position:fixed;top:-9999px;';
    ta.setAttribute('readonly', '');
    document.body.appendChild(ta);
    ta.select();
    let ok = false;
    try { ok = document.execCommand('copy'); } catch {}
    ta.remove();
    return ok;
  }

  function renderMergeBar() {
    if (!el.mergeBar) return;
    el.mergeBar.classList.toggle('hidden', !state.mergeEnabled);
    if (!state.mergeEnabled) return;

    const p = state.mergePatient;
    if (p.name && p.id) {
      el.patientBadge.textContent = `BN: ${p.name} (${p.id})`;
    } else if (p.name) {
      el.patientBadge.textContent = `BN: ${p.name}`;
    } else if (p.id) {
      el.patientBadge.textContent = `Mã BN: ${p.id}`;
    } else {
      el.patientBadge.textContent = 'Chế độ gộp nhiều phiếu XN';
    }

    el.clearMergeBtn.classList.toggle('hidden', state.mergedSheets.length === 0);

    if (!state.mergedSheets.length) {
      el.mergeChips.innerHTML = '<span class="merge-empty">Chuyển lần lượt các phiếu xét nghiệm trên HIS để tự động gộp…</span>';
      return;
    }

    el.mergeChips.innerHTML = state.mergedSheets.map((s, idx) => {
      const tip = [s.serviceName || s.label, s.resultTime].filter(Boolean).join(' — ');
      const isImg = s.label === 'CĐHA' || s.label === 'TDCN';
      const chipLabel = isImg && s.rows[0]?.cleanName ? s.rows[0].cleanName.slice(0, 22) : s.label;
      const chipCount = isImg ? '' : `<span class="merge-chip-count">(${s.rows.length})</span>`;
      return `
        <span class="merge-chip" data-idx="${idx}" title="${escapeAttr(tip)}">
          <span>${escapeHtml(chipLabel)}</span>
          ${chipCount}
          <button class="merge-chip-del" data-del="${idx}" title="Bỏ phiếu này">&times;</button>
        </span>
      `;
    }).join('');
  }

  function updateToolbarUI() {
    document.body.classList.toggle('dark-mode', state.darkMode);
    el.formatBtn.textContent = FORMAT_LABELS[state.copyFormat] || ',';
    el.unitBtn.classList.toggle('active', state.showUnit);
    el.abbrBtn.classList.toggle('active', state.showAbbr);
    if (el.autoScanBtn) {
      el.autoScanBtn.classList.toggle('active', state.autoScanEnabled);
    }
    if (el.mergeBtn) {
      el.mergeBtn.classList.toggle('active', state.mergeEnabled);
      el.mergeBtn.textContent = state.mergeEnabled && state.mergedSheets.length
        ? `Gộp (${state.mergedSheets.length})`
        : 'Gộp';
    }
    const activeData = hasAnyData();
    el.filterBtns.forEach((btn) => {
	  btn.classList.toggle('active', btn.dataset.filter === state.activeFilter);
	});
    renderMergeBar();
  }

  function buildCurrentOutput() {
    if (state.mergeEnabled) {
      const total = state.mergedSheets.reduce((sum, s) => sum + s.rows.length, 0);
      const abnTotal = state.mergedSheets.reduce(
        (sum, s) => sum + s.rows.filter((r) => r._status === 'abnormal').length,
        0
      );

      if (!state.mergedSheets.length) {
        return { total: 0, abnTotal: 0, html: '', plain: '', emptyMsg: 'Chưa có phiếu nào được gộp' };
      }

      const outputGroups = [];
      for (const sheet of state.mergedSheets) {
        const filtered = filterRowsForSheet(sheet.rows, state.activeFilter);
        if (!filtered.length) continue;

        const target = outputGroups.find(
          (g) => g.label === sheet.label && getRowOverlapRatio(g.rows, filtered) === 0
        );
        if (target) {
          target.rows.push(...filtered);
        } else {
          outputGroups.push({ label: sheet.label, rows: [...filtered] });
        }
      }

      const htmlBlocks = [];
      const plainBlocks = [];

      for (const group of outputGroups) {
        if (group.label === 'CĐHA' || group.label === 'TDCN') {
          for (const r of group.rows) {
            const { html, plain } = computeSummary([r]);
            if (!plain) continue;
            const colonPos = html.indexOf(': ');
            const formattedHtml = colonPos !== -1
              ? `<span class="grp-label">- ${html.slice(0, colonPos + 1)}</span>${html.slice(colonPos + 1)}`
              : `<span class="grp-label">-</span> ${html}`;
            htmlBlocks.push(formattedHtml);
            plainBlocks.push(`- ${plain}`);
          }
          continue;
        }

        const { html, plain } = computeSummary(group.rows);
        if (!plain) continue;

        if (state.copyFormat === 'newline') {
          htmlBlocks.push(`<span class="grp-label">- ${escapeHtml(group.label)}:</span><br>${html}`);
          plainBlocks.push(`- ${group.label}:\n${plain}`);
        } else {
          htmlBlocks.push(`<span class="grp-label">- ${escapeHtml(group.label)}:</span> ${html}`);
          plainBlocks.push(`- ${group.label}: ${plain}`);
        }
      }

      return {
        total,
        abnTotal,
        html: htmlBlocks.join('<br>'),
        plain: plainBlocks.join('\n'),
        emptyMsg: 'Không có chỉ số nào trong nhóm lọc này'
      };
    }

    // Chế độ đơn phiếu
    const selected = state.rows.filter((_, i) => state.selectedIndices.includes(i));
    const abnTotal = state.rows.filter((r) => r._status === 'abnormal').length;
    if (!state.rows.length) {
      return { total: 0, abnTotal: 0, html: '', plain: '', emptyMsg: 'Chưa có dữ liệu xét nghiệm' };
    }
    if (!selected.length) {
      return { total: state.rows.length, abnTotal, html: '', plain: '', emptyMsg: 'Không có chỉ số nào trong nhóm lọc này' };
    }
    const { html, plain } = computeSummary(selected);
    return {
      total: state.rows.length,
      abnTotal,
      html,
      plain,
      emptyMsg: 'Không có chỉ số hợp lệ'
    };
  }

  function renderSummary() {
    const out = buildCurrentOutput();
    el.totalCount.textContent = out.total;
    el.abnCount.textContent = out.abnTotal;
    el.summaryText.innerHTML = out.html || `<div class="empty-state">${out.emptyMsg}</div>`;
    return out.plain;
  }

  function applyFilter(filterName) {
    state.activeFilter = filterName;
	localStorage.setItem('pop_activeFilter', state.activeFilter);
    if (!state.mergeEnabled) {
      if (filterName === 'main') {
        const main = state.rows.reduce((a, r, i) => SPECIAL_NAMES.includes(r.cleanName) ? [...a, i] : a, []);
        state.selectedIndices = main.length ? main : state.rows.map((_, i) => i);
        if (!main.length) state.activeFilter = 'all';
      } else if (filterName === 'abnormal') {
        state.selectedIndices = state.rows.reduce((a, r, i) => r._status === 'abnormal' ? [...a, i] : a, []);
      } else {
        state.selectedIndices = state.rows.map((_, i) => i);
      }
    }
    updateToolbarUI();
    return renderSummary();
  }

  function upsertMergedSheet(rawText, rows, meta) {
    let patientSwitched = false;
    const incomingId = meta?.patientId || '';
    const incomingName = meta?.patientName || '';

    // Nếu phát hiện đổi sang bệnh nhân mới -> tự động làm mới bộ gộp để chống nhầm lẫn
    if (incomingId && state.mergePatient.id && incomingId !== state.mergePatient.id) {
      state.mergedSheets = [];
      patientSwitched = true;
    }

    if (incomingId) state.mergePatient.id = incomingId;
    if (incomingName) state.mergePatient.name = incomingName;

    const label = getShortServiceLabel(meta?.serviceName, rows);
    const resultTime = (meta?.resultTime || '').trim();
    const key = makeSheetKey(label, resultTime, rows);

    const sheetObj = {
      key,
      label,
      serviceName: meta?.serviceName || label,
      resultTime,
      rawText,
      rows
    };

    // 1. Trùng y hệt nội dung -> cập nhật tại chỗ, không nhân đôi
    let existingIdx = state.mergedSheets.findIndex((s) => s.rawText === rawText);

    // 2. Chỉ ghi đè khi CÙNG nhóm + CÙNG mốc thời gian (hoặc chưa có thời gian) + TRÙNG >= 50% tên chỉ số
    //    Các phiếu khác chỉ số (VD: Sắt huyết thanh vs Gan-Thận) luôn được giữ cả hai
    const isGenericImgName = (n) => /^(cđha|tdcn|siêu âm|chụp x-quang|x-quang|điện tim|nội soi)$/i.test(String(n || '').trim());

    if (existingIdx === -1) {
      existingIdx = state.mergedSheets.findIndex((s) => {
        if (s.label !== label) return false;
        if (s.resultTime && resultTime && s.resultTime !== resultTime) return false;
        if (label === 'CĐHA' || label === 'TDCN') {
          const oldName = s.rows[0]?.cleanName || '';
          const newName = rows[0]?.cleanName || '';
          if (!oldName || !newName || isGenericImgName(newName)) return false;
          return oldName.toLowerCase() === newName.toLowerCase();
        }
        return getRowOverlapRatio(s.rows, rows) >= 0.5;
      });
    }

    const isUpdated = existingIdx !== -1;
    if (isUpdated) {
      if (!sheetObj.resultTime && state.mergedSheets[existingIdx].resultTime) {
        sheetObj.resultTime = state.mergedSheets[existingIdx].resultTime;
        sheetObj.key = makeSheetKey(label, sheetObj.resultTime, rows);
      }
      state.mergedSheets[existingIdx] = sheetObj;
    } else {
      state.mergedSheets.push(sheetObj);
    }

    sortMergedSheets();
    saveMergeSession();
    return { label, isUpdated, patientSwitched, count: state.mergedSheets.length };
  }

  function summarize(autoCopy = true, toastLabel = 'Đã tóm tắt & sao chép', meta = null) {
    const rawText = el.dataInput.value.trim();
    const rows = parseInputToRows(rawText);
    state.rows = rows;
    state.currentMeta = meta || state.currentMeta;

    if (!rows.length) {
      state.selectedIndices = [];
      updateToolbarUI();
      renderSummary();
      return;
    }

    const main = rows.reduce((a, r, i) => SPECIAL_NAMES.includes(r.cleanName) ? [...a, i] : a, []);
    state.selectedIndices = main.length ? main : rows.map((_, i) => i);

    let finalToast = toastLabel;
    if (state.mergeEnabled) {
      const info = upsertMergedSheet(rawText, rows, meta);
      if (info.patientSwitched) {
        finalToast = `Đổi BN ${state.mergePatient.name || state.mergePatient.id} — gộp mới (${info.label})`;
      } else if (info.isUpdated) {
        finalToast = `Đã cập nhật ${info.label} (${info.count} phiếu) & copy`;
      } else {
        finalToast = `Đã gộp +${info.label} (${info.count} phiếu) & copy`;
      }
    } else {
      state.activeFilter = main.length ? 'main' : 'all';
    }

    updateToolbarUI();
    const plain = renderSummary();

    if (autoCopy && plain) {
      copyText(plain).then(() => showToast(finalToast, 2200));
    }

    el.outputCard.classList.add('pulse');
    setTimeout(() => el.outputCard.classList.remove('pulse'), 450);
  }

  function scanFromCurrentTab(mode = 'auto', silent = false) {
    if (state.isScanning) return;
    if (silent && document.hidden) return;

    state.isScanning = true;
    if (!silent) {
      el.rescanBtn.disabled = true;
      el.scanBadge.className = 'scan-badge';
      el.scanBadge.textContent = 'Đang quét…';
    }

    chrome.runtime.sendMessage({ type: 'CLS_SCAN_HIS', mode }, (res) => {
      state.isScanning = false;
      if (!silent) el.rescanBtn.disabled = false;

      if (chrome.runtime.lastError || !res || !res.ok || res.empty || !res.text?.trim()) {
        if (!silent) {
          el.scanBadge.classList.add('hidden');
          if (mode === 'manual') {
            showToast(res?.error || 'Không tìm thấy bảng xét nghiệm trên trang này', 2600);
          } else if (!hasAnyData()) {
            el.dataInput.focus();
          }
        }
        return;
      }

      const normalized = res.text.trim();
      const alreadyMerged = state.mergeEnabled && state.mergedSheets.some((s) => s.rawText === normalized);
      if (silent && (normalized === state.lastAutoScannedText || alreadyMerged)) {
        state.lastAutoScannedText = normalized;
        return;
      }

      state.lastAutoScannedText = normalized;
      el.dataInput.value = normalized;
      el.scanBadge.className = 'scan-badge ok';
      el.scanBadge.textContent = state.mergeEnabled ? 'Đã gộp' : 'Đã quét';
      summarize(true, 'Đã quét & sao chép', res.meta || null);
    });
  }
  function saveSharedSettings() {
  const payload = {
    showUnit: state.showUnit,
    showAbbr: state.showAbbr,
    copyFormat: state.copyFormat,
    darkMode: state.darkMode,
    themeMode: state.darkMode ? 'dark' : 'light',
    mergeEnabled: state.mergeEnabled,
    mergeFilter: state.activeFilter
  };
  try {
    chrome.storage?.local?.set({ [SHARED_SETTINGS_KEY]: payload });
  } catch {}
}

function applySharedSettings(s) {
  if (!s || typeof s !== 'object') return;
  let changed = false;

  if (typeof s.showUnit === 'boolean' && s.showUnit !== state.showUnit) {
    state.showUnit = s.showUnit;
    localStorage.setItem('pop_showUnit', state.showUnit);
    changed = true;
  }
  if (typeof s.showAbbr === 'boolean' && s.showAbbr !== state.showAbbr) {
    state.showAbbr = s.showAbbr;
    localStorage.setItem('pop_showAbbr', state.showAbbr);
    changed = true;
  }
  if (s.copyFormat && FORMAT_ORDER.includes(s.copyFormat) && s.copyFormat !== state.copyFormat) {
    state.copyFormat = s.copyFormat;
    localStorage.setItem('pop_copyFormat', state.copyFormat);
    changed = true;
  }
  if (typeof s.darkMode === 'boolean' && s.darkMode !== state.darkMode) {
    state.darkMode = s.darkMode;
    localStorage.setItem('pop_darkMode', state.darkMode);
    changed = true;
  }
  if (typeof s.mergeEnabled === 'boolean' && s.mergeEnabled !== state.mergeEnabled) {
    state.mergeEnabled = s.mergeEnabled;
    localStorage.setItem('pop_mergeEnabled', state.mergeEnabled);
    changed = true;
  }
  if (s.mergeFilter && ['main', 'abnormal', 'all'].includes(s.mergeFilter) && s.mergeFilter !== state.activeFilter) {
    state.activeFilter = s.mergeFilter;
	localStorage.setItem('pop_activeFilter', state.activeFilter);
    changed = true;
  }
  if (changed) {
    updateToolbarUI();
    if (hasAnyData()) renderSummary();
  }
}
  // --- Sự kiện ---
  let inputTimer = null;
  el.dataInput.addEventListener('input', () => {
    clearTimeout(inputTimer);
    inputTimer = setTimeout(() => summarize(true, 'Đã tóm tắt & sao chép', null), 250);
  });

  el.rescanBtn.addEventListener('click', () => scanFromCurrentTab('manual', false));

  el.clearBtn.addEventListener('click', () => {
    el.dataInput.value = '';
    el.scanBadge.classList.add('hidden');
    state.rows = [];
    state.selectedIndices = [];
    state.lastAutoScannedText = '';
    if (state.mergeEnabled) {
      state.mergedSheets = [];
      state.mergePatient = { id: '', name: '' };
      saveMergeSession();
    }
    updateToolbarUI();
    renderSummary();
    el.dataInput.focus();
  });

  if (el.mergeBtn) {
    el.mergeBtn.addEventListener('click', () => {
      state.mergeEnabled = !state.mergeEnabled;
      localStorage.setItem('pop_mergeEnabled', state.mergeEnabled);
      saveSharedSettings(); // 👈 Thêm

      if (state.mergeEnabled) {
        // Giữ luôn phiếu đang hiển thị hiện tại đưa vào danh sách gộp
        if (state.rows.length && el.dataInput.value.trim()) {
          upsertMergedSheet(el.dataInput.value.trim(), state.rows, state.currentMeta);
        }
        showToast('Bật chế độ Gộp nhiều phiếu XN', 2000);
      } else {
        showToast('Tắt chế độ Gộp phiếu', 1600);
      }

      updateToolbarUI();
      const plain = renderSummary();
      if (plain) copyText(plain);
    });
  }

  if (el.clearMergeBtn) {
    el.clearMergeBtn.addEventListener('click', () => {
      state.mergedSheets = [];
      state.mergePatient = { id: '', name: '' };
      state.lastAutoScannedText = '';
      saveMergeSession();
      updateToolbarUI();
      renderSummary();
      showToast('Đã xóa danh sách gộp');
    });
  }

  if (el.mergeChips) {
    el.mergeChips.addEventListener('click', (e) => {
      const delBtn = e.target.closest('[data-del]');
      if (delBtn) {
        const idx = parseInt(delBtn.dataset.del, 10);
        if (!isNaN(idx)) {
          state.mergedSheets.splice(idx, 1);
          if (!state.mergedSheets.length) state.mergePatient = { id: '', name: '' };
          saveMergeSession();
          updateToolbarUI();
          const plain = renderSummary();
          if (plain) copyText(plain).then(() => showToast('Đã bỏ phiếu & sao chép lại'));
        }
        return;
      }

      const chip = e.target.closest('.merge-chip');
      if (chip) {
        const idx = parseInt(chip.dataset.idx, 10);
        const sheet = state.mergedSheets[idx];
        if (sheet) el.dataInput.value = sheet.rawText;
      }
    });
  }

  el.formatBtn.addEventListener('click', () => {
    const idx = (FORMAT_ORDER.indexOf(state.copyFormat) + 1) % FORMAT_ORDER.length;
    state.copyFormat = FORMAT_ORDER[idx];
    localStorage.setItem('pop_copyFormat', state.copyFormat);
    saveSharedSettings();
    updateToolbarUI();
    const plain = renderSummary();
    if (plain) copyText(plain).then(() => showToast('Đã đổi định dạng & sao chép'));
  });

  el.unitBtn.addEventListener('click', () => {
    state.showUnit = !state.showUnit;
    localStorage.setItem('pop_showUnit', state.showUnit);
    saveSharedSettings();
    updateToolbarUI();
    const plain = renderSummary();
    if (plain) copyText(plain);
  });

  el.abbrBtn.addEventListener('click', () => {
    state.showAbbr = !state.showAbbr;
    localStorage.setItem('pop_showAbbr', state.showAbbr);
    saveSharedSettings();
    updateToolbarUI();
    const plain = renderSummary();
    if (plain) copyText(plain);
  });

  el.copyBtn.addEventListener('click', () => {
    const plain = buildCurrentOutput().plain;
    if (!plain) return showToast('Chưa có dữ liệu để copy');
    copyText(plain).then(() => {
      el.copyBtn.classList.add('copied');
      el.copyBtn.textContent = 'Đã copy';
      showToast('Đã sao chép kết quả');
      setTimeout(() => {
        el.copyBtn.classList.remove('copied');
        el.copyBtn.textContent = 'Copy';
      }, 1500);
    });
  });
  if (el.insertBtn) {
  el.insertBtn.addEventListener('click', () => {
    const plain = buildCurrentOutput().plain;
    if (!plain) return showToast('Chưa có dữ liệu để chèn');

    chrome.runtime.sendMessage({ type: 'CLS_INSERT_HIS', text: plain }, (res) => {
      if (chrome.runtime.lastError || !res || !res.ok) {
        copyText(plain);
        showToast(res?.error || 'Hãy đặt con trỏ vào ô HIS (đã copy dự phòng)', 3200);
        return;
      }
      el.insertBtn.classList.add('inserted');
      el.insertBtn.textContent = 'Đã chèn';
      showToast('Đã chèn trực tiếp vào HIS');
      setTimeout(() => {
        el.insertBtn.classList.remove('inserted');
        el.insertBtn.textContent = 'Chèn';
      }, 1500);
    });
  });
}
  el.filterBtns.forEach((btn) => {
    btn.addEventListener('click', () => {
      const plain = applyFilter(btn.dataset.filter);
      saveSharedSettings(); // 👈 Thêm
      if (plain) copyText(plain).then(() => showToast('Đã cập nhật & sao chép'));
    });
  });

  el.themeBtn.addEventListener('click', () => {
    state.darkMode = !state.darkMode;
    localStorage.setItem('pop_darkMode', state.darkMode);
    saveSharedSettings();
    updateToolbarUI();
  });

  el.openFullBtn.addEventListener('click', async () => {
    const tabs = await chrome.tabs.query({ url: 'https://qtrungyb.github.io/*' });
    if (tabs.length) {
      await chrome.tabs.update(tabs[0].id, { active: true });
      await chrome.windows.update(tabs[0].windowId, { focused: true });
    } else {
      await chrome.tabs.create({ url: CLS_WEB_URL });
    }
    if (!isSidePanel) window.close();
  });

  document.addEventListener('keydown', (e) => {
    const cmd = e.ctrlKey || e.metaKey;
    if (cmd && e.key === 'Enter') {
      e.preventDefault();
      summarize(true);
    } else if (cmd && e.shiftKey && (e.key === 'C' || e.key === 'c')) {
      e.preventDefault();
      el.copyBtn.click();
    }
  });

  // --- Hỗ trợ đồng thời Popup và Thanh bên (Side Panel) ---
  const isSidePanel = new URLSearchParams(window.location.search).get('mode') === 'sidepanel';
  if (isSidePanel) {
    document.body.classList.add('sidepanel-mode');
  }

  function stopSidePanelAutoScan() {
    if (state.autoScanTimer != null) {
      clearInterval(state.autoScanTimer);
      state.autoScanTimer = null;
    }
  }

  function startSidePanelAutoScan(immediate = false) {
    stopSidePanelAutoScan();
    if (!isSidePanel || !state.autoScanEnabled) return;
    state.autoScanTimer = setInterval(() => scanFromCurrentTab('auto', true), 1200);
    if (immediate) scanFromCurrentTab('auto', true);
  }

  if (el.autoScanBtn) {
    el.autoScanBtn.addEventListener('click', () => {
      state.autoScanEnabled = !state.autoScanEnabled;
      localStorage.setItem('pop_autoScan', state.autoScanEnabled);
      updateToolbarUI();

      if (state.autoScanEnabled) {
        state.lastAutoScannedText = '';
        startSidePanelAutoScan(true);
        showToast('Đã bật tự động quét HIS');
      } else {
        stopSidePanelAutoScan();
        showToast('Đã tắt tự động quét HIS');
      }
    });
  }

  if (isSidePanel) {
    if (chrome.tabs && chrome.tabs.onActivated) {
      chrome.tabs.onActivated.addListener(() => {
        if (state.autoScanEnabled) scanFromCurrentTab('auto', true);
      });
    }
    window.addEventListener('unload', stopSidePanelAutoScan);
  }

  let currentWindowId = null;
  if (chrome.windows && chrome.windows.getCurrent) {
    chrome.windows.getCurrent((w) => {
      if (w) currentWindowId = w.id;
    });
  }

  if (el.sidePanelBtn) {
    el.sidePanelBtn.addEventListener('click', () => {
      if (!chrome.sidePanel || !chrome.sidePanel.open || currentWindowId == null) {
        return showToast('Chuột phải vào biểu tượng tiện ích → Mở bảng điều khiển bên', 3500);
      }
      chrome.sidePanel.open({ windowId: currentWindowId })
        .then(() => window.close())
        .catch((err) => showToast('Không mở được thanh bên: ' + err.message, 3000));
    });
  }

  // --- Khởi chạy ---
  loadMergeSession();
  updateToolbarUI();
  renderSummary();
  syncAbbrFromFirebase();

  // Đồng bộ cài đặt + danh sách gộp dùng chung với Background & trang Web
  try {
    chrome.storage.local.get([SHARED_SETTINGS_KEY, MERGE_SESSION_KEY], (data) => {
      const savedSettings = data?.[SHARED_SETTINGS_KEY];
      if (savedSettings && typeof savedSettings.mergeEnabled === 'boolean') {
        applySharedSettings(savedSettings);
      } else {
        if (savedSettings) applySharedSettings(savedSettings);
        saveSharedSettings();
      }
      if (data?.[MERGE_SESSION_KEY]) {
        applyMergeSessionPayload(data[MERGE_SESSION_KEY]);
        updateToolbarUI();
        renderSummary();
      }
    });
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== 'local') return;
      if (changes[SHARED_SETTINGS_KEY]?.newValue) {
        applySharedSettings(changes[SHARED_SETTINGS_KEY].newValue);
      }
      if (changes[MERGE_SESSION_KEY]?.newValue) {
        applyMergeSessionPayload(changes[MERGE_SESSION_KEY].newValue);
        updateToolbarUI();
        renderSummary();
      }
    });
  } catch {}

  scanFromCurrentTab('auto', false);
  if (isSidePanel && state.autoScanEnabled) {
    startSidePanelAutoScan(false);
  }
})();