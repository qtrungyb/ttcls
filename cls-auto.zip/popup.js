/* =========================================================
   POPUP — Thu gọn Dán dữ liệu + Kết quả + Tự động quét HIS
   ========================================================= */
(function() {
  const CLS_WEB_URL = 'https://qtrungyb.github.io/ttcls/';
  const ABBR_ENDPOINT = 'https://tomtatcls-default-rtdb.asia-southeast1.firebasedatabase.app/abbreviations.json';

  const SPECIAL_NAMES = [
    'Số lượng hồng cầu', 'Huyết sắc tố', 'Hematocrit',
    'Số lượng tiểu cầu', 'Số lượng bạch cầu', 'Tỷ lệ bạch cầu GR'
  ];

  const DEFAULT_ABBR_MAP = {
    'Số lượng hồng cầu': 'HC',
    'Huyết sắc tố': 'Hb',
    'Hematocrit': 'HTC',
    'Số lượng tiểu cầu': 'TC',
    'Số lượng bạch cầu': 'BC',
    'Tỷ lệ bạch cầu GR': 'N%'
  };

  const SEP_INNER = { T3: ': ', T4: ': ', TSH: ': ', Tg: ': ' };
  const FORMAT_ORDER = ['comma', 'semicolon', 'newline'];
  const FORMAT_LABELS = { comma: ',', semicolon: ';', newline: '↵' };

  const RANGE_REGEX = /(\d+[.,]?\d*)\s*[-–]\s*(\d+[.,]?\d*)/;
  const LE_REGEX = /(<=|≤)\s*(\d+[.,]?\d*)/;
  const L_REGEX = /<\s*(\d+[.,]?\d*)/;
  const GE_REGEX = /(>=|≥)\s*(\d+[.,]?\d*)/;
  const G_REGEX = />\s*(\d+[.,]?\d*)/;

  const NAME_PREFIX_REGEX = /^\([^)]+\)\s*(.*)/;
  const INNER_PAREN_REGEX = /\s*\(([^)]+)\)/g;
  const VALID_KEEP_TEXT = ['inr', 'bệnh/ chứng r', 'bệnh/chứng r', 'alt', 'ast'];

  const state = {
    abbrMap: loadCachedAbbr(),
    showUnit: localStorage.getItem('pop_showUnit') === 'true',
    showAbbr: localStorage.getItem('pop_showAbbr') !== 'false',
    copyFormat: localStorage.getItem('pop_copyFormat') || 'comma',
    darkMode: localStorage.getItem('pop_darkMode') === 'true',
    rows: [],
    selectedIndices: [],
    activeFilter: 'main'
  };

  const el = {
    dataInput: document.getElementById('dataInput'),
    summaryText: document.getElementById('summaryText'),
    outputCard: document.getElementById('outputCard'),
    totalCount: document.getElementById('totalCount'),
    abnCount: document.getElementById('abnCount'),
    scanBadge: document.getElementById('scanBadge'),
    rescanBtn: document.getElementById('rescanBtn'),
    clearBtn: document.getElementById('clearBtn'),
    formatBtn: document.getElementById('formatBtn'),
    unitBtn: document.getElementById('unitBtn'),
    abbrBtn: document.getElementById('abbrBtn'),
    copyBtn: document.getElementById('copyBtn'),
    openFullBtn: document.getElementById('openFullBtn'),
    themeBtn: document.getElementById('themeBtn'),
    filterBtns: document.querySelectorAll('.filter-btn'),
    toast: document.getElementById('toast')
  };

  function loadCachedAbbr() {
    try {
      const raw = localStorage.getItem('pop_abbr_cache');
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed && Object.keys(parsed).length) return parsed;
      }
    } catch {}
    return { ...DEFAULT_ABBR_MAP };
  }

  async function syncAbbrFromFirebase() {
    try {
      const res = await fetch(ABBR_ENDPOINT, { cache: 'no-store' });
      if (!res.ok) return;
      const data = await res.json();
      if (!data) return;

      const map = {};
      Object.values(data).forEach((item) => {
        if (item && item.raw != null && item.short != null) {
          map[item.raw] = item.short;
        }
      });

      if (Object.keys(map).length) {
        state.abbrMap = map;
        localStorage.setItem('pop_abbr_cache', JSON.stringify(map));
        if (state.rows.length) renderSummary();
      }
    } catch {}
  }

  function escapeHtml(str) {
    return str ? String(str).replace(/[&<>]/g, (m) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[m])) : '';
  }

  function escapeAttr(str) {
    return str ? String(str).replace(/[&<>"']/g, (m) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[m])) : '';
  }

  function parseNumber(str) {
    const m = str && String(str).replace(/,/g, '.').replace(/\s+/g, '').match(/-?\d+(?:\.\d+)?/);
    return m ? parseFloat(m[0]) : NaN;
  }

  function cleanName(raw) {
    if (!raw) return '';
    const str = raw.trim().replace(/^["']|["']$/g, '');
    const m = str.match(NAME_PREFIX_REGEX);
    let name = m ? m[1].trim() : str;
    name = name.replace(INNER_PAREN_REGEX, (match, inner) =>
      VALID_KEEP_TEXT.includes(inner.trim().toLowerCase()) ? match : ''
    );
    return name.trim();
  }

  function getStatus(valStr, rangeStr) {
    const val = parseNumber(valStr);
    if (isNaN(val) || !rangeStr) return 'unknown';
    let m;
    if ((m = rangeStr.match(RANGE_REGEX))) return (val < parseNumber(m[1]) || val > parseNumber(m[2])) ? 'abnormal' : 'normal';
    if ((m = rangeStr.match(LE_REGEX)))    return val <= parseNumber(m[2]) ? 'normal' : 'abnormal';
    if ((m = rangeStr.match(L_REGEX)))     return val <  parseNumber(m[1]) ? 'normal' : 'abnormal';
    if ((m = rangeStr.match(GE_REGEX)))    return val >= parseNumber(m[2]) ? 'normal' : 'abnormal';
    if ((m = rangeStr.match(G_REGEX)))     return val >  parseNumber(m[1]) ? 'normal' : 'abnormal';
    return 'unknown';
  }

  function parseInputToRows(input) {
    const lines = String(input || '').split(/\r?\n/);
    const rows = [];
    for (const line of lines) {
      if (!line.trim()) continue;
      const cols = line.split('\t').map((c) => c.trim()).filter(Boolean);
      if (cols.length >= 3 && /^\d+$/.test(cols[0])) {
        const refRange = cols[3] || '';
        rows.push({
          stt: cols[0],
          cleanName: cleanName(cols[1]),
          value: cols[2],
          refRange,
          unit: cols[4] || '',
          _status: getStatus(cols[2], refRange)
        });
      }
    }
    return rows;
  }

  function computeSummary(rows) {
    const htmlParts = [];
    const plainParts = [];
    for (const r of rows) {
      if (!r.value || r.value.trim().toLowerCase() === '- neg') continue;
      const isAbbr = state.showAbbr && state.abbrMap[r.cleanName];
      const name = isAbbr ? state.abbrMap[r.cleanName] : r.cleanName;
      const sep = SEP_INNER[name] || ' ';
      const unit = (state.showUnit && r.unit) ? ' ' + r.unit : '';
      const ev = escapeHtml(r.value);
      const hv = r._status === 'abnormal' ? `<span class="abnormal-value">${ev}</span>` : ev;
      const nHtml = isAbbr
        ? `<span class="abbr-tip" title="${escapeAttr(r.cleanName)}">${escapeHtml(name)}</span>`
        : escapeHtml(name);

      htmlParts.push(`${nHtml}${sep}${hv}${escapeHtml(unit)}`);
      plainParts.push(`${name}${sep}${r.value}${unit}`);
    }
    const sepHtml  = state.copyFormat === 'newline' ? '<br>' : (state.copyFormat === 'semicolon' ? '; ' : ', ');
    const sepPlain = state.copyFormat === 'newline' ? '\n'   : (state.copyFormat === 'semicolon' ? '; ' : ', ');
    return { html: htmlParts.join(sepHtml), plain: plainParts.join(sepPlain) };
  }

  let toastTimer = null;
  function showToast(msg, ms = 1800) {
    el.toast.textContent = msg;
    el.toast.classList.remove('hidden');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.toast.classList.add('hidden'), ms);
  }

  function copyText(text) {
    if (!text) return Promise.resolve(false);
    if (navigator.clipboard && navigator.clipboard.writeText) {
      return navigator.clipboard.writeText(text).then(() => true).catch(() => fallbackCopy(text));
    }
    return Promise.resolve(fallbackCopy(text));
  }

  function fallbackCopy(text) {
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.style.cssText = 'position:fixed;top:-9999px;';
    ta.setAttribute('readonly', '');
    document.body.appendChild(ta);
    ta.select();
    let ok = false;
    try { ok = document.execCommand('copy'); } catch {}
    ta.remove();
    return ok;
  }

  function updateToolbarUI() {
    document.body.classList.toggle('dark-mode', state.darkMode);
    el.formatBtn.textContent = FORMAT_LABELS[state.copyFormat] || ',';
    el.unitBtn.classList.toggle('active', state.showUnit);
    el.abbrBtn.classList.toggle('active', state.showAbbr);
    el.filterBtns.forEach((btn) => {
      btn.classList.toggle('active', btn.dataset.filter === state.activeFilter && state.rows.length > 0);
    });
  }

  function applyFilter(filterName) {
    state.activeFilter = filterName;
    if (filterName === 'main') {
      const main = state.rows.reduce((a, r, i) => SPECIAL_NAMES.includes(r.cleanName) ? [...a, i] : a, []);
      state.selectedIndices = main.length ? main : state.rows.map((_, i) => i);
      if (!main.length) state.activeFilter = 'all';
    } else if (filterName === 'abnormal') {
      state.selectedIndices = state.rows.reduce((a, r, i) => r._status === 'abnormal' ? [...a, i] : a, []);
    } else {
      state.selectedIndices = state.rows.map((_, i) => i);
    }
    updateToolbarUI();
    renderSummary();
  }

  function renderSummary() {
    const selected = state.rows.filter((_, i) => state.selectedIndices.includes(i));
    const abnTotal = state.rows.filter((r) => r._status === 'abnormal').length;
    el.totalCount.textContent = state.rows.length;
    el.abnCount.textContent = abnTotal;

    if (!state.rows.length) {
      el.summaryText.innerHTML = '<div class="empty-state">Chưa có dữ liệu xét nghiệm</div>';
      return '';
    }
    if (!selected.length) {
      el.summaryText.innerHTML = '<div class="empty-state">Không có chỉ số nào trong nhóm lọc này</div>';
      return '';
    }

    const { html, plain } = computeSummary(selected);
    el.summaryText.innerHTML = html || '<div class="empty-state">Không có chỉ số hợp lệ</div>';
    return plain;
  }

  function summarize(autoCopy = true, toastLabel = 'Đã tóm tắt & sao chép') {
    const rows = parseInputToRows(el.dataInput.value);
    state.rows = rows;

    if (!rows.length) {
      state.selectedIndices = [];
      updateToolbarUI();
      renderSummary();
      return;
    }

    const main = rows.reduce((a, r, i) => SPECIAL_NAMES.includes(r.cleanName) ? [...a, i] : a, []);
    state.activeFilter = main.length ? 'main' : 'all';
    state.selectedIndices = main.length ? main : rows.map((_, i) => i);

    updateToolbarUI();
    const plain = renderSummary();

    if (autoCopy && plain) {
      copyText(plain).then(() => showToast(toastLabel));
    }

    el.outputCard.classList.add('pulse');
    setTimeout(() => el.outputCard.classList.remove('pulse'), 450);
  }

  function scanFromCurrentTab(mode = 'auto') {
    el.rescanBtn.disabled = true;
    el.scanBadge.className = 'scan-badge';
    el.scanBadge.textContent = 'Đang quét…';

    chrome.runtime.sendMessage({ type: 'CLS_SCAN_HIS', mode }, (res) => {
      el.rescanBtn.disabled = false;

      if (chrome.runtime.lastError || !res || !res.ok || res.empty || !res.text?.trim()) {
        el.scanBadge.classList.add('hidden');
        if (mode === 'manual') {
          showToast(res?.error || 'Không tìm thấy bảng xét nghiệm trên trang này', 2600);
        } else {
          el.dataInput.focus();
        }
        return;
      }

      el.dataInput.value = res.text.trim();
      el.scanBadge.className = 'scan-badge ok';
      el.scanBadge.textContent = 'Đã quét HIS';
      summarize(true, 'Đã tự động quét & sao chép');
    });
  }

  // --- Sự kiện ---
  let inputTimer = null;
  el.dataInput.addEventListener('input', () => {
    clearTimeout(inputTimer);
    inputTimer = setTimeout(() => summarize(true), 250);
  });

  el.rescanBtn.addEventListener('click', () => scanFromCurrentTab('manual'));

  el.clearBtn.addEventListener('click', () => {
    el.dataInput.value = '';
    el.scanBadge.classList.add('hidden');
    state.rows = [];
    state.selectedIndices = [];
    updateToolbarUI();
    renderSummary();
    el.dataInput.focus();
  });

  el.formatBtn.addEventListener('click', () => {
    const idx = (FORMAT_ORDER.indexOf(state.copyFormat) + 1) % FORMAT_ORDER.length;
    state.copyFormat = FORMAT_ORDER[idx];
    localStorage.setItem('pop_copyFormat', state.copyFormat);
    updateToolbarUI();
    const plain = renderSummary();
    if (plain) copyText(plain).then(() => showToast('Đã đổi định dạng & sao chép'));
  });

  el.unitBtn.addEventListener('click', () => {
    state.showUnit = !state.showUnit;
    localStorage.setItem('pop_showUnit', state.showUnit);
    updateToolbarUI();
    const plain = renderSummary();
    if (plain) copyText(plain);
  });

  el.abbrBtn.addEventListener('click', () => {
    state.showAbbr = !state.showAbbr;
    localStorage.setItem('pop_showAbbr', state.showAbbr);
    updateToolbarUI();
    const plain = renderSummary();
    if (plain) copyText(plain);
  });

  el.copyBtn.addEventListener('click', () => {
    const selected = state.rows.filter((_, i) => state.selectedIndices.includes(i));
    const { plain } = computeSummary(selected);
    if (!plain) return showToast('Chưa có dữ liệu để copy');
    copyText(plain).then(() => {
      el.copyBtn.classList.add('copied');
      el.copyBtn.textContent = 'Đã copy';
      showToast('Đã sao chép kết quả');
      setTimeout(() => {
        el.copyBtn.classList.remove('copied');
        el.copyBtn.textContent = 'Copy';
      }, 1500);
    });
  });

  el.filterBtns.forEach((btn) => {
    btn.addEventListener('click', () => {
      if (!state.rows.length) return;
      applyFilter(btn.dataset.filter);
      const selected = state.rows.filter((_, i) => state.selectedIndices.includes(i));
      const { plain } = computeSummary(selected);
      if (plain) copyText(plain).then(() => showToast('Đã cập nhật & sao chép'));
    });
  });

  el.themeBtn.addEventListener('click', () => {
    state.darkMode = !state.darkMode;
    localStorage.setItem('pop_darkMode', state.darkMode);
    updateToolbarUI();
  });

  el.openFullBtn.addEventListener('click', async () => {
    const tabs = await chrome.tabs.query({ url: 'https://qtrungyb.github.io/*' });
    if (tabs.length) {
      await chrome.tabs.update(tabs[0].id, { active: true });
      await chrome.windows.update(tabs[0].windowId, { focused: true });
    } else {
      await chrome.tabs.create({ url: CLS_WEB_URL });
    }
    window.close();
  });

  document.addEventListener('keydown', (e) => {
    const cmd = e.ctrlKey || e.metaKey;
    if (cmd && e.key === 'Enter') {
      e.preventDefault();
      summarize(true);
    } else if (cmd && e.shiftKey && (e.key === 'C' || e.key === 'c')) {
      e.preventDefault();
      el.copyBtn.click();
    }
  });

  // --- Khởi chạy ngay khi bấm mở Popup ---
  updateToolbarUI();
  syncAbbrFromFirebase();
  scanFromCurrentTab('auto');
})();