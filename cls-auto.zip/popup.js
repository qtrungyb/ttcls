/* =========================================================
   POPUP & SIDE PANEL — Tóm tắt nhanh + Tự quét + Gộp phiếu
   ========================================================= */
(function() {
  const CLS = globalThis.CLSShared;
  const {
    CLS_WEB_URL,
    ABBR_ENDPOINT,
    MERGE_SESSION_KEY,
    SHARED_SETTINGS_KEY,
    ABBR_CACHE_KEY,
    SPECIAL_NAMES,
    DEFAULT_ABBR
  } = CLS;

  const FORMAT_ORDER = ['comma', 'semicolon', 'newline'];
  const FORMAT_LABELS = { comma: ',', semicolon: ';', newline: '↵' };

  const state = {
    autoScanEnabled: localStorage.getItem('pop_autoScan') !== 'false',
    mergeEnabled: localStorage.getItem('pop_mergeEnabled') !== 'false',
    lastAutoScannedText: '',
    isScanning: false,
    autoScanTimer: null,
    abbrMap: loadCachedAbbr(),
    showUnit: localStorage.getItem('pop_showUnit') === 'true',
    showAbbr: localStorage.getItem('pop_showAbbr') !== 'false',
    copyFormat: localStorage.getItem('pop_copyFormat') || 'comma',
    darkMode: localStorage.getItem('pop_darkMode') === 'true',
    rows: [],
    selectedIndices: [],
    activeFilter: localStorage.getItem('pop_activeFilter') || 'main',
    currentMeta: null,
    mergePatient: { id: '', name: '', contextKey: '' },
    mergedSheets: []
  };

  const el = {
    insertBtn: document.getElementById('insertBtn'),
    autoScanBtn: document.getElementById('autoScanBtn'),
    mergeBtn: document.getElementById('mergeBtn'),
    mergeBar: document.getElementById('mergeBar'),
    patientBadge: document.getElementById('patientBadge'),
    mergeChips: document.getElementById('mergeChips'),
    clearMergeBtn: document.getElementById('clearMergeBtn'),
    sidePanelBtn: document.getElementById('sidePanelBtn'),
    dataInput: document.getElementById('dataInput'),
    summaryText: document.getElementById('summaryText'),
    outputCard: document.getElementById('outputCard'),
    totalCount: document.getElementById('totalCount'),
    abnCount: document.getElementById('abnCount'),
    scanBadge: document.getElementById('scanBadge'),
    rescanBtn: document.getElementById('rescanBtn'),
    clearBtn: document.getElementById('clearBtn'),
    formatBtn: document.getElementById('formatBtn'),
    unitBtn: document.getElementById('unitBtn'),
    abbrBtn: document.getElementById('abbrBtn'),
    copyBtn: document.getElementById('copyBtn'),
    openFullBtn: document.getElementById('openFullBtn'),
    themeBtn: document.getElementById('themeBtn'),
    filterBtns: document.querySelectorAll('.filter-btn'),
    toast: document.getElementById('toast')
  };

  function loadCachedAbbr() {
    try {
      const raw = localStorage.getItem('pop_abbr_cache');
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed && Object.keys(parsed).length) return parsed;
      }
    } catch {}
    return { ...DEFAULT_ABBR };
  }

  function applyMergeSessionPayload(saved) {
    if (!saved || typeof saved !== 'object') return;
    state.mergePatient = {
      id: saved.patient?.id || '',
      name: saved.patient?.name || '',
      contextKey: saved.patient?.contextKey || (saved.patient?.id ? 'pid:' + saved.patient.id : '')
    };
    state.mergedSheets = Array.isArray(saved.sheets)
      ? saved.sheets
          .map((s) => {
            const rows = CLS.parseInputToRows(s.rawText);
            if (!rows.length) return null;
            return {
              key: s.key,
              label: CLS.getShortServiceLabel(s.serviceName, rows),
              serviceName: s.serviceName || '',
              resultTime: s.resultTime || '',
              rawText: s.rawText,
              rows
            };
          })
          .filter(Boolean)
      : [];
    CLS.sortSheets(state.mergedSheets);
  }

  function saveMergeSession() {
    const payload = {
      patient: state.mergePatient,
      sheets: state.mergedSheets.map((s) => ({
        key: s.key,
        label: s.label,
        serviceName: s.serviceName,
        resultTime: s.resultTime,
        rawText: s.rawText
      })),
      updatedAt: Date.now()
    };
    try { localStorage.setItem(MERGE_SESSION_KEY, JSON.stringify(payload)); } catch {}
    try { chrome.storage?.local?.set({ [MERGE_SESSION_KEY]: payload }); } catch {}
  }

  function loadMergeSession() {
    try {
      const raw = localStorage.getItem(MERGE_SESSION_KEY);
      if (raw) applyMergeSessionPayload(JSON.parse(raw));
    } catch {}
  }

  async function syncAbbrFromFirebase() {
    try {
      const res = await fetch(ABBR_ENDPOINT, { cache: 'no-store' });
      if (!res.ok) return;
      const data = await res.json();
      if (!data) return;

      const map = {};
      Object.values(data).forEach((item) => {
        if (item && item.raw != null && item.short != null) {
          map[item.raw] = item.short;
        }
      });

      if (Object.keys(map).length) {
        state.abbrMap = map;
        localStorage.setItem('pop_abbr_cache', JSON.stringify(map));
        chrome.storage?.local?.set({ [ABBR_CACHE_KEY]: map });
        if (hasAnyData()) renderSummary();
      }
    } catch {}
  }

  function getFormatSettings() {
    return {
      showUnit: state.showUnit,
      showAbbr: state.showAbbr,
      copyFormat: state.copyFormat,
      mergeFilter: state.activeFilter
    };
  }

  function hasAnyData() {
    return state.mergeEnabled ? state.mergedSheets.length > 0 : state.rows.length > 0;
  }

  let toastTimer = null;
  function showToast(msg, ms = 1800) {
    el.toast.textContent = msg;
    el.toast.classList.remove('hidden');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.toast.classList.add('hidden'), ms);
  }

  function copyText(text) {
    if (!text) return Promise.resolve(false);

    if (!document.hasFocus()) {
      return new Promise((resolve) => {
        chrome.runtime.sendMessage({ type: 'CLS_COPY_TEXT', text }, (res) => {
          void chrome.runtime.lastError;
          resolve(Boolean(res && res.ok));
        });
      });
    }

    if (navigator.clipboard && navigator.clipboard.writeText) {
      return navigator.clipboard.writeText(text).then(() => true).catch(() => fallbackCopy(text));
    }
    return Promise.resolve(fallbackCopy(text));
  }

  function fallbackCopy(text) {
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.style.cssText = 'position:fixed;top:-9999px;';
    ta.setAttribute('readonly', '');
    document.body.appendChild(ta);
    ta.select();
    let ok = false;
    try { ok = document.execCommand('copy'); } catch {}
    ta.remove();
    return ok;
  }

  function renderMergeBar() {
    if (!el.mergeBar) return;
    el.mergeBar.classList.toggle('hidden', !state.mergeEnabled);
    if (!state.mergeEnabled) return;

    const p = state.mergePatient;
    if (p.name && p.id) el.patientBadge.textContent = `BN: ${p.name} (${p.id})`;
    else if (p.name) el.patientBadge.textContent = `BN: ${p.name}`;
    else if (p.id) el.patientBadge.textContent = `Mã BN: ${p.id}`;
    else el.patientBadge.textContent = 'Chế độ gộp nhiều phiếu XN';

    el.clearMergeBtn.classList.toggle('hidden', state.mergedSheets.length === 0);

    if (!state.mergedSheets.length) {
      el.mergeChips.innerHTML = '<span class="merge-empty">Chuyển lần lượt các phiếu xét nghiệm trên HIS để tự động gộp…</span>';
      return;
    }

    el.mergeChips.innerHTML = state.mergedSheets.map((s, idx) => {
      const tip = [s.serviceName || s.label, s.resultTime].filter(Boolean).join(' — ');
      const isImg = s.label === 'CĐHA' || s.label === 'TDCN';
      const chipLabel = isImg && s.rows[0]?.cleanName ? s.rows[0].cleanName.slice(0, 22) : s.label;
      const chipCount = isImg ? '' : `<span class="merge-chip-count">(${s.rows.length})</span>`;
      return `
        <span class="merge-chip" data-idx="${idx}" title="${CLS.escapeAttr(tip)}">
          <span>${CLS.escapeHtml(chipLabel)}</span>
          ${chipCount}
          <button class="merge-chip-del" data-del="${idx}" title="Bỏ phiếu này">&times;</button>
        </span>
      `;
    }).join('');
  }

  function updateToolbarUI() {
    document.body.classList.toggle('dark-mode', state.darkMode);
    el.formatBtn.textContent = FORMAT_LABELS[state.copyFormat] || ',';
    el.unitBtn.classList.toggle('active', state.showUnit);
    el.abbrBtn.classList.toggle('active', state.showAbbr);
    if (el.autoScanBtn) el.autoScanBtn.classList.toggle('active', state.autoScanEnabled);
    if (el.mergeBtn) {
      el.mergeBtn.classList.toggle('active', state.mergeEnabled);
      el.mergeBtn.textContent = state.mergeEnabled && state.mergedSheets.length
        ? `Gộp (${state.mergedSheets.length})`
        : 'Gộp';
    }
    el.filterBtns.forEach((btn) => {
      btn.classList.toggle('active', btn.dataset.filter === state.activeFilter);
    });
    renderMergeBar();
  }

  function buildCurrentOutput() {
    if (state.mergeEnabled) {
      if (!state.mergedSheets.length) {
        return { total: 0, abnTotal: 0, html: '', plain: '', emptyMsg: 'Chưa có phiếu nào được gộp' };
      }
      const res = CLS.formatMergedSheets(state.mergedSheets, getFormatSettings(), state.abbrMap);
      return {
        ...res,
        emptyMsg: 'Không có chỉ số nào trong nhóm lọc này'
      };
    }

    const selected = state.rows.filter((_, i) => state.selectedIndices.includes(i));
    const abnTotal = state.rows.filter((r) => r._status === 'abnormal').length;
    if (!state.rows.length) {
      return { total: 0, abnTotal: 0, html: '', plain: '', emptyMsg: 'Chưa có dữ liệu xét nghiệm' };
    }
    if (!selected.length) {
      return { total: state.rows.length, abnTotal, html: '', plain: '', emptyMsg: 'Không có chỉ số nào trong nhóm lọc này' };
    }
    const { html, plain } = CLS.formatRows(selected, getFormatSettings(), state.abbrMap);
    return {
      total: state.rows.length,
      abnTotal,
      html,
      plain,
      emptyMsg: 'Không có chỉ số hợp lệ'
    };
  }

  function renderSummary() {
    const out = buildCurrentOutput();
    el.totalCount.textContent = out.total;
    el.abnCount.textContent = out.abnTotal;
    el.summaryText.innerHTML = out.html || `<div class="empty-state">${out.emptyMsg}</div>`;
    return out.plain;
  }

  function applyFilter(filterName) {
    state.activeFilter = filterName;
    localStorage.setItem('pop_activeFilter', state.activeFilter);
    if (!state.mergeEnabled) {
      if (filterName === 'main') {
        const main = state.rows.reduce((a, r, i) => SPECIAL_NAMES.includes(r.cleanName) ? [...a, i] : a, []);
        state.selectedIndices = main.length ? main : state.rows.map((_, i) => i);
        if (!main.length) state.activeFilter = 'all';
      } else if (filterName === 'abnormal') {
        state.selectedIndices = state.rows.reduce((a, r, i) => r._status === 'abnormal' ? [...a, i] : a, []);
      } else {
        state.selectedIndices = state.rows.map((_, i) => i);
      }
    }
    updateToolbarUI();
    return renderSummary();
  }

  function upsertMergedSheet(rawText, rows, meta) {
    let patientSwitched = false;
    const incomingId = meta?.patientId || '';
    const incomingName = meta?.patientName || '';
    const incomingKey = incomingId ? 'pid:' + incomingId : (meta?.contextKey || '');
    const currentKey = state.mergePatient.contextKey || (state.mergePatient.id ? 'pid:' + state.mergePatient.id : '');

    if (incomingKey && currentKey && incomingKey !== currentKey) {
      state.mergedSheets = [];
      state.mergePatient = { id: '', name: '', contextKey: '' };
      patientSwitched = true;
    }

    if (incomingId) state.mergePatient.id = incomingId;
    if (incomingName) state.mergePatient.name = incomingName;
    if (incomingKey) state.mergePatient.contextKey = incomingKey;

    const label = CLS.getShortServiceLabel(meta?.serviceName, rows);
    const resultTime = (meta?.resultTime || '').trim();
    const key = CLS.makeSheetKey(label, resultTime, rows);

    const sheetObj = {
      key,
      label,
      serviceName: meta?.serviceName || label,
      resultTime,
      rawText,
      rows
    };

    const existingIdx = CLS.findMatchingSheetIndex(state.mergedSheets, { rawText, label, resultTime, rows });
    const isUpdated = existingIdx !== -1;
    if (isUpdated) {
      if (!sheetObj.resultTime && state.mergedSheets[existingIdx].resultTime) {
        sheetObj.resultTime = state.mergedSheets[existingIdx].resultTime;
        sheetObj.key = CLS.makeSheetKey(label, sheetObj.resultTime, rows);
      }
      state.mergedSheets[existingIdx] = sheetObj;
    } else {
      state.mergedSheets.push(sheetObj);
    }

    CLS.sortSheets(state.mergedSheets);
    saveMergeSession();
    return { label, isUpdated, patientSwitched, count: state.mergedSheets.length };
  }

  function summarize(autoCopy = true, toastLabel = 'Đã tóm tắt & sao chép', meta = null) {
    const rawText = el.dataInput.value.trim();
    const rows = CLS.parseInputToRows(rawText);
    state.rows = rows;
    state.currentMeta = meta || state.currentMeta;

    if (!rows.length) {
      state.selectedIndices = [];
      updateToolbarUI();
      renderSummary();
      return;
    }

    const main = rows.reduce((a, r, i) => SPECIAL_NAMES.includes(r.cleanName) ? [...a, i] : a, []);
    state.selectedIndices = main.length ? main : rows.map((_, i) => i);

    let finalToast = toastLabel;
    if (state.mergeEnabled) {
      const info = upsertMergedSheet(rawText, rows, meta);
      if (info.patientSwitched) {
        finalToast = `Đổi BN ${state.mergePatient.name || state.mergePatient.id || 'mới'} — gộp mới (${info.label})`;
      } else if (info.isUpdated) {
        finalToast = `Đã cập nhật ${info.label} (${info.count} phiếu) & copy`;
      } else {
        finalToast = `Đã gộp +${info.label} (${info.count} phiếu) & copy`;
      }
    } else {
      state.activeFilter = main.length ? 'main' : 'all';
    }

    updateToolbarUI();
    const plain = renderSummary();

    if (autoCopy && plain) {
      copyText(plain).then(() => showToast(finalToast, 2200));
    }

    el.outputCard.classList.add('pulse');
    setTimeout(() => el.outputCard.classList.remove('pulse'), 450);
  }

  function scanFromCurrentTab(mode = 'auto', silent = false) {
    if (state.isScanning) return;
    if (silent && document.hidden) return;

    state.isScanning = true;
    if (!silent) {
      el.rescanBtn.disabled = true;
      el.scanBadge.className = 'scan-badge';
      el.scanBadge.textContent = 'Đang quét…';
    }

    chrome.runtime.sendMessage({ type: 'CLS_SCAN_HIS', mode }, (res) => {
      state.isScanning = false;
      if (!silent) el.rescanBtn.disabled = false;

      if (chrome.runtime.lastError || !res || !res.ok || res.empty || !res.text?.trim()) {
        if (!silent) {
          el.scanBadge.classList.add('hidden');
          if (mode === 'manual') {
            showToast(res?.error || 'Không tìm thấy bảng xét nghiệm trên trang này', 2600);
          } else if (!hasAnyData()) {
            el.dataInput.focus();
          }
        }
        return;
      }

      const normalized = res.text.trim();
      const alreadyMerged = state.mergeEnabled && state.mergedSheets.some((s) => s.rawText === normalized);
      if (silent && (normalized === state.lastAutoScannedText || alreadyMerged)) {
        state.lastAutoScannedText = normalized;
        return;
      }

      state.lastAutoScannedText = normalized;
      el.dataInput.value = normalized;
      el.scanBadge.className = 'scan-badge ok';
      el.scanBadge.textContent = state.mergeEnabled ? 'Đã gộp' : 'Đã quét';
      summarize(true, 'Đã quét & sao chép', res.meta || null);
    });
  }

  function saveSharedSettings() {
    const payload = {
      showUnit: state.showUnit,
      showAbbr: state.showAbbr,
      copyFormat: state.copyFormat,
      darkMode: state.darkMode,
      themeMode: state.darkMode ? 'dark' : 'light',
      mergeEnabled: state.mergeEnabled,
      mergeFilter: state.activeFilter
    };
    try {
      chrome.storage?.local?.set({ [SHARED_SETTINGS_KEY]: payload });
    } catch {}
  }

  function applySharedSettings(s) {
    if (!s || typeof s !== 'object') return;
    let changed = false;

    if (typeof s.showUnit === 'boolean' && s.showUnit !== state.showUnit) {
      state.showUnit = s.showUnit;
      localStorage.setItem('pop_showUnit', state.showUnit);
      changed = true;
    }
    if (typeof s.showAbbr === 'boolean' && s.showAbbr !== state.showAbbr) {
      state.showAbbr = s.showAbbr;
      localStorage.setItem('pop_showAbbr', state.showAbbr);
      changed = true;
    }
    if (s.copyFormat && FORMAT_ORDER.includes(s.copyFormat) && s.copyFormat !== state.copyFormat) {
      state.copyFormat = s.copyFormat;
      localStorage.setItem('pop_copyFormat', state.copyFormat);
      changed = true;
    }
    if (typeof s.darkMode === 'boolean' && s.darkMode !== state.darkMode) {
      state.darkMode = s.darkMode;
      localStorage.setItem('pop_darkMode', state.darkMode);
      changed = true;
    }
    if (typeof s.mergeEnabled === 'boolean' && s.mergeEnabled !== state.mergeEnabled) {
      state.mergeEnabled = s.mergeEnabled;
      localStorage.setItem('pop_mergeEnabled', state.mergeEnabled);
      changed = true;
    }
    if (s.mergeFilter && ['main', 'abnormal', 'all'].includes(s.mergeFilter) && s.mergeFilter !== state.activeFilter) {
      state.activeFilter = s.mergeFilter;
      localStorage.setItem('pop_activeFilter', state.activeFilter);
      changed = true;
    }
    if (changed) {
      updateToolbarUI();
      if (hasAnyData()) renderSummary();
    }
  }

  // --- Sự kiện ---
  let inputTimer = null;
  el.dataInput.addEventListener('input', () => {
    clearTimeout(inputTimer);
    inputTimer = setTimeout(() => summarize(true, 'Đã tóm tắt & sao chép', null), 250);
  });

  el.rescanBtn.addEventListener('click', () => scanFromCurrentTab('manual', false));

  el.clearBtn.addEventListener('click', () => {
    el.dataInput.value = '';
    el.scanBadge.classList.add('hidden');
    state.rows = [];
    state.selectedIndices = [];
    state.lastAutoScannedText = '';
    if (state.mergeEnabled) {
      state.mergedSheets = [];
      state.mergePatient = { id: '', name: '', contextKey: '' };
      saveMergeSession();
    }
    updateToolbarUI();
    renderSummary();
    el.dataInput.focus();
  });

  if (el.mergeBtn) {
    el.mergeBtn.addEventListener('click', () => {
      state.mergeEnabled = !state.mergeEnabled;
      localStorage.setItem('pop_mergeEnabled', state.mergeEnabled);
      saveSharedSettings();

      if (state.mergeEnabled) {
        if (state.rows.length && el.dataInput.value.trim()) {
          upsertMergedSheet(el.dataInput.value.trim(), state.rows, state.currentMeta);
        }
        showToast('Bật chế độ Gộp nhiều phiếu XN', 2000);
      } else {
        showToast('Tắt chế độ Gộp phiếu', 1600);
      }

      updateToolbarUI();
      const plain = renderSummary();
      if (plain) copyText(plain);
    });
  }

  if (el.clearMergeBtn) {
    el.clearMergeBtn.addEventListener('click', () => {
      state.mergedSheets = [];
      state.mergePatient = { id: '', name: '', contextKey: '' };
      state.lastAutoScannedText = '';
      saveMergeSession();
      updateToolbarUI();
      renderSummary();
      showToast('Đã xóa danh sách gộp');
    });
  }

  if (el.mergeChips) {
    el.mergeChips.addEventListener('click', (e) => {
      const delBtn = e.target.closest('[data-del]');
      if (delBtn) {
        const idx = parseInt(delBtn.dataset.del, 10);
        if (!isNaN(idx)) {
          state.mergedSheets.splice(idx, 1);
          if (!state.mergedSheets.length) state.mergePatient = { id: '', name: '', contextKey: '' };
          saveMergeSession();
          updateToolbarUI();
          const plain = renderSummary();
          if (plain) copyText(plain).then(() => showToast('Đã bỏ phiếu & sao chép lại'));
        }
        return;
      }

      const chip = e.target.closest('.merge-chip');
      if (chip) {
        const idx = parseInt(chip.dataset.idx, 10);
        const sheet = state.mergedSheets[idx];
        if (sheet) el.dataInput.value = sheet.rawText;
      }
    });
  }

  el.formatBtn.addEventListener('click', () => {
    const idx = (FORMAT_ORDER.indexOf(state.copyFormat) + 1) % FORMAT_ORDER.length;
    state.copyFormat = FORMAT_ORDER[idx];
    localStorage.setItem('pop_copyFormat', state.copyFormat);
    saveSharedSettings();
    updateToolbarUI();
    const plain = renderSummary();
    if (plain) copyText(plain).then(() => showToast('Đã đổi định dạng & sao chép'));
  });

  el.unitBtn.addEventListener('click', () => {
    state.showUnit = !state.showUnit;
    localStorage.setItem('pop_showUnit', state.showUnit);
    saveSharedSettings();
    updateToolbarUI();
    const plain = renderSummary();
    if (plain) copyText(plain);
  });

  el.abbrBtn.addEventListener('click', () => {
    state.showAbbr = !state.showAbbr;
    localStorage.setItem('pop_showAbbr', state.showAbbr);
    saveSharedSettings();
    updateToolbarUI();
    const plain = renderSummary();
    if (plain) copyText(plain);
  });

  el.copyBtn.addEventListener('click', () => {
    const plain = buildCurrentOutput().plain;
    if (!plain) return showToast('Chưa có dữ liệu để copy');
    copyText(plain).then(() => {
      el.copyBtn.classList.add('copied');
      el.copyBtn.textContent = 'Đã copy';
      showToast('Đã sao chép kết quả');
      setTimeout(() => {
        el.copyBtn.classList.remove('copied');
        el.copyBtn.textContent = 'Copy';
      }, 1500);
    });
  });

  if (el.insertBtn) {
    el.insertBtn.addEventListener('click', () => {
      const plain = buildCurrentOutput().plain;
      if (!plain) return showToast('Chưa có dữ liệu để chèn');

      chrome.runtime.sendMessage({ type: 'CLS_INSERT_HIS', text: plain }, (res) => {
        if (chrome.runtime.lastError || !res || !res.ok) {
          copyText(plain);
          showToast(res?.error || 'Hãy đặt con trỏ vào ô HIS (đã copy dự phòng)', 3200);
          return;
        }
        el.insertBtn.classList.add('inserted');
        el.insertBtn.textContent = 'Đã chèn';
        showToast('Đã chèn trực tiếp vào HIS');
        setTimeout(() => {
          el.insertBtn.classList.remove('inserted');
          el.insertBtn.textContent = 'Chèn';
        }, 1500);
      });
    });
  }

  el.filterBtns.forEach((btn) => {
    btn.addEventListener('click', () => {
      const plain = applyFilter(btn.dataset.filter);
      saveSharedSettings();
      if (plain) copyText(plain).then(() => showToast('Đã cập nhật & sao chép'));
    });
  });

  el.themeBtn.addEventListener('click', () => {
    state.darkMode = !state.darkMode;
    localStorage.setItem('pop_darkMode', state.darkMode);
    saveSharedSettings();
    updateToolbarUI();
  });

  el.openFullBtn.addEventListener('click', async () => {
    const tabs = await chrome.tabs.query({ url: 'https://qtrungyb.github.io/*' });
    if (tabs.length) {
      await chrome.tabs.update(tabs[0].id, { active: true });
      await chrome.windows.update(tabs[0].windowId, { focused: true });
    } else {
      await chrome.tabs.create({ url: CLS_WEB_URL });
    }
    if (!isSidePanel) window.close();
  });

  document.addEventListener('keydown', (e) => {
    const cmd = e.ctrlKey || e.metaKey;
    if (cmd && e.key === 'Enter') {
      e.preventDefault();
      summarize(true);
    } else if (cmd && e.shiftKey && (e.key === 'C' || e.key === 'c')) {
      e.preventDefault();
      el.copyBtn.click();
    }
  });

  // --- Popup & Side Panel ---
  const isSidePanel = new URLSearchParams(window.location.search).get('mode') === 'sidepanel';
  if (isSidePanel) document.body.classList.add('sidepanel-mode');

  function stopSidePanelAutoScan() {
    if (state.autoScanTimer != null) {
      clearInterval(state.autoScanTimer);
      state.autoScanTimer = null;
    }
  }

  function startSidePanelAutoScan(immediate = false) {
    stopSidePanelAutoScan();
    if (!isSidePanel || !state.autoScanEnabled) return;
    state.autoScanTimer = setInterval(() => scanFromCurrentTab('auto', true), 1200);
    if (immediate) scanFromCurrentTab('auto', true);
  }

  if (el.autoScanBtn) {
    el.autoScanBtn.addEventListener('click', () => {
      state.autoScanEnabled = !state.autoScanEnabled;
      localStorage.setItem('pop_autoScan', state.autoScanEnabled);
      updateToolbarUI();

      if (state.autoScanEnabled) {
        state.lastAutoScannedText = '';
        startSidePanelAutoScan(true);
        showToast('Đã bật tự động quét HIS');
      } else {
        stopSidePanelAutoScan();
        showToast('Đã tắt tự động quét HIS');
      }
    });
  }

  if (isSidePanel) {
    if (chrome.tabs && chrome.tabs.onActivated) {
      chrome.tabs.onActivated.addListener(() => {
        if (state.autoScanEnabled) scanFromCurrentTab('auto', true);
      });
    }
    window.addEventListener('unload', stopSidePanelAutoScan);
  }

  let currentWindowId = null;
  if (chrome.windows && chrome.windows.getCurrent) {
    chrome.windows.getCurrent((w) => {
      if (w) currentWindowId = w.id;
    });
  }

  if (el.sidePanelBtn) {
    el.sidePanelBtn.addEventListener('click', () => {
      if (!chrome.sidePanel || !chrome.sidePanel.open || currentWindowId == null) {
        return showToast('Chuột phải vào biểu tượng tiện ích → Mở bảng điều khiển bên', 3500);
      }
      chrome.sidePanel.open({ windowId: currentWindowId })
        .then(() => window.close())
        .catch((err) => showToast('Không mở được thanh bên: ' + err.message, 3000));
    });
  }

  // --- Khởi chạy ---
  loadMergeSession();
  updateToolbarUI();
  renderSummary();
  syncAbbrFromFirebase();

  try {
    chrome.storage.local.get([SHARED_SETTINGS_KEY, MERGE_SESSION_KEY], (data) => {
      const savedSettings = data?.[SHARED_SETTINGS_KEY];
      if (savedSettings && typeof savedSettings.mergeEnabled === 'boolean') {
        applySharedSettings(savedSettings);
      } else {
        if (savedSettings) applySharedSettings(savedSettings);
        saveSharedSettings();
      }
      if (data?.[MERGE_SESSION_KEY]) {
        applyMergeSessionPayload(data[MERGE_SESSION_KEY]);
        updateToolbarUI();
        renderSummary();
      }
    });
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== 'local') return;
      if (changes[SHARED_SETTINGS_KEY]?.newValue) {
        applySharedSettings(changes[SHARED_SETTINGS_KEY].newValue);
      }
      if (changes[MERGE_SESSION_KEY]?.newValue) {
        applyMergeSessionPayload(changes[MERGE_SESSION_KEY].newValue);
        updateToolbarUI();
        renderSummary();
      }
    });
  } catch {}

  scanFromCurrentTab('auto', false);
  if (isSidePanel && state.autoScanEnabled) {
    startSidePanelAutoScan(false);
  }
})();