/* =========================================================
   POPUP & SIDE PANEL — Tóm tắt nhanh + Tự quét + Gộp phiếu
   ========================================================= */
(function() {
  const CLS = globalThis.CLSShared;
  const {
    CLS_WEB_URL,
    ABBR_ENDPOINT,
    MERGE_SESSION_KEY,
    SHARED_SETTINGS_KEY,
    ABBR_CACHE_KEY,
    SPECIAL_NAMES,
    DEFAULT_ABBR
  } = CLS;

  const REMOTE_MANIFEST_URL = 'https://qtrungyb.github.io/ttcls/cls-auto/manifest.json';
  const UPDATE_CACHE_KEY = 'pop_update_check_v1';
  const FORMAT_ORDER = ['comma', 'semicolon', 'newline'];
  const FORMAT_LABELS = { comma: ',', semicolon: ';', newline: '↵' };

  const state = {
	compactUrine: localStorage.getItem('pop_compactUrine') !== 'false',
    autoScanEnabled: localStorage.getItem('pop_autoScan') !== 'false',
    mergeEnabled: localStorage.getItem('pop_mergeEnabled') !== 'false',
    drawerOpen: false,
    latestRemoteVersion: '',
    lastAutoScannedText: '',
    isScanning: false,
    autoScanTimer: null,
    abbrMap: loadCachedAbbr(),
    showUnit: localStorage.getItem('pop_showUnit') === 'true',
    showAbbr: localStorage.getItem('pop_showAbbr') !== 'false',
    copyFormat: localStorage.getItem('pop_copyFormat') || 'comma',
    darkMode: localStorage.getItem('pop_darkMode') !== 'false',
    rows: [],
    selectedIndices: [],
    activeFilter: localStorage.getItem('pop_activeFilter') || 'main',
    currentMeta: null,
    mergePatient: { id: '', name: '', contextKey: '' },
    mergedSheets: []
  };

  const el = {
	urineBtn: document.getElementById('urineBtn'),
    verBadge: document.getElementById('verBadge'),
    verText: document.getElementById('verText'),
    verDot: document.getElementById('verDot'),
    autoScanBtn: document.getElementById('autoScanBtn'),
    mergeBtn: document.getElementById('mergeBtn'),
    mergeBar: document.getElementById('mergeBar'),
    patientBadge: document.getElementById('patientBadge'),
    mergeChips: document.getElementById('mergeChips'),
    clearMergeBtn: document.getElementById('clearMergeBtn'),
    sidePanelBtn: document.getElementById('sidePanelBtn'),
    pasteDrawer: document.getElementById('pasteDrawer'),
    pasteToggleBtn: document.getElementById('pasteToggleBtn'),
    pastePanel: document.getElementById('pastePanel'),
    dataInput: document.getElementById('dataInput'),
    summaryText: document.getElementById('summaryText'),
    outputCard: document.getElementById('outputCard'),
    totalCount: document.getElementById('totalCount'),
    abnCount: document.getElementById('abnCount'),
    scanBadge: document.getElementById('scanBadge'),
    rescanBtn: document.getElementById('rescanBtn'),
    clearBtn: document.getElementById('clearBtn'),
    formatBtn: document.getElementById('formatBtn'),
    unitBtn: document.getElementById('unitBtn'),
    abbrBtn: document.getElementById('abbrBtn'),
    copyBtn: document.getElementById('copyBtn'),
    openFullBtn: document.getElementById('openFullBtn'),
    themeBtn: document.getElementById('themeBtn'),
    filterBtns: document.querySelectorAll('.filter-btn'),
    toast: document.getElementById('toast')
  };

  function setBtnLabel(btn, text) {
    if (!btn) return;
    const span = btn.querySelector('.btn-label');
    if (span) span.textContent = text;
    else btn.textContent = text;
  }

  function compareVersions(a, b) {
    const pa = String(a || '0').split('.').map((n) => parseInt(n, 10) || 0);
    const pb = String(b || '0').split('.').map((n) => parseInt(n, 10) || 0);
    const len = Math.max(pa.length, pb.length);
    for (let i = 0; i < len; i++) {
      if ((pa[i] || 0) !== (pb[i] || 0)) return (pa[i] || 0) - (pb[i] || 0);
    }
    return 0;
  }

  function getChipGroupClass(label) {
    const k = String(label || '').toUpperCase();
    if (k === 'CTM' || k === 'VSS') return 'chip-ctm';
    if (k === 'SHM' || k === 'ĐGĐ') return 'chip-shm';
    if (k === 'TPTNT') return 'chip-tptnt';
    if (k === 'CĐHA' || k === 'TDCN') return 'chip-img';
    return 'chip-other';
  }

  function setDrawerOpen(open, focusInput = false) {
    state.drawerOpen = Boolean(open);
    if (el.pasteDrawer) el.pasteDrawer.classList.toggle('open', state.drawerOpen);
    if (el.pastePanel) el.pastePanel.classList.toggle('hidden', !state.drawerOpen);
    if (el.pasteToggleBtn) el.pasteToggleBtn.setAttribute('aria-expanded', String(state.drawerOpen));
    if (state.drawerOpen && focusInput && el.dataInput) {
      el.dataInput.focus();
    }
  }

  function initVersionAndUpdateCheck() {
    let curVer = '';
    try { curVer = chrome.runtime.getManifest().version || ''; } catch {}
    if (el.verText && curVer) el.verText.textContent = 'v' + curVer;

    const applyRemote = (remoteVer) => {
      if (!remoteVer || !curVer) return;
      if (compareVersions(curVer, remoteVer) < 0) {
        state.latestRemoteVersion = remoteVer;
        el.verBadge?.classList.add('has-update');
        el.verDot?.classList.remove('hidden');
        if (el.verBadge) {
          el.verBadge.title = `Có bản mới v${remoteVer} — Nháy đúp CapNhat_CLS.bat rồi bấm Tải lại`;
        }
      } else {
        state.latestRemoteVersion = '';
        el.verBadge?.classList.remove('has-update');
        el.verDot?.classList.add('hidden');
        if (el.verBadge) el.verBadge.title = `Đang ở bản mới nhất (v${curVer})`;
      }
    };

    try {
      const cached = JSON.parse(localStorage.getItem(UPDATE_CACHE_KEY) || 'null');
      if (cached?.ver) applyRemote(cached.ver);
      if (cached?.ts && Date.now() - cached.ts < 10 * 60 * 1000) return;
    } catch {}

    fetch(`${REMOTE_MANIFEST_URL}?t=${Date.now()}`, { cache: 'no-store' })
      .then((res) => (res.ok ? res.json() : null))
      .then((mf) => {
        if (!mf?.version) return;
        try {
          localStorage.setItem(UPDATE_CACHE_KEY, JSON.stringify({ ver: mf.version, ts: Date.now() }));
        } catch {}
        applyRemote(mf.version);
      })
      .catch(() => {});
  }

  function loadCachedAbbr() {
    try {
      const raw = localStorage.getItem('pop_abbr_cache');
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed && Object.keys(parsed).length) return parsed;
      }
    } catch {}
    return { ...DEFAULT_ABBR };
  }

  function applyMergeSessionPayload(saved) {
    if (!saved || typeof saved !== 'object') return;
    state.mergePatient = {
      id: saved.patient?.id || '',
      name: saved.patient?.name || '',
      contextKey: saved.patient?.contextKey || (saved.patient?.id ? 'pid:' + saved.patient.id : '')
    };
    state.mergedSheets = Array.isArray(saved.sheets)
      ? saved.sheets
          .map((s) => {
            const rows = CLS.parseInputToRows(s.rawText);
            if (!rows.length) return null;
            return {
              key: s.key,
              label: CLS.getShortServiceLabel(s.serviceName, rows),
              serviceName: s.serviceName || '',
              resultTime: s.resultTime || '',
              rawText: s.rawText,
              rows
            };
          })
          .filter(Boolean)
      : [];
    CLS.sortSheets(state.mergedSheets);
  }

  function saveMergeSession() {
    const payload = {
      patient: state.mergePatient,
      sheets: state.mergedSheets.map((s) => ({
        key: s.key,
        label: s.label,
        serviceName: s.serviceName,
        resultTime: s.resultTime,
        rawText: s.rawText
      })),
      updatedAt: Date.now()
    };
    try { localStorage.setItem(MERGE_SESSION_KEY, JSON.stringify(payload)); } catch {}
    try { chrome.storage?.local?.set({ [MERGE_SESSION_KEY]: payload }); } catch {}
  }

  function loadMergeSession() {
    try {
      const raw = localStorage.getItem(MERGE_SESSION_KEY);
      if (raw) applyMergeSessionPayload(JSON.parse(raw));
    } catch {}
  }

  async function syncAbbrFromFirebase() {
    try {
      const res = await fetch(ABBR_ENDPOINT, { cache: 'no-store' });
      if (!res.ok) return;
      const data = await res.json();
      if (!data) return;

      const map = {};
      Object.values(data).forEach((item) => {
        if (item && item.raw != null && item.short != null) {
          map[item.raw] = item.short;
        }
      });

      if (Object.keys(map).length) {
        state.abbrMap = map;
        localStorage.setItem('pop_abbr_cache', JSON.stringify(map));
        chrome.storage?.local?.set({ [ABBR_CACHE_KEY]: map });
        if (hasAnyData()) renderSummary();
      }
    } catch {}
  }

  function getFormatSettings() {
    return {
      showUnit: state.showUnit,
      showAbbr: state.showAbbr,
      compactUrine: state.compactUrine,
      copyFormat: state.copyFormat,
      mergeFilter: state.activeFilter
    };
  }

  function hasAnyData() {
    return state.mergeEnabled ? state.mergedSheets.length > 0 : state.rows.length > 0;
  }

  let toastTimer = null;
  function showToast(msg, ms = 1800) {
    el.toast.textContent = msg;
    el.toast.classList.remove('hidden');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.toast.classList.add('hidden'), ms);
  }

  function copyText(text) {
    if (!text) return Promise.resolve(false);

    if (!document.hasFocus()) {
      return new Promise((resolve) => {
        chrome.runtime.sendMessage({ type: 'CLS_COPY_TEXT', text }, (res) => {
          void chrome.runtime.lastError;
          resolve(Boolean(res && res.ok));
        });
      });
    }

    if (navigator.clipboard && navigator.clipboard.writeText) {
      return navigator.clipboard.writeText(text).then(() => true).catch(() => fallbackCopy(text));
    }
    return Promise.resolve(fallbackCopy(text));
  }

  function fallbackCopy(text) {
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.style.cssText = 'position:fixed;top:-9999px;';
    ta.setAttribute('readonly', '');
    document.body.appendChild(ta);
    ta.select();
    let ok = false;
    try { ok = document.execCommand('copy'); } catch {}
    ta.remove();
    return ok;
  }

  function renderMergeBar() {
    if (!el.mergeBar) return;
    el.mergeBar.classList.toggle('hidden', !state.mergeEnabled);
    if (!state.mergeEnabled) return;

    const p = state.mergePatient;
    if (p.name && p.id) el.patientBadge.textContent = `BN: ${p.name} (${p.id})`;
    else if (p.name) el.patientBadge.textContent = `BN: ${p.name}`;
    else if (p.id) el.patientBadge.textContent = `Mã BN: ${p.id}`;
    else el.patientBadge.textContent = 'Chế độ gộp nhiều phiếu XN';

    el.clearMergeBtn.classList.toggle('hidden', state.mergedSheets.length === 0);

    if (!state.mergedSheets.length) {
      el.mergeChips.innerHTML = '<span class="merge-empty">Chuyển lần lượt các phiếu trên HIS để tự động gộp…</span>';
      return;
    }

    el.mergeChips.innerHTML = state.mergedSheets.map((s, idx) => {
      const tip = [s.serviceName || s.label, s.resultTime].filter(Boolean).join(' — ');
      const isImg = s.label === 'CĐHA' || s.label === 'TDCN';
      const chipLabel = isImg && s.rows[0]?.cleanName ? s.rows[0].cleanName : s.label;
      const chipCount = isImg ? '' : `<span class="merge-chip-count">(${s.rows.length})</span>`;
      const grpCls = getChipGroupClass(s.label);
      return `
        <span class="merge-chip ${grpCls}" data-idx="${idx}" title="${CLS.escapeAttr(tip)}">
          <span class="merge-chip-text">${CLS.escapeHtml(chipLabel)}</span>
          ${chipCount}
          <button type="button" class="merge-chip-del" data-del="${idx}" title="Bỏ phiếu này">&times;</button>
        </span>
      `;
    }).join('');
  }

  function updateToolbarUI() {
    document.body.classList.toggle('dark-mode', state.darkMode);
    el.formatBtn.textContent = FORMAT_LABELS[state.copyFormat] || ',';
    el.unitBtn.classList.toggle('active', state.showUnit);
    el.abbrBtn.classList.toggle('active', state.showAbbr);
    if (el.urineBtn) el.urineBtn.classList.toggle('active', state.compactUrine);
    if (el.autoScanBtn) el.autoScanBtn.classList.toggle('active', state.autoScanEnabled);
    if (el.mergeBtn) {
      el.mergeBtn.classList.toggle('active', state.mergeEnabled);
      setBtnLabel(
        el.mergeBtn,
        state.mergeEnabled && state.mergedSheets.length ? `Gộp (${state.mergedSheets.length})` : 'Gộp'
      );
    }
    el.filterBtns.forEach((btn) => {
      btn.classList.toggle('active', btn.dataset.filter === state.activeFilter);
    });
    renderMergeBar();
  }

  function buildCurrentOutput() {
    if (state.mergeEnabled) {
      if (!state.mergedSheets.length) {
        return { total: 0, abnTotal: 0, html: '', plain: '', emptyMsg: 'Chưa có phiếu nào được gộp' };
      }
      const res = CLS.formatMergedSheets(state.mergedSheets, getFormatSettings(), state.abbrMap);
      return {
        ...res,
        emptyMsg: 'Không có chỉ số nào trong nhóm lọc này'
      };
    }

    const selected = state.rows.filter((_, i) => state.selectedIndices.includes(i));
    const abnTotal = state.rows.filter((r) => r._status === 'abnormal').length;
    if (!state.rows.length) {
      return { total: 0, abnTotal: 0, html: '', plain: '', emptyMsg: 'Chưa có dữ liệu xét nghiệm' };
    }
    if (!selected.length) {
      return { total: state.rows.length, abnTotal, html: '', plain: '', emptyMsg: 'Không có chỉ số nào trong nhóm lọc này' };
    }
	 const singleLabel = CLS.getShortServiceLabel(state.currentMeta?.serviceName, state.rows);
	 if (singleLabel === 'TPTNT' && state.compactUrine) {
	   const abnUrine = selected.filter((r) => !CLS.isNormalUrineRow(r));
	   if (!abnUrine.length) {
		 return { total: state.rows.length, abnTotal, html: 'Bình thường', plain: 'Bình thường', emptyMsg: '' };
	   }
	   const { html, plain } = CLS.formatRows(abnUrine, getFormatSettings(), state.abbrMap);
	   return { total: state.rows.length, abnTotal, html, plain, emptyMsg: 'Không có chỉ số hợp lệ' };
	 }
	 const { html, plain } = CLS.formatRows(selected, getFormatSettings(), state.abbrMap);
    return {
      total: state.rows.length,
      abnTotal,
      html,
      plain,
      emptyMsg: 'Không có chỉ số hợp lệ'
    };
  }

  function renderSummary() {
    const out = buildCurrentOutput();
    el.totalCount.textContent = out.total;
    el.abnCount.textContent = out.abnTotal;
    el.summaryText.innerHTML = out.html || `<div class="empty-state">${out.emptyMsg}</div>`;
    return out.plain;
  }

  function applyFilter(filterName) {
    state.activeFilter = filterName;
    localStorage.setItem('pop_activeFilter', state.activeFilter);
    if (!state.mergeEnabled) {
      if (filterName === 'main') {
        const main = state.rows.reduce((a, r, i) => SPECIAL_NAMES.includes(r.cleanName) ? [...a, i] : a, []);
        state.selectedIndices = main.length ? main : state.rows.map((_, i) => i);
        if (!main.length) state.activeFilter = 'all';
      } else if (filterName === 'abnormal') {
        state.selectedIndices = state.rows.reduce((a, r, i) => r._status === 'abnormal' ? [...a, i] : a, []);
      } else {
        state.selectedIndices = state.rows.map((_, i) => i);
      }
    }
    updateToolbarUI();
    return renderSummary();
  }

  function upsertMergedSheet(rawText, rows, meta) {
    let patientSwitched = false;
    const incomingId = meta?.patientId || '';
    const incomingName = meta?.patientName || '';
    const incomingKey = incomingId ? 'pid:' + incomingId : (meta?.contextKey || '');
    const currentKey = state.mergePatient.contextKey || (state.mergePatient.id ? 'pid:' + state.mergePatient.id : '');

    if (incomingKey && currentKey && incomingKey !== currentKey) {
      state.mergedSheets = [];
      state.mergePatient = { id: '', name: '', contextKey: '' };
      patientSwitched = true;
    }

    if (incomingId) state.mergePatient.id = incomingId;
    if (incomingName) state.mergePatient.name = incomingName;
    if (incomingKey) state.mergePatient.contextKey = incomingKey;

    const label = CLS.getShortServiceLabel(meta?.serviceName, rows);
    const resultTime = (meta?.resultTime || '').trim();
    const key = CLS.makeSheetKey(label, resultTime, rows);

    const sheetObj = {
      key,
      label,
      serviceName: meta?.serviceName || label,
      resultTime,
      rawText,
      rows
    };

    const existingIdx = CLS.findMatchingSheetIndex(state.mergedSheets, { rawText, label, resultTime, rows });
    const isUpdated = existingIdx !== -1;
    if (isUpdated) {
      if (!sheetObj.resultTime && state.mergedSheets[existingIdx].resultTime) {
        sheetObj.resultTime = state.mergedSheets[existingIdx].resultTime;
        sheetObj.key = CLS.makeSheetKey(label, sheetObj.resultTime, rows);
      }
      state.mergedSheets[existingIdx] = sheetObj;
    } else {
      state.mergedSheets.push(sheetObj);
    }

    CLS.sortSheets(state.mergedSheets);
    saveMergeSession();
    return { label, isUpdated, patientSwitched, count: state.mergedSheets.length };
  }

  function summarize(autoCopy = true, toastLabel = 'Đã tóm tắt & sao chép', meta = null) {
    const rawText = el.dataInput.value.trim();
    const rows = CLS.parseInputToRows(rawText);
    state.rows = rows;
    state.currentMeta = meta || state.currentMeta;

    if (!rows.length) {
      state.selectedIndices = [];
      updateToolbarUI();
      renderSummary();
      return;
    }

    const main = rows.reduce((a, r, i) => SPECIAL_NAMES.includes(r.cleanName) ? [...a, i] : a, []);
    state.selectedIndices = main.length ? main : rows.map((_, i) => i);

    let finalToast = toastLabel;
    if (state.mergeEnabled) {
      const info = upsertMergedSheet(rawText, rows, meta);
      if (info.patientSwitched) {
        finalToast = `Đổi BN ${state.mergePatient.name || state.mergePatient.id || 'mới'} — gộp mới (${info.label})`;
      } else if (info.isUpdated) {
        finalToast = `Đã cập nhật ${info.label} (${info.count} phiếu) & copy`;
      } else {
        finalToast = `Đã gộp +${info.label} (${info.count} phiếu) & copy`;
      }
    } else {
      state.activeFilter = main.length ? 'main' : 'all';
    }

    updateToolbarUI();
    const plain = renderSummary();

    if (autoCopy && plain) {
      copyText(plain).then(() => showToast(finalToast, 2200));
    }

    el.outputCard.classList.add('pulse');
    setTimeout(() => el.outputCard.classList.remove('pulse'), 450);
  }

  function scanFromCurrentTab(mode = 'auto', silent = false) {
    if (state.isScanning) return;
    if (silent && document.hidden) return;

    state.isScanning = true;
    if (!silent) {
      el.rescanBtn.disabled = true;
      el.scanBadge.className = 'scan-badge';
      el.scanBadge.textContent = 'Đang quét…';
    }

    chrome.runtime.sendMessage({ type: 'CLS_SCAN_HIS', mode }, (res) => {
      state.isScanning = false;
      if (!silent) el.rescanBtn.disabled = false;

      if (chrome.runtime.lastError || !res || !res.ok || res.empty || !res.text?.trim()) {
        if (!silent) {
          el.scanBadge.classList.add('hidden');
          if (mode === 'manual') {
            showToast(res?.error || 'Không tìm thấy bảng xét nghiệm trên trang này', 2600);
          }
        }
        return;
      }

      const normalized = res.text.trim();
      const alreadyMerged = state.mergeEnabled && state.mergedSheets.some((s) => s.rawText === normalized);
      if (silent && (normalized === state.lastAutoScannedText || alreadyMerged)) {
        state.lastAutoScannedText = normalized;
        return;
      }

      state.lastAutoScannedText = normalized;
      el.dataInput.value = normalized;
      el.scanBadge.className = 'scan-badge ok';
      el.scanBadge.textContent = state.mergeEnabled ? 'Đã gộp' : 'Đã quét';
      summarize(true, 'Đã quét & sao chép', res.meta || null);
    });
  }

  function saveSharedSettings() {
    const payload = {
      showUnit: state.showUnit,
      showAbbr: state.showAbbr,
      compactUrine: state.compactUrine,
      copyFormat: state.copyFormat,
      darkMode: state.darkMode,
      themeMode: state.darkMode ? 'dark' : 'light',
      mergeEnabled: state.mergeEnabled,
      mergeFilter: state.activeFilter
    };
    try {
      chrome.storage?.local?.set({ [SHARED_SETTINGS_KEY]: payload });
    } catch {}
  }

  function applySharedSettings(s) {
    if (!s || typeof s !== 'object') return;
    let changed = false;

    if (typeof s.showUnit === 'boolean' && s.showUnit !== state.showUnit) {
      state.showUnit = s.showUnit;
      localStorage.setItem('pop_showUnit', state.showUnit);
      changed = true;
    }
    if (typeof s.showAbbr === 'boolean' && s.showAbbr !== state.showAbbr) {
      state.showAbbr = s.showAbbr;
      localStorage.setItem('pop_showAbbr', state.showAbbr);
      changed = true;
    }
    if (typeof s.compactUrine === 'boolean' && s.compactUrine !== state.compactUrine) {
      state.compactUrine = s.compactUrine;
      localStorage.setItem('pop_compactUrine', state.compactUrine);
      changed = true;
    }
    if (s.copyFormat && FORMAT_ORDER.includes(s.copyFormat) && s.copyFormat !== state.copyFormat) {
      state.copyFormat = s.copyFormat;
      localStorage.setItem('pop_copyFormat', state.copyFormat);
      changed = true;
    }
    if (typeof s.darkMode === 'boolean' && s.darkMode !== state.darkMode) {
      state.darkMode = s.darkMode;
      localStorage.setItem('pop_darkMode', state.darkMode);
      changed = true;
    }
    if (typeof s.mergeEnabled === 'boolean' && s.mergeEnabled !== state.mergeEnabled) {
      state.mergeEnabled = s.mergeEnabled;
      localStorage.setItem('pop_mergeEnabled', state.mergeEnabled);
      changed = true;
    }
    if (s.mergeFilter && ['main', 'abnormal', 'all'].includes(s.mergeFilter) && s.mergeFilter !== state.activeFilter) {
      state.activeFilter = s.mergeFilter;
      localStorage.setItem('pop_activeFilter', state.activeFilter);
      changed = true;
    }
    if (changed) {
      updateToolbarUI();
      if (hasAnyData()) renderSummary();
    }
  }

  // --- Sự kiện ---
  if (el.verBadge) {
    el.verBadge.addEventListener('click', () => {
      if (state.latestRemoteVersion) {
        showToast(`Có bản mới v${state.latestRemoteVersion} — nháy đúp CapNhat_CLS.bat`, 3200);
      } else {
        showToast('Tiện ích đang ở phiên bản mới nhất', 1600);
      }
    });
  }

  if (el.pasteToggleBtn) {
    el.pasteToggleBtn.addEventListener('click', () => {
      setDrawerOpen(!state.drawerOpen, !state.drawerOpen);
    });
  }

  // Hỗ trợ nhấn Ctrl+V ngay khi mở Popup (tự mở ngăn kéo & tóm tắt)
  document.addEventListener('paste', (e) => {
    if (document.activeElement === el.dataInput) return;
    const text = e.clipboardData?.getData('text') || '';
    if (!text.trim()) return;
    e.preventDefault();
    setDrawerOpen(true, false);
    el.dataInput.value = text;
    summarize(true, 'Đã dán, tóm tắt & sao chép', null);
  });

  let inputTimer = null;
  el.dataInput.addEventListener('input', () => {
    clearTimeout(inputTimer);
    inputTimer = setTimeout(() => summarize(true, 'Đã tóm tắt & sao chép', null), 250);
  });

  el.rescanBtn.addEventListener('click', () => scanFromCurrentTab('manual', false));

  el.clearBtn.addEventListener('click', () => {
    el.dataInput.value = '';
    el.scanBadge.classList.add('hidden');
    state.rows = [];
    state.selectedIndices = [];
    state.lastAutoScannedText = '';
    if (state.mergeEnabled) {
      state.mergedSheets = [];
      state.mergePatient = { id: '', name: '', contextKey: '' };
      saveMergeSession();
    }
    updateToolbarUI();
    renderSummary();
  });

  if (el.mergeBtn) {
    el.mergeBtn.addEventListener('click', () => {
      state.mergeEnabled = !state.mergeEnabled;
      localStorage.setItem('pop_mergeEnabled', state.mergeEnabled);
      saveSharedSettings();

      if (state.mergeEnabled) {
        if (state.rows.length && el.dataInput.value.trim()) {
          upsertMergedSheet(el.dataInput.value.trim(), state.rows, state.currentMeta);
        }
        showToast('Bật chế độ Gộp nhiều phiếu XN', 2000);
      } else {
        showToast('Tắt chế độ Gộp phiếu', 1600);
      }

      updateToolbarUI();
      const plain = renderSummary();
      if (plain) copyText(plain);
    });
  }

  if (el.clearMergeBtn) {
    el.clearMergeBtn.addEventListener('click', () => {
      state.mergedSheets = [];
      state.mergePatient = { id: '', name: '', contextKey: '' };
      state.lastAutoScannedText = '';
      saveMergeSession();
      updateToolbarUI();
      renderSummary();
      showToast('Đã xóa danh sách gộp');
    });
  }

  if (el.mergeChips) {
    el.mergeChips.addEventListener('click', (e) => {
      const delBtn = e.target.closest('[data-del]');
      if (delBtn) {
        const idx = parseInt(delBtn.dataset.del, 10);
        if (!isNaN(idx)) {
          state.mergedSheets.splice(idx, 1);
          if (!state.mergedSheets.length) state.mergePatient = { id: '', name: '', contextKey: '' };
          saveMergeSession();
          updateToolbarUI();
          const plain = renderSummary();
          if (plain) copyText(plain).then(() => showToast('Đã bỏ phiếu & sao chép lại'));
        }
        return;
      }

      const chip = e.target.closest('.merge-chip');
      if (chip) {
        const idx = parseInt(chip.dataset.idx, 10);
        const sheet = state.mergedSheets[idx];
        if (sheet) {
          el.dataInput.value = sheet.rawText;
          setDrawerOpen(true, false);
        }
      }
    });
  }

  el.formatBtn.addEventListener('click', () => {
    const idx = (FORMAT_ORDER.indexOf(state.copyFormat) + 1) % FORMAT_ORDER.length;
    state.copyFormat = FORMAT_ORDER[idx];
    localStorage.setItem('pop_copyFormat', state.copyFormat);
    saveSharedSettings();
    updateToolbarUI();
    const plain = renderSummary();
    if (plain) copyText(plain).then(() => showToast('Đã đổi định dạng & sao chép'));
  });

  el.unitBtn.addEventListener('click', () => {
    state.showUnit = !state.showUnit;
    localStorage.setItem('pop_showUnit', state.showUnit);
    saveSharedSettings();
    updateToolbarUI();
    const plain = renderSummary();
    if (plain) copyText(plain);
  });

  el.abbrBtn.addEventListener('click', () => {
    state.showAbbr = !state.showAbbr;
    localStorage.setItem('pop_showAbbr', state.showAbbr);
    saveSharedSettings();
    updateToolbarUI();
    const plain = renderSummary();
    if (plain) copyText(plain);
  });

  if (el.urineBtn) {
    el.urineBtn.addEventListener('click', () => {
      state.compactUrine = !state.compactUrine;
      localStorage.setItem('pop_compactUrine', state.compactUrine);
      saveSharedSettings();
      updateToolbarUI();
      const plain = renderSummary();
      if (plain) {
        copyText(plain).then(() =>
          showToast(state.compactUrine ? 'Đã bật rút gọn TPTNT' : 'Hiển thị đầy đủ TPTNT')
        );
      }
    });
  }

  el.copyBtn.addEventListener('click', () => {
    const plain = buildCurrentOutput().plain;
    if (!plain) return showToast('Chưa có dữ liệu để copy');
    copyText(plain).then(() => {
      el.copyBtn.classList.add('copied');
      setBtnLabel(el.copyBtn, 'Đã copy');
      showToast('Đã sao chép kết quả');
      setTimeout(() => {
        el.copyBtn.classList.remove('copied');
        setBtnLabel(el.copyBtn, 'Copy');
      }, 1500);
    });
  });

  el.filterBtns.forEach((btn) => {
    btn.addEventListener('click', () => {
      const plain = applyFilter(btn.dataset.filter);
      saveSharedSettings();
      if (plain) copyText(plain).then(() => showToast('Đã cập nhật & sao chép'));
    });
  });

  el.themeBtn.addEventListener('click', () => {
    state.darkMode = !state.darkMode;
    localStorage.setItem('pop_darkMode', state.darkMode);
    saveSharedSettings();
    updateToolbarUI();
  });

  el.openFullBtn.addEventListener('click', async () => {
    const tabs = await chrome.tabs.query({ url: 'https://qtrungyb.github.io/*' });
    if (tabs.length) {
      await chrome.tabs.update(tabs[0].id, { active: true });
      await chrome.windows.update(tabs[0].windowId, { focused: true });
    } else {
      await chrome.tabs.create({ url: CLS_WEB_URL });
    }
    if (!isSidePanel) window.close();
  });

  document.addEventListener('keydown', (e) => {
    const cmd = e.ctrlKey || e.metaKey;
    if (cmd && e.key === 'Enter') {
      e.preventDefault();
      summarize(true);
    } else if (cmd && e.shiftKey && (e.key === 'C' || e.key === 'c')) {
      e.preventDefault();
      el.copyBtn.click();
    }
  });

  // --- Popup & Side Panel ---
  const isSidePanel = new URLSearchParams(window.location.search).get('mode') === 'sidepanel';
  if (isSidePanel) document.body.classList.add('sidepanel-mode');

  function stopSidePanelAutoScan() {
    if (state.autoScanTimer != null) {
      clearInterval(state.autoScanTimer);
      state.autoScanTimer = null;
    }
  }

  function startSidePanelAutoScan(immediate = false) {
    stopSidePanelAutoScan();
    if (!isSidePanel || !state.autoScanEnabled) return;
    state.autoScanTimer = setInterval(() => scanFromCurrentTab('auto', true), 1200);
    if (immediate) scanFromCurrentTab('auto', true);
  }

  if (el.autoScanBtn) {
    el.autoScanBtn.addEventListener('click', () => {
      state.autoScanEnabled = !state.autoScanEnabled;
      localStorage.setItem('pop_autoScan', state.autoScanEnabled);
      updateToolbarUI();

      if (state.autoScanEnabled) {
        state.lastAutoScannedText = '';
        startSidePanelAutoScan(true);
        showToast('Đã bật tự động quét HIS');
      } else {
        stopSidePanelAutoScan();
        showToast('Đã tắt tự động quét HIS');
      }
    });
  }

  if (isSidePanel) {
    if (chrome.tabs && chrome.tabs.onActivated) {
      chrome.tabs.onActivated.addListener(() => {
        if (state.autoScanEnabled) scanFromCurrentTab('auto', true);
      });
    }
    window.addEventListener('unload', stopSidePanelAutoScan);
  }

  let currentWindowId = null;
  if (chrome.windows && chrome.windows.getCurrent) {
    chrome.windows.getCurrent((w) => {
      if (w) currentWindowId = w.id;
    });
  }

  if (el.sidePanelBtn) {
    el.sidePanelBtn.addEventListener('click', () => {
      if (!chrome.sidePanel || !chrome.sidePanel.open || currentWindowId == null) {
        return showToast('Chuột phải vào biểu tượng tiện ích → Mở bảng điều khiển bên', 3500);
      }
      chrome.sidePanel.open({ windowId: currentWindowId })
        .then(() => window.close())
        .catch((err) => showToast('Không mở được thanh bên: ' + err.message, 3000));
    });
  }

  // --- Khởi chạy ---
  initVersionAndUpdateCheck();
  loadMergeSession();
  updateToolbarUI();
  renderSummary();
  syncAbbrFromFirebase();

  try {
    chrome.storage.local.get([SHARED_SETTINGS_KEY, MERGE_SESSION_KEY], (data) => {
      const savedSettings = data?.[SHARED_SETTINGS_KEY];
      if (savedSettings && typeof savedSettings.mergeEnabled === 'boolean') {
        applySharedSettings(savedSettings);
      } else {
        if (savedSettings) applySharedSettings(savedSettings);
        saveSharedSettings();
      }
      if (data?.[MERGE_SESSION_KEY]) {
        applyMergeSessionPayload(data[MERGE_SESSION_KEY]);
        updateToolbarUI();
        renderSummary();
      }
    });
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== 'local') return;
      if (changes[SHARED_SETTINGS_KEY]?.newValue) {
        applySharedSettings(changes[SHARED_SETTINGS_KEY].newValue);
      }
      if (changes[MERGE_SESSION_KEY]?.newValue) {
        applyMergeSessionPayload(changes[MERGE_SESSION_KEY].newValue);
        updateToolbarUI();
        renderSummary();
      }
    });
  } catch {}

  scanFromCurrentTab('auto', false);
  if (isSidePanel && state.autoScanEnabled) {
    startSidePanelAutoScan(false);
  }
})();