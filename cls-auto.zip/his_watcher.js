/* =========================================================
   HIS WATCHER — Gộp ngầm + Tự quét cả tab Lịch sử XN/CĐHA
                 + Tạm dừng ⏸/▶ + Popover + Dark Mode
   ========================================================= */
(function() {
  if (window.__clsHisWatcherCleanup) {
    try { window.__clsHisWatcherCleanup(); } catch {}
  }

  const SHARED_SETTINGS_KEY = 'cls_shared_settings';
  const MERGE_SESSION_KEY = 'cls_merge_session_v1';
  const CAPTURE_PAUSED_KEY = 'cls_capture_paused';
  const FLOAT_BAR_ID = 'cls-ext-float-bar';
  const POPOVER_ID = 'cls-ext-popover';
  const FLOAT_UI_KEY = 'cls_his_float_ui_v1';
  const SVG_NS = 'http://www.w3.org/2000/svg';

  const AUTO_SWEEP_MAX_ROWS = 10;
  const MANUAL_SWEEP_MAX_ROWS = 15;

  let mergeEnabled = true;
  let capturePaused = false;
  let isDark = true;
  let mergedCount = 0;
  let popoverOpen = false;
  let previewData = null;

  // Trạng thái tự quét theo tab (Cách 1)
  let isSweeping = false;
  let sweepAbort = false;
  let sweepProgressText = '';
  let hasSweepableList = false;
  const sweptSignatures = new Set();

  let t1 = null;
  let t2 = null;
  let mutTimer = null;
  let sweepCheckTimer = null;
  let hoverOpenTimer = null;
  let hoverCloseTimer = null;
  let copyFlashTimer = null;
  let observer = null;

  let uiPrefs = loadUiPrefs();

  function loadUiPrefs() {
    try {
      const parsed = JSON.parse(localStorage.getItem(FLOAT_UI_KEY) || '{}');
      return {
        right: typeof parsed.right === 'number' ? parsed.right : 24,
        bottom: typeof parsed.bottom === 'number' ? parsed.bottom : 18,
        collapsed: Boolean(parsed.collapsed)
      };
    } catch {
      return { right: 24, bottom: 18, collapsed: false };
    }
  }

  function saveUiPrefs() {
    try { localStorage.setItem(FLOAT_UI_KEY, JSON.stringify(uiPrefs)); } catch {}
  }

  function cleanText(s) {
    return String(s || '').replace(/\s+/g, ' ').trim();
  }

  function isVisible(node) {
    if (!node || !node.getBoundingClientRect) return false;
    const style = window.getComputedStyle(node);
    if (style.display === 'none' || style.visibility === 'hidden' || parseFloat(style.opacity) === 0) {
      return false;
    }
    const rect = node.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  }

  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  function showLocalToast(message, isWarn = false) {
    if (window !== window.top || !document.body) return;
    const id = 'cls-ext-page-toast';
    const old = document.getElementById(id);
    if (old) old.remove();

    const el = document.createElement('div');
    el.id = id;
    el.textContent = message;
    const bg = isWarn ? '#d97706' : (isDark ? '#0f766e' : '#0d9488');
    const border = isDark ? 'rgba(255,255,255,0.14)' : 'rgba(15,23,42,0.08)';
    el.style.cssText = [
      'position:fixed',
      'bottom:64px',
      'right:24px',
      'z-index:2147483647',
      'padding:9px 15px',
      'border-radius:10px',
      'font:600 12.5px/1.4 system-ui,-apple-system,Segoe UI,sans-serif',
      'color:#ffffff',
      `background:${bg}`,
      `border:1px solid ${border}`,
      'box-shadow:0 8px 24px rgba(0,0,0,0.22)',
      'transition:opacity 220ms ease',
      'pointer-events:none'
    ].join(';');
    document.body.appendChild(el);
    setTimeout(() => { el.style.opacity = '0'; }, 2200);
    setTimeout(() => { el.remove(); }, 2500);
  }

  function getPalette() {
    if (isDark) {
      return {
        barBg: 'rgba(28, 25, 23, 0.94)',
        barBorder: 'rgba(255, 255, 255, 0.13)',
        popBg: '#1c1917',
        popSub: '#24201e',
        popBorder: '#35312e',
        text: '#f5f5f4',
        muted: '#a8a29e',
        hover: 'rgba(255, 255, 255, 0.1)',
        primary: '#14b8a6',
        primaryText: '#5eead4',
        primarySoft: 'rgba(20, 184, 166, 0.18)',
        warnBg: 'rgba(245, 158, 11, 0.22)',
        warnText: '#fcd34d',
        dangerBg: 'rgba(239, 68, 68, 0.2)',
        dangerText: '#fca5a5',
        shadow: '0 10px 28px rgba(0, 0, 0, 0.45)',
        chips: {
          ctm:   { bg: '#4c111d', bd: '#9f1239', tx: '#fda4af' },
          shm:   { bg: '#083836', bd: '#115e59', tx: '#5eead4' },
          tptnt: { bg: '#422a08', bd: '#92400e', tx: '#fcd34d' },
          img:   { bg: '#142a4f', bd: '#1d4ed8', tx: '#93c5fd' },
          other: { bg: '#2e1852', bd: '#6d28d9', tx: '#c4b5fd' }
        }
      };
    }
    return {
      barBg: 'rgba(255, 255, 255, 0.96)',
      barBorder: '#d6d3d1',
      popBg: '#ffffff',
      popSub: '#fafaf9',
      popBorder: '#e7e5e4',
      text: '#1c1917',
      muted: '#57534e',
      hover: 'rgba(28, 25, 23, 0.06)',
      primary: '#0d9488',
      primaryText: '#0f766e',
      primarySoft: '#f0fdfa',
      warnBg: '#fef3c7',
      warnText: '#b45309',
      dangerBg: '#fef2f2',
      dangerText: '#b91c1c',
      shadow: '0 10px 28px rgba(15, 23, 42, 0.16)',
      chips: {
        ctm:   { bg: '#ffe4e6', bd: '#fda4af', tx: '#be123c' },
        shm:   { bg: '#ccfbf1', bd: '#5eead4', tx: '#0f766e' },
        tptnt: { bg: '#fef3c7', bd: '#fcd34d', tx: '#b45309' },
        img:   { bg: '#dbeafe', bd: '#93c5fd', tx: '#1d4ed8' },
        other: { bg: '#ede9fe', bd: '#c4b5fd', tx: '#6d28d9' }
      }
    };
  }

  function getChipKey(label) {
    const k = String(label || '').toUpperCase();
    if (k === 'CTM' || k === 'VSS') return 'ctm';
    if (k === 'SHM' || k === 'ĐGĐ') return 'shm';
    if (k === 'TPTNT') return 'tptnt';
    if (k === 'CĐHA' || k === 'TDCN') return 'img';
    return 'other';
  }

  function createSvg(paths, size = 13) {
    const svg = document.createElementNS(SVG_NS, 'svg');
    svg.setAttribute('viewBox', '0 0 24 24');
    svg.setAttribute('width', String(size));
    svg.setAttribute('height', String(size));
    svg.setAttribute('fill', 'none');
    svg.setAttribute('stroke', 'currentColor');
    svg.setAttribute('stroke-width', '1.9');
    svg.setAttribute('stroke-linecap', 'round');
    svg.setAttribute('stroke-linejoin', 'round');
    for (const def of paths) {
      const node = document.createElementNS(SVG_NS, def.tag);
      for (const [k, v] of Object.entries(def.attrs)) node.setAttribute(k, v);
      svg.appendChild(node);
    }
    return svg;
  }

  function isContextAlive() {
    try { return Boolean(chrome.runtime && chrome.runtime.id); } catch { return false; }
  }

  function stopObserver() {
    if (observer) {
      observer.disconnect();
      observer = null;
    }
  }

  function removePopover() {
    popoverOpen = false;
    const old = document.getElementById(POPOVER_ID);
    if (old) old.remove();
  }

  function removeFloatBar() {
    removePopover();
    const old = document.getElementById(FLOAT_BAR_ID);
    if (old) old.remove();
  }

  function clampBarPosition(bar) {
    if (!bar) return;
    const rect = bar.getBoundingClientRect();
    const maxR = Math.max(8, window.innerWidth - Math.max(rect.width, 60) - 8);
    const maxB = Math.max(8, window.innerHeight - Math.max(rect.height, 34) - 8);
    uiPrefs.right = Math.min(maxR, Math.max(8, Math.round(uiPrefs.right)));
    uiPrefs.bottom = Math.min(maxB, Math.max(8, Math.round(uiPrefs.bottom)));
    bar.style.right = uiPrefs.right + 'px';
    bar.style.bottom = uiPrefs.bottom + 'px';
    positionPopover();
  }

  function positionPopover() {
    const bar = document.getElementById(FLOAT_BAR_ID);
    const pop = document.getElementById(POPOVER_ID);
    if (!bar || !pop) return;

    const br = bar.getBoundingClientRect();
    const popW = Math.min(350, window.innerWidth - 20);
    pop.style.width = popW + 'px';

    let rightPx = window.innerWidth - br.right;
    rightPx = Math.max(10, Math.min(window.innerWidth - popW - 10, rightPx));
    pop.style.right = Math.round(rightPx) + 'px';

    if (br.top >= 220) {
      pop.style.top = 'auto';
      pop.style.bottom = Math.round(window.innerHeight - br.top + 8) + 'px';
    } else {
      pop.style.bottom = 'auto';
      pop.style.top = Math.round(br.bottom + 8) + 'px';
    }
  }

  /* =========================================================
     PHẦN TỰ QUÉT CẢ TAB LỊCH SỬ XN / CĐHA / TDCN (CÁCH 1)
     ========================================================= */
  function findHistoryModalContainer() {
    // Tìm các tab Lịch sử XN / CĐHA / TDCN đang hiển thị trong cửa sổ Lịch sử KCB
    const tabCandidates = Array.from(
      document.querySelectorAll('a, button, li, div, span')
    ).filter((node) => {
      if (!isVisible(node) || isOwnNode(node)) return false;
      if (node.childElementCount > 2) return false;
      const t = cleanText(node.textContent);
      return /^Lịch sử\s+(XN|CĐHA|TDCN)/i.test(t);
    });

    if (!tabCandidates.length) return null;

    let cur = tabCandidates[0].parentElement;
    for (let depth = 0; depth < 9 && cur && cur !== document.body; depth++) {
      const hasTable = cur.querySelector('table') !== null;
      const txt = cur.textContent || '';
      if (hasTable && /Lịch sử\s+XN/i.test(txt) && (/Lịch sử\s+CĐHA/i.test(txt) || /Lịch sử\s+KCB/i.test(txt))) {
        return cur;
      }
      cur = cur.parentElement;
    }
    return null;
  }

  function mapHistoryListHeader(row) {
    const map = { stt: -1, time: -1, service: -1, status: -1 };
    const cells = Array.from(row.cells || []);
    let hasDetailCols = 0;

    cells.forEach((cell, idx) => {
      const h = cleanText(cell.innerText || cell.textContent).toLowerCase();
      if (!h) return;
      if (h === 'chỉ số' || h.includes('chỉ số') || h === 'kết quả' || h.includes('tham chiếu') || h.includes('đơn vị')) {
        hasDetailCols++;
      }
      if (map.stt === -1 && /^(stt|tt|#)$/.test(h)) {
        map.stt = idx;
      } else if (map.time === -1 && (h.includes('tg chỉ định') || h.includes('thời gian') || h.includes('ngày chỉ định') || h.includes('ngày y lệnh'))) {
        map.time = idx;
      } else if (
        map.service === -1 &&
        (h.includes('loại xét nghiệm') || h.includes('loại dịch vụ') || h.includes('tên dịch vụ') ||
         h.includes('dịch vụ') || h.includes('nội dung') || h.includes('loại cđha') || h.includes('nhóm dịch vụ'))
      ) {
        map.service = idx;
      } else if (map.status === -1 && (h.includes('trạng thái') || h.includes('tình trạng'))) {
        map.status = idx;
      }
    });

    if (hasDetailCols >= 2) return null;
    if (map.status === -1 && map.time === -1) return null;
    if (map.service === -1 && map.stt === -1) return null;

    return map;
  }

  function isTodayFilterSelected(modal) {
    const selects = Array.from(modal.querySelectorAll('select')).filter(isVisible);
    for (const sel of selects) {
      const allOpts = Array.from(sel.options || []).map((o) => cleanText(o.text).toLowerCase()).join('|');
      if (/trong ngày|hôm nay|tất cả|7 ngày|30 ngày|tháng/.test(allOpts)) {
        const curText = cleanText(sel.options[sel.selectedIndex]?.text || '').toLowerCase();
        return /trong ngày|hôm nay/.test(curText);
      }
    }
    return true;
  }

  function extractModalPatientSig(modal) {
    const headerText = cleanText((modal.textContent || '').slice(0, 220));
    const m = headerText.match(/Mã:\s*([A-Z0-9_-]+)/i);
    if (m) return 'pid:' + m[1];
    const m2 = headerText.match(/Người bệnh:\s*([^|]+)/i);
    return m2 ? cleanText(m2[1]) : 'modal';
  }

  function findClickableInCell(cell) {
    if (!cell) return null;
    const explicit = cell.querySelector('a, button, [onclick], [ng-click], [role="button"], input[type="button"]');
    if (explicit && isVisible(explicit)) return explicit;

    const styled = Array.from(cell.querySelectorAll('span, div, label, p')).find((el) => {
      if (!isVisible(el) || !cleanText(el.textContent)) return false;
      const st = window.getComputedStyle(el);
      const hasBorder = st.borderTopWidth !== '0px' && st.borderTopStyle !== 'none';
      const hasBg = st.backgroundColor && st.backgroundColor !== 'rgba(0, 0, 0, 0)' && st.backgroundColor !== 'transparent';
      return st.cursor === 'pointer' || hasBorder || hasBg;
    });
    return styled || cell;
  }

  function findHistoryListContext() {
    const modal = findHistoryModalContainer();
    if (!modal) return null;

    const visibleTables = Array.from(modal.querySelectorAll('table')).filter(isVisible);
    let best = null;

    for (const table of visibleTables) {
      const headerCandidates = table.tHead
        ? Array.from(table.tHead.rows)
        : Array.from(table.rows).slice(0, 2);

      let colMap = null;
      let headerRowRef = null;
      for (const hRow of headerCandidates) {
        const m = mapHistoryListHeader(hRow);
        if (m) {
          colMap = m;
          headerRowRef = hRow;
          break;
        }
      }
      if (!colMap) continue;

      let bodyTable = null;
      let bodyRows = [];
      if (table.tBodies && table.tBodies.length) {
        for (const tb of table.tBodies) bodyRows.push(...Array.from(tb.rows));
      } else {
        bodyRows = Array.from(table.rows);
      }
      bodyRows = bodyRows.filter((r) => r !== headerRowRef && isVisible(r));

      // Trường hợp bảng HIS tách header và body thành 2 thẻ <table> riêng
      if (!bodyRows.length) {
        let parent = table.parentElement;
        for (let d = 0; d < 3 && parent && parent !== modal; d++) {
          const nextTable = Array.from(parent.querySelectorAll('table')).find((t) => {
            if (t === table || !isVisible(t)) return false;
            return Boolean(table.compareDocumentPosition(t) & Node.DOCUMENT_POSITION_FOLLOWING);
          });
          if (nextTable) {
            bodyTable = nextTable;
            bodyRows = (nextTable.tBodies?.length
              ? Array.from(nextTable.tBodies[0].rows)
              : Array.from(nextTable.rows)).filter(isVisible);
            break;
          }
          parent = parent.parentElement;
        }
      }

      const items = [];
      for (const row of bodyRows) {
        const cells = Array.from(row.cells || []);
        if (cells.length < 3) continue;
        if (cells.some((c) => (c.colSpan || 1) >= 3)) continue; // Bỏ qua dòng tên Khoa

        if (colMap.stt !== -1) {
          const sttTxt = cleanText(cells[colMap.stt]?.innerText || '');
          if (!/^\d+$/.test(sttTxt)) continue;
        }

        const statusCell = colMap.status !== -1 ? cells[colMap.status] : null;
        const statusTxt = statusCell ? cleanText(statusCell.innerText || '') : '';
        if (colMap.status !== -1) {
          if (!/hoàn tất|đã trả|đã duyệt|có kết quả|đã thực hiện/i.test(statusTxt)) continue;
          if (/chưa|hủy/i.test(statusTxt)) continue;
        } else {
          const rowTxt = cleanText(row.innerText || '');
          if (/chưa thực hiện|đang chờ|đã hủy/i.test(rowTxt)) continue;
        }

        const timeCell = colMap.time !== -1 ? cells[colMap.time] : cells[1] || null;
        const serviceCell = colMap.service !== -1 ? cells[colMap.service] : cells[Math.min(3, cells.length - 1)];
        const timeTxt = timeCell ? cleanText(timeCell.innerText || '') : '';
        const serviceTxt = serviceCell ? cleanText(serviceCell.innerText || '') : '';
        if (!serviceTxt && !timeTxt) continue;

        items.push({
          row,
          timeCell,
          serviceCell,
          statusCell,
          serviceTxt,
          sig: `${timeTxt}|${serviceTxt}|${statusTxt}`
        });
      }

      if (items.length) {
        best = {
          modal,
          listTable: bodyTable || table,
          listTables: [table, bodyTable].filter(Boolean),
          items,
          isToday: isTodayFilterSelected(modal),
          signature: `${extractModalPatientSig(modal)}##${items.map((x) => x.sig).join('||')}`
        };
        break;
      }
    }

    return best;
  }

  function isInsideListTables(node, listTables) {
    if (!node || !listTables?.length) return false;
    return listTables.some((t) => t === node || t.contains(node) || (node.contains && node.contains(t)));
  }

  function getDetailSnapshot(modal, listTable, listTables = []) {
    if (!modal) return '';
    const refTables = listTables.length ? listTables : (listTable ? [listTable] : []);
    const listRect = listTable ? listTable.getBoundingClientRect() : null;
    const parts = [];

    const otherTables = Array.from(modal.querySelectorAll('table')).filter((t) => {
      if (!isVisible(t) || isOwnNode(t)) return false;
      if (isInsideListTables(t, refTables)) return false;
      return true;
    });
    for (const t of otherTables) {
      const txt = cleanText(t.innerText);
      if (txt) parts.push(txt.slice(0, 260));
    }

    if (listRect) {
      const rightBlocks = Array.from(modal.querySelectorAll('div, section, article, p, textarea, iframe')).filter((el) => {
        if (!isVisible(el) || isOwnNode(el) || isInsideListTables(el, refTables)) return false;
        const r = el.getBoundingClientRect();
        return r.left >= listRect.right - 25 && r.width > 100 && r.height > 18;
      });
      for (const b of rightBlocks.slice(0, 8)) {
        const txt = b.tagName === 'IFRAME'
          ? (b.src || 'iframe')
          : cleanText(b.tagName === 'TEXTAREA' ? b.value : b.innerText);
        if (txt) parts.push(txt.slice(0, 180));
      }
    }

    return parts.join('|').slice(0, 700);
  }

  const ROW_CLICK_STRATEGIES = [
    { id: 'time-btn',   getTarget: (it) => findClickableInCell(it.timeCell), dbl: false },
    { id: 'status-btn', getTarget: (it) => findClickableInCell(it.statusCell), dbl: false },
    { id: 'row-click',  getTarget: (it) => it.row, dbl: false },
    { id: 'time-dbl',   getTarget: (it) => findClickableInCell(it.timeCell) || it.row, dbl: true },
    { id: 'row-dbl',    getTarget: (it) => it.row, dbl: true }
  ];

  function dispatchRowAction(target, useDblClick = false) {
    if (!target || !isContextAlive()) return Promise.resolve(false);
    const clickId = 'c' + Date.now() + '_' + Math.random().toString(36).slice(2, 7);
    target.setAttribute('data-cls-click-id', clickId);

    return new Promise((resolve) => {
      let done = false;
      const cleanup = () => {
        try {
          if (target.getAttribute('data-cls-click-id') === clickId) {
            target.removeAttribute('data-cls-click-id');
          }
        } catch {}
      };
      const timer = setTimeout(() => {
        if (!done) {
          done = true;
          cleanup();
          resolve(false);
        }
      }, 1500);

      try {
        chrome.runtime.sendMessage(
          { type: 'CLS_MAIN_CLICK', clickId, useDblClick: Boolean(useDblClick) },
          (res) => {
            void chrome.runtime.lastError;
            if (!done) {
              done = true;
              clearTimeout(timer);
              cleanup();
              resolve(Boolean(res?.ok));
            }
          }
        );
      } catch {
        clearTimeout(timer);
        cleanup();
        resolve(false);
      }
    });
  }

  function waitForDetailSettle(modal, listTable, listTables, prevSnap, noChangeMs = 900) {
    return new Promise((resolve) => {
      let changed = false;
      let settleTimer = null;
      let done = false;

      const finish = () => {
        if (done) return;
        done = true;
        clearTimeout(settleTimer);
        clearTimeout(noChangeTimer);
        clearTimeout(hardTimer);
        if (localObs) localObs.disconnect();
        resolve(changed);
      };

      const checkDiff = () => {
        if (sweepAbort || !document.contains(modal)) return finish();
        const curSnap = getDetailSnapshot(modal, listTable, listTables);
        if (curSnap && curSnap !== prevSnap) {
          changed = true;
          clearTimeout(settleTimer);
          settleTimer = setTimeout(finish, 360);
        }
      };

      const localObs = new MutationObserver((mutations) => {
        if (sweepAbort) return finish();
        const relevant = mutations.some((m) => {
          const t = m.target;
          if (isOwnNode(t)) return false;
          if (isInsideListTables(t, listTables)) return false;
          return true;
        });
        if (relevant) checkDiff();
      });

      try {
        localObs.observe(modal, { childList: true, subtree: true, characterData: true });
      } catch {}

      const noChangeTimer = setTimeout(() => {
        checkDiff();
        if (!changed) finish();
      }, noChangeMs);

      const hardTimer = setTimeout(finish, 2200);
    });
  }

  function sendAutoCaptureAwait() {
    return new Promise((resolve) => {
      if (!isContextAlive()) {
        teardown();
        return resolve(null);
      }
      let settled = false;
      const timer = setTimeout(() => {
        if (!settled) {
          settled = true;
          resolve(null);
        }
      }, 2600);

      try {
        chrome.runtime.sendMessage({ type: 'CLS_BG_AUTO_CAPTURE' }, (res) => {
          void chrome.runtime.lastError;
          if (!settled) {
            settled = true;
            clearTimeout(timer);
            resolve(res || null);
          }
        });
      } catch {
        clearTimeout(timer);
        resolve(null);
      }
    });
  }

  async function runTabSweep(manual = false) {
    if (isSweeping || !mergeEnabled) return;
    if (!manual && capturePaused) return;

    const ctx = findHistoryListContext();
    if (!ctx || !ctx.items.length) {
      if (manual) showLocalToast('Không tìm thấy phiếu Hoàn tất trong tab này', true);
      return;
    }

    const maxRows = manual ? MANUAL_SWEEP_MAX_ROWS : AUTO_SWEEP_MAX_ROWS;
    if (!manual) {
      if (!ctx.isToday) return;
      if (ctx.items.length > maxRows) return;
      if (sweptSignatures.has(ctx.signature)) return;
    }

    const targets = ctx.items.slice(0, maxRows);
    isSweeping = true;
    sweepAbort = false;
    sweptSignatures.add(ctx.signature);
    if (sweptSignatures.size > 40) sweptSignatures.clear();

    clearTimeout(t1);
    clearTimeout(t2);
    clearTimeout(mutTimer);
    removePopover();

    let workingStrategy = null;
    let openedCount = 0;

    try {
      for (let i = 0; i < targets.length; i++) {
        if (sweepAbort || !isContextAlive() || (!manual && capturePaused)) break;
        const item = targets[i];
        if (!document.contains(item.row) || !isVisible(item.row)) break;

        sweepProgressText = `Quét ${i + 1}/${targets.length}…`;
        renderFloatBar();

        const prevSnap = getDetailSnapshot(ctx.modal, ctx.listTable, ctx.listTables);
        let detailChanged = false;

        if (workingStrategy) {
          const target = workingStrategy.getTarget(item);
          if (target) {
            const settlePromise = waitForDetailSettle(ctx.modal, ctx.listTable, ctx.listTables, prevSnap, 900);
            await dispatchRowAction(target, workingStrategy.dbl);
            detailChanged = await settlePromise;
          }
        } else {
          // Tự dò đúng vị trí click mở được chi tiết trên HIS (ưu tiên ô khung cam TG chỉ định)
          const tried = new Set();
          for (const strat of ROW_CLICK_STRATEGIES) {
            if (sweepAbort) break;
            const target = strat.getTarget(item);
            if (!target) continue;
            const dedupKey = strat.dbl ? 'dbl' : 'clk';
            if (tried.has(target) && tried.has(dedupKey + strat.id)) continue;
            tried.add(target);
            tried.add(dedupKey + strat.id);

            const settlePromise = waitForDetailSettle(ctx.modal, ctx.listTable, ctx.listTables, prevSnap, 650);
            await dispatchRowAction(target, strat.dbl);
            const ok = await settlePromise;
            if (ok) {
              workingStrategy = strat;
              detailChanged = true;
              break;
            }
          }
        }

        if (sweepAbort) break;

        // Nếu dòng đầu tiên không mở được khung bên phải ở bất kỳ kiểu click nào -> dừng sớm, tránh chạy ảo 10 dòng
        if (!detailChanged && !prevSnap && i === 0) {
          break;
        }

        if (detailChanged || prevSnap) {
          await sendAutoCaptureAwait();
          if (detailChanged || i === 0) openedCount++;
        }

        if (i < targets.length - 1 && !sweepAbort) {
          await sleep(220);
        }
      }
    } finally {
      const wasAborted = sweepAbort;
      isSweeping = false;
      sweepAbort = false;
      sweepProgressText = '';
      renderFloatBar();

      if (openedCount === 0 && !wasAborted) {
        sweptSignatures.delete(ctx.signature);
        showLocalToast('Không mở được chi tiết phiếu — thử mở tay 1 phiếu để kiểm tra', true);
      } else if (!wasAborted && openedCount > 0) {
        showLocalToast(`✓ Đã tự quét xong ${openedCount}/${targets.length} phiếu trong tab`, false);
      } else if (wasAborted && openedCount > 0) {
        showLocalToast(`Đã dừng tự quét (${openedCount}/${targets.length} phiếu)`, true);
      }
    }
  }

  function checkAutoSweep(delay = 550) {
    clearTimeout(sweepCheckTimer);
    sweepCheckTimer = setTimeout(() => {
      if (isSweeping || !isContextAlive()) return;
      const ctx = findHistoryListContext();
      const nextHasList = Boolean(ctx && ctx.items.length > 0);
      if (nextHasList !== hasSweepableList) {
        hasSweepableList = nextHasList;
        renderFloatBar();
      }
      if (
        nextHasList &&
        mergeEnabled &&
        !capturePaused &&
        ctx.isToday &&
        ctx.items.length <= AUTO_SWEEP_MAX_ROWS &&
        !sweptSignatures.has(ctx.signature)
      ) {
        runTabSweep(false);
      }
    }, delay);
  }

  /* =========================================================
     THANH NỔI & POPOVER XEM TRƯỚC
     ========================================================= */
  function updatePauseButton(pauseBtn) {
    if (!pauseBtn) return;
    const p = getPalette();
    pauseBtn.textContent = '';
    if (capturePaused) {
      pauseBtn.appendChild(createSvg([
        { tag: 'polygon', attrs: { points: '7 5 19 12 7 19 7 5', fill: 'currentColor' } }
      ], 11));
      pauseBtn.title = 'Đang tạm dừng gộp — bấm để tiếp tục tự động gộp';
      pauseBtn.style.background = p.warnBg;
      pauseBtn.style.color = p.warnText;
    } else {
      pauseBtn.appendChild(createSvg([
        { tag: 'line', attrs: { x1: '9', y1: '5', x2: '9', y2: '19' } },
        { tag: 'line', attrs: { x1: '15', y1: '5', x2: '15', y2: '19' } }
      ], 11));
      pauseBtn.title = 'Tạm dừng tự động gộp (khi cần xem lại lịch sử cũ)';
      pauseBtn.style.background = p.hover;
      pauseBtn.style.color = p.muted;
    }
  }

  function updateSweepButton(sweepBtn) {
    if (!sweepBtn) return;
    const p = getPalette();
    sweepBtn.textContent = '';

    if (isSweeping) {
      sweepBtn.appendChild(createSvg([
        { tag: 'rect', attrs: { x: '6', y: '6', width: '12', height: '12', rx: '2', fill: 'currentColor' } }
      ], 10));
      const lbl = document.createElement('span');
      lbl.textContent = 'Dừng';
      sweepBtn.appendChild(lbl);
      sweepBtn.title = 'Dừng tự động quét tab';
      sweepBtn.style.background = p.warnBg;
      sweepBtn.style.color = p.warnText;
    } else {
      sweepBtn.appendChild(createSvg([
        { tag: 'polygon', attrs: { points: '13 2 3 14 12 14 11 22 21 10 12 10 13 2' } }
      ], 11));
      const lbl = document.createElement('span');
      lbl.textContent = 'Quét tab';
      sweepBtn.appendChild(lbl);
      sweepBtn.title = 'Tự động quét hết các phiếu Hoàn tất trong tab hiện tại';
      sweepBtn.style.background = p.primarySoft;
      sweepBtn.style.color = p.primaryText;
    }
  }

  function applyBarTheme(bar) {
    if (!bar) return;
    const p = getPalette();
    bar.style.background = p.barBg;
    bar.style.borderColor = (capturePaused || isSweeping) ? '#d97706' : p.barBorder;
    bar.style.color = p.text;
    bar.style.boxShadow = p.shadow;

    const grip = bar.querySelector('#cls-ext-float-grip');
    if (grip) grip.style.color = p.muted;

    const dot = bar.querySelector('#cls-ext-float-dot');
    if (dot) dot.style.background = (capturePaused || isSweeping) ? '#f59e0b' : '#14b8a6';

    const copyBtn = bar.querySelector('#cls-ext-float-copy');
    if (copyBtn) copyBtn.style.color = p.text;

    updateSweepButton(bar.querySelector('#cls-ext-float-sweep'));
    updatePauseButton(bar.querySelector('#cls-ext-float-pause'));

    const collapseBtn = bar.querySelector('#cls-ext-float-collapse');
    if (collapseBtn) {
      collapseBtn.style.background = p.hover;
      collapseBtn.style.color = p.muted;
    }

    const clearBtn = bar.querySelector('#cls-ext-float-clear');
    if (clearBtn) {
      clearBtn.style.background = p.dangerBg;
      clearBtn.style.color = p.dangerText;
    }
  }

  function renderPopoverContent() {
    const pop = document.getElementById(POPOVER_ID);
    if (!pop) return;
    const p = getPalette();

    pop.style.background = p.popBg;
    pop.style.borderColor = p.popBorder;
    pop.style.color = p.text;
    pop.style.boxShadow = p.shadow;
    pop.textContent = '';

    const head = document.createElement('div');
    head.style.cssText = [
      'display:flex',
      'align-items:center',
      'justify-content:space-between',
      'gap:8px',
      'padding:8px 10px',
      `border-bottom:1px solid ${p.popBorder}`,
      `background:${p.popSub}`
    ].join(';');

    const title = document.createElement('div');
    const pt = previewData?.patient;
    const bn = pt?.name && pt?.id ? `${pt.name} (${pt.id})` : (pt?.name || pt?.id || `Bộ gộp (${mergedCount} phiếu)`);
    title.textContent = capturePaused ? `${bn} — Tạm dừng` : bn;
    title.title = bn;
    title.style.cssText = [
      'font-size:11.5px',
      'font-weight:700',
      `color:${capturePaused ? p.warnText : p.primaryText}`,
      'white-space:nowrap',
      'overflow:hidden',
      'text-overflow:ellipsis',
      'min-width:0'
    ].join(';');

    const headActs = document.createElement('div');
    headActs.style.cssText = 'display:inline-flex;align-items:center;gap:5px;flex-shrink:0;';

    const copyNowBtn = document.createElement('button');
    copyNowBtn.type = 'button';
    copyNowBtn.style.cssText = [
      'display:inline-flex',
      'align-items:center',
      'gap:4px',
      'border:none',
      `background:${p.primary}`,
      'color:#ffffff',
      'padding:3px 9px',
      'border-radius:6px',
      'font:600 11px/1.2 system-ui,-apple-system,Segoe UI,sans-serif',
      'cursor:pointer'
    ].join(';');
    copyNowBtn.appendChild(createSvg([
      { tag: 'rect', attrs: { x: '9', y: '9', width: '13', height: '13', rx: '2' } },
      { tag: 'path', attrs: { d: 'M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1' } }
    ], 11));
    const copyLbl = document.createElement('span');
    copyLbl.textContent = 'Copy';
    copyNowBtn.appendChild(copyLbl);
    copyNowBtn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      if (!isContextAlive()) return teardown();
      chrome.runtime.sendMessage({ type: 'CLS_COPY_MERGED' }, (res) => {
        void chrome.runtime.lastError;
        if (res?.ok) {
          copyLbl.textContent = 'Đã copy';
          setTimeout(() => { copyLbl.textContent = 'Copy'; }, 1200);
        }
      });
    });

    const closeBtn = document.createElement('button');
    closeBtn.type = 'button';
    closeBtn.title = 'Đóng xem trước';
    closeBtn.style.cssText = [
      'width:20px',
      'height:20px',
      'border-radius:6px',
      'border:none',
      'background:transparent',
      `color:${p.muted}`,
      'display:inline-flex',
      'align-items:center',
      'justify-content:center',
      'cursor:pointer'
    ].join(';');
    closeBtn.appendChild(createSvg([
      { tag: 'line', attrs: { x1: '18', y1: '6', x2: '6', y2: '18' } },
      { tag: 'line', attrs: { x1: '6', y1: '6', x2: '18', y2: '18' } }
    ], 12));
    closeBtn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      removePopover();
    });

    headActs.appendChild(copyNowBtn);
    headActs.appendChild(closeBtn);
    head.appendChild(title);
    head.appendChild(headActs);
    pop.appendChild(head);

    const sheets = Array.isArray(previewData?.sheets) ? previewData.sheets : [];
    if (sheets.length) {
      const chipWrap = document.createElement('div');
      chipWrap.style.cssText = [
        'display:flex',
        'flex-wrap:wrap',
        'gap:5px',
        'padding:7px 10px',
        `border-bottom:1px solid ${p.popBorder}`
      ].join(';');

      sheets.forEach((s, idx) => {
        const c = p.chips[getChipKey(s.label)] || p.chips.other;
        const chip = document.createElement('span');
        chip.title = [s.serviceName || s.label, s.resultTime].filter(Boolean).join(' — ');
        chip.style.cssText = [
          'display:inline-flex',
          'align-items:center',
          'gap:4px',
          'max-width:100%',
          'padding:2px 5px 2px 8px',
          'border-radius:999px',
          `background:${c.bg} !important`,
          `border:1px solid ${c.bd} !important`,
          `color:${c.tx} !important`,
          'font:600 11px/1.25 system-ui,-apple-system,Segoe UI,sans-serif'
        ].join(';');

        const isImg = s.label === 'CĐHA' || s.label === 'TDCN';
        const txt = document.createElement('span');
        txt.textContent = isImg && s.displayName
          ? s.displayName
          : `${s.label}${s.count ? ` (${s.count})` : ''}`;
        txt.style.cssText = 'max-width:220px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;display:inline-block;';

        const del = document.createElement('button');
        del.type = 'button';
        del.textContent = '×';
        del.title = 'Bỏ riêng phiếu này';
        del.style.cssText = [
          'border:none',
          'background:transparent',
          'color:inherit',
          'width:15px',
          'height:15px',
          'border-radius:50%',
          'display:inline-flex',
          'align-items:center',
          'justify-content:center',
          'font-size:12px',
          'line-height:1',
          'cursor:pointer',
          'opacity:0.75',
          'flex-shrink:0'
        ].join(';');
        del.addEventListener('mouseenter', () => {
          del.style.background = '#dc2626';
          del.style.color = '#ffffff';
          del.style.opacity = '1';
        });
        del.addEventListener('mouseleave', () => {
          del.style.background = 'transparent';
          del.style.color = 'inherit';
          del.style.opacity = '0.75';
        });
        del.addEventListener('click', (e) => {
          e.preventDefault();
          e.stopPropagation();
          if (!isContextAlive()) return teardown();
          clearTimeout(t1);
          clearTimeout(t2);
          clearTimeout(mutTimer);
          chrome.runtime.sendMessage({ type: 'CLS_REMOVE_SHEET', index: idx }, (res) => {
            void chrome.runtime.lastError;
            if (res?.ok) {
              previewData = res;
              if (!res.sheets?.length) removePopover();
              else renderPopoverContent();
            }
          });
        });

        chip.appendChild(txt);
        chip.appendChild(del);
        chipWrap.appendChild(chip);
      });
      pop.appendChild(chipWrap);
    }

    const body = document.createElement('div');
    body.style.cssText = [
      'padding:9px 10px',
      'max-height:165px',
      'overflow-y:auto',
      'font:500 11.5px/1.6 ui-monospace,Cascadia Mono,Consolas,monospace',
      'white-space:pre-wrap',
      'word-break:break-word',
      `color:${p.text}`
    ].join(';');
    body.textContent = previewData
      ? (previewData.plain || 'Không có chỉ số nào khớp bộ lọc hiện tại.')
      : 'Đang tải xem trước…';
    pop.appendChild(body);

    positionPopover();
  }

  function fetchPreviewAndRender() {
    if (!isContextAlive()) return teardown();
    chrome.runtime.sendMessage({ type: 'CLS_GET_MERGED_PREVIEW' }, (res) => {
      void chrome.runtime.lastError;
      if (res?.ok) {
        previewData = res;
        if (popoverOpen) renderPopoverContent();
      }
    });
  }

  function openPopover() {
    if (window !== window.top || !document.body || mergedCount <= 0 || isSweeping) return;
    clearTimeout(hoverCloseTimer);

    let pop = document.getElementById(POPOVER_ID);
    if (!pop) {
      pop = document.createElement('div');
      pop.id = POPOVER_ID;
      pop.style.cssText = [
        'position:fixed',
        'z-index:2147483646',
        'border-radius:12px',
        'border:1px solid transparent',
        'overflow:hidden',
        'font-family:system-ui,-apple-system,Segoe UI,sans-serif'
      ].join(';');

      pop.addEventListener('mouseenter', () => clearTimeout(hoverCloseTimer));
      pop.addEventListener('mouseleave', scheduleClosePopover);
      document.body.appendChild(pop);
    }

    popoverOpen = true;
    renderPopoverContent();
    fetchPreviewAndRender();
  }

  function scheduleClosePopover() {
    clearTimeout(hoverOpenTimer);
    clearTimeout(hoverCloseTimer);
    hoverCloseTimer = setTimeout(removePopover, 240);
  }

  function updateBarText(bar) {
    if (!bar) return;
    const labelEl = bar.querySelector('#cls-ext-float-label');
    const sweepBtn = bar.querySelector('#cls-ext-float-sweep');
    const pauseBtn = bar.querySelector('#cls-ext-float-pause');
    const clearBtn = bar.querySelector('#cls-ext-float-clear');
    const collapseBtn = bar.querySelector('#cls-ext-float-collapse');
    const grip = bar.querySelector('#cls-ext-float-grip');

    if (uiPrefs.collapsed && !isSweeping) {
      if (labelEl) labelEl.textContent = capturePaused ? (mergedCount > 0 ? `${mergedCount} ⏸` : '⏸') : String(mergedCount);
      if (sweepBtn) sweepBtn.style.display = 'none';
      if (pauseBtn) pauseBtn.style.display = capturePaused ? 'inline-flex' : 'none';
      if (clearBtn) clearBtn.style.display = 'none';
      if (grip) grip.style.display = 'none';
      if (collapseBtn) {
        collapseBtn.style.display = 'inline-flex';
        collapseBtn.textContent = '◂';
        collapseBtn.title = 'Mở rộng thanh CLS';
      }
    } else {
      if (labelEl) {
        if (isSweeping && sweepProgressText) labelEl.textContent = sweepProgressText;
        else if (mergedCount > 0) labelEl.textContent = `CLS: ${mergedCount} phiếu`;
        else if (capturePaused) labelEl.textContent = 'CLS: Tạm dừng';
        else labelEl.textContent = 'CLS';
      }
      if (sweepBtn) sweepBtn.style.display = (hasSweepableList || isSweeping) ? 'inline-flex' : 'none';
      if (pauseBtn) pauseBtn.style.display = isSweeping ? 'none' : 'inline-flex';
      if (clearBtn) clearBtn.style.display = (!isSweeping && mergedCount > 0) ? 'inline-flex' : 'none';
      if (grip) grip.style.display = 'inline-flex';
      if (collapseBtn) {
        collapseBtn.style.display = isSweeping ? 'none' : 'inline-flex';
        collapseBtn.textContent = '–';
        collapseBtn.title = 'Thu gọn thanh CLS';
      }
    }
    applyBarTheme(bar);
    clampBarPosition(bar);
  }

  function renderFloatBar() {
    if (window !== window.top || !document.body) return;

    if (!mergeEnabled || (mergedCount <= 0 && !capturePaused && !hasSweepableList && !isSweeping)) {
      removeFloatBar();
      return;
    }

    let bar = document.getElementById(FLOAT_BAR_ID);
    if (!bar) {
      bar = document.createElement('div');
      bar.id = FLOAT_BAR_ID;
      bar.style.cssText = [
        'position:fixed',
        `bottom:${uiPrefs.bottom}px`,
        `right:${uiPrefs.right}px`,
        'z-index:2147483646',
        'display:inline-flex',
        'align-items:center',
        'gap:5px',
        'padding:5px 7px 5px 8px',
        'border-radius:999px',
        'border:1px solid transparent',
        'font:600 12px/1.2 system-ui,-apple-system,Segoe UI,sans-serif',
        'backdrop-filter:blur(8px)',
        'user-select:none'
      ].join(';');

      // Tay nắm kéo vị trí
      const grip = document.createElement('span');
      grip.id = 'cls-ext-float-grip';
      grip.title = 'Kéo để di chuyển thanh nổi';
      grip.style.cssText = 'display:inline-flex;align-items:center;padding:2px;cursor:grab;opacity:0.65;';
      grip.appendChild(createSvg([
        { tag: 'circle', attrs: { cx: '9', cy: '6', r: '1.2', fill: 'currentColor', stroke: 'none' } },
        { tag: 'circle', attrs: { cx: '15', cy: '6', r: '1.2', fill: 'currentColor', stroke: 'none' } },
        { tag: 'circle', attrs: { cx: '9', cy: '12', r: '1.2', fill: 'currentColor', stroke: 'none' } },
        { tag: 'circle', attrs: { cx: '15', cy: '12', r: '1.2', fill: 'currentColor', stroke: 'none' } },
        { tag: 'circle', attrs: { cx: '9', cy: '18', r: '1.2', fill: 'currentColor', stroke: 'none' } },
        { tag: 'circle', attrs: { cx: '15', cy: '18', r: '1.2', fill: 'currentColor', stroke: 'none' } }
      ], 12));

      // Nhãn CLS: N phiếu (bấm để copy nhanh, di chuột mở Popover xem trước)
      const copyBtn = document.createElement('button');
      copyBtn.type = 'button';
      copyBtn.id = 'cls-ext-float-copy';
      copyBtn.title = 'Bấm để copy nhanh — Di chuột để xem trước & xóa lẻ phiếu';
      copyBtn.style.cssText = [
        'display:inline-flex',
        'align-items:center',
        'gap:6px',
        'border:none',
        'background:transparent',
        'padding:3px 7px',
        'border-radius:999px',
        'font:600 12px/1.2 system-ui,-apple-system,Segoe UI,sans-serif',
        'cursor:pointer',
        'transition:background 120ms ease'
      ].join(';');

      const dot = document.createElement('span');
      dot.id = 'cls-ext-float-dot';
      dot.style.cssText = 'width:7px;height:7px;border-radius:50%;background:#14b8a6;flex-shrink:0;';

      const label = document.createElement('span');
      label.id = 'cls-ext-float-label';

      copyBtn.appendChild(dot);
      copyBtn.appendChild(label);

      copyBtn.addEventListener('mouseenter', () => {
        copyBtn.style.background = getPalette().primarySoft;
        if (mergedCount > 0 && !isSweeping) {
          clearTimeout(hoverCloseTimer);
          hoverOpenTimer = setTimeout(openPopover, 160);
        }
      });
      copyBtn.addEventListener('mouseleave', () => {
        copyBtn.style.background = 'transparent';
        clearTimeout(hoverOpenTimer);
        scheduleClosePopover();
      });
      copyBtn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        if (!isContextAlive()) return teardown();
        if (mergedCount <= 0 || isSweeping) return;
        chrome.runtime.sendMessage({ type: 'CLS_COPY_MERGED' }, (res) => {
          void chrome.runtime.lastError;
          if (res?.ok && label) {
            clearTimeout(copyFlashTimer);
            label.textContent = uiPrefs.collapsed ? '✓' : '✓ Đã copy';
            copyFlashTimer = setTimeout(() => updateBarText(bar), 1200);
          }
        });
      });

      // Nút Quét cả tab / Dừng
      const sweepBtn = document.createElement('button');
      sweepBtn.type = 'button';
      sweepBtn.id = 'cls-ext-float-sweep';
      sweepBtn.style.cssText = [
        'display:none',
        'align-items:center',
        'gap:4px',
        'border:none',
        'padding:3px 9px',
        'border-radius:999px',
        'font:600 11.5px/1.2 system-ui,-apple-system,Segoe UI,sans-serif',
        'cursor:pointer',
        'transition:background 120ms ease,color 120ms ease'
      ].join(';');
      sweepBtn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        if (!isContextAlive()) return teardown();
        if (isSweeping) {
          sweepAbort = true;
        } else {
          runTabSweep(true);
        }
      });

      // Nút Tạm dừng / Tiếp tục gộp (⏸ / ▶)
      const pauseBtn = document.createElement('button');
      pauseBtn.type = 'button';
      pauseBtn.id = 'cls-ext-float-pause';
      pauseBtn.style.cssText = [
        'border:none',
        'width:22px',
        'height:22px',
        'border-radius:50%',
        'display:inline-flex',
        'align-items:center',
        'justify-content:center',
        'cursor:pointer',
        'transition:background 120ms ease,color 120ms ease'
      ].join(';');
      pauseBtn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        if (!isContextAlive()) return teardown();
        clearTimeout(t1);
        clearTimeout(t2);
        clearTimeout(mutTimer);
        sweepAbort = true;
        chrome.runtime.sendMessage({ type: 'CLS_TOGGLE_PAUSE' }, () => {
          void chrome.runtime.lastError;
        });
      });

      // Nút thu gọn / mở rộng
      const collapseBtn = document.createElement('button');
      collapseBtn.type = 'button';
      collapseBtn.id = 'cls-ext-float-collapse';
      collapseBtn.style.cssText = [
        'border:none',
        'width:20px',
        'height:20px',
        'border-radius:50%',
        'display:inline-flex',
        'align-items:center',
        'justify-content:center',
        'font:700 12px/1 system-ui,sans-serif',
        'cursor:pointer',
        'transition:opacity 120ms ease'
      ].join(';');
      collapseBtn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        uiPrefs.collapsed = !uiPrefs.collapsed;
        saveUiPrefs();
        updateBarText(bar);
      });

      // Nút xóa toàn bộ bộ gộp
      const clearBtn = document.createElement('button');
      clearBtn.type = 'button';
      clearBtn.id = 'cls-ext-float-clear';
      clearBtn.title = 'Xóa toàn bộ bộ gộp (Alt+Shift+X)';
      clearBtn.style.cssText = [
        'display:inline-flex',
        'align-items:center',
        'gap:3px',
        'border:none',
        'padding:3px 8px',
        'border-radius:999px',
        'font:600 11.5px/1.2 system-ui,-apple-system,Segoe UI,sans-serif',
        'cursor:pointer',
        'transition:background 120ms ease,color 120ms ease'
      ].join(';');
      clearBtn.appendChild(createSvg([
        { tag: 'line', attrs: { x1: '18', y1: '6', x2: '6', y2: '18' } },
        { tag: 'line', attrs: { x1: '6', y1: '6', x2: '18', y2: '18' } }
      ], 11));
      const clrTxt = document.createElement('span');
      clrTxt.textContent = 'Xóa';
      clearBtn.appendChild(clrTxt);

      clearBtn.addEventListener('mouseenter', () => {
        clearBtn.style.background = '#dc2626';
        clearBtn.style.color = '#ffffff';
      });
      clearBtn.addEventListener('mouseleave', () => {
        const pal = getPalette();
        clearBtn.style.background = pal.dangerBg;
        clearBtn.style.color = pal.dangerText;
      });
      clearBtn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        if (!isContextAlive()) return teardown();
        clearTimeout(t1);
        clearTimeout(t2);
        clearTimeout(mutTimer);
        sweepAbort = true;
        removePopover();
        chrome.runtime.sendMessage({ type: 'CLS_CLEAR_MERGE' }, () => {
          void chrome.runtime.lastError;
        });
      });

      // Kéo thả thanh nổi
      let dragState = null;
      grip.addEventListener('pointerdown', (e) => {
        e.preventDefault();
        e.stopPropagation();
        grip.setPointerCapture(e.pointerId);
        grip.style.cursor = 'grabbing';
        dragState = {
          startX: e.clientX,
          startY: e.clientY,
          origRight: uiPrefs.right,
          origBottom: uiPrefs.bottom
        };
      });
      grip.addEventListener('pointermove', (e) => {
        if (!dragState) return;
        uiPrefs.right = dragState.origRight - (e.clientX - dragState.startX);
        uiPrefs.bottom = dragState.origBottom - (e.clientY - dragState.startY);
        clampBarPosition(bar);
      });
      const finishDrag = (e) => {
        if (!dragState) return;
        try { grip.releasePointerCapture(e.pointerId); } catch {}
        grip.style.cursor = 'grab';
        dragState = null;
        saveUiPrefs();
      };
      grip.addEventListener('pointerup', finishDrag);
      grip.addEventListener('pointercancel', finishDrag);

      bar.appendChild(grip);
      bar.appendChild(copyBtn);
      bar.appendChild(sweepBtn);
      bar.appendChild(pauseBtn);
      bar.appendChild(collapseBtn);
      bar.appendChild(clearBtn);
      document.body.appendChild(bar);
    }

    updateBarText(bar);
  }

  function onWinResize() {
    const bar = document.getElementById(FLOAT_BAR_ID);
    if (bar) clampBarPosition(bar);
  }

  function updateSessionState(session) {
    const sheets = Array.isArray(session?.sheets) ? session.sheets : [];
    mergedCount = sheets.length;
    if (mergedCount <= 0) {
      previewData = null;
      removePopover();
    }
    renderFloatBar();
    if (popoverOpen && mergedCount > 0) fetchPreviewAndRender();
  }

  function isOwnNode(node) {
    if (!node) return false;
    const elem = node.nodeType === 1 ? node : node.parentElement;
    if (!elem) return false;
    return Boolean(
      elem.id === 'cls-ext-page-toast' ||
      elem.id === 'cls-ext-copy-tmp' ||
      elem.id === FLOAT_BAR_ID ||
      elem.id === POPOVER_ID ||
      elem.closest?.(`#${FLOAT_BAR_ID}, #${POPOVER_ID}, #cls-ext-page-toast`)
    );
  }

  function isRelevantMutation(m) {
    if (isOwnNode(m.target)) return false;
    const added = Array.from(m.addedNodes || []);
    const removed = Array.from(m.removedNodes || []);
    if ((added.length || removed.length) && [...added, ...removed].every(isOwnNode)) {
      return false;
    }
    return true;
  }

  function triggerCapture() {
    if (!mergeEnabled || capturePaused || isSweeping) return;
    if (!isContextAlive()) return teardown();
    try {
      chrome.runtime.sendMessage({ type: 'CLS_BG_AUTO_CAPTURE' }, () => {
        void chrome.runtime.lastError;
      });
    } catch {
      teardown();
    }
  }

  function scheduleCapture() {
    if (!mergeEnabled || capturePaused || isSweeping) return;
    clearTimeout(t1);
    clearTimeout(t2);
    t1 = setTimeout(triggerCapture, 650);
    t2 = setTimeout(triggerCapture, 1800);
  }

  function startObserver() {
    if (observer || !document.body) return;
    observer = new MutationObserver((mutations) => {
      if (!mergeEnabled || capturePaused || isSweeping) return;
      if (!mutations.some(isRelevantMutation)) return;
      clearTimeout(mutTimer);
      mutTimer = setTimeout(triggerCapture, 550);
      checkAutoSweep(650);
    });
    observer.observe(document.body, { childList: true, subtree: true, characterData: true });
  }

  function syncObserverState() {
    if (mergeEnabled && !capturePaused) {
      startObserver();
    } else {
      clearTimeout(t1);
      clearTimeout(t2);
      clearTimeout(mutTimer);
      clearTimeout(sweepCheckTimer);
      stopObserver();
    }
  }

  function applySettings(settings, triggerIfJustOn = false) {
    const wasOn = mergeEnabled;
    mergeEnabled = settings?.mergeEnabled !== false;
    isDark = settings?.darkMode !== false;

    syncObserverState();
    if (mergeEnabled && !capturePaused && triggerIfJustOn && !wasOn && window === window.top) {
      setTimeout(triggerCapture, 250);
      checkAutoSweep(400);
    }
    renderFloatBar();
    if (popoverOpen) fetchPreviewAndRender();
  }

  function applyPausedState(paused) {
    capturePaused = Boolean(paused);
    if (capturePaused) sweepAbort = true;
    syncObserverState();
    renderFloatBar();
    if (popoverOpen) renderPopoverContent();
  }

  function onDocClick(e) {
    if (!isContextAlive()) return teardown();
    if (!e.isTrusted) return; // Bỏ qua click tự động của chính script
    if (isOwnNode(e.target)) return;

    // Nếu người dùng tự click tay khi đang tự quét -> nhường quyền ngay
    if (isSweeping) sweepAbort = true;
    if (popoverOpen) removePopover();
    if (!mergeEnabled || capturePaused) return;

    const target = e.target;
    const tag = (target?.tagName || '').toUpperCase();
    if (
      (tag === 'TEXTAREA' || (tag === 'INPUT' && target.type !== 'checkbox' && target.type !== 'radio')) &&
      !target.readOnly && !target.disabled
    ) {
      return;
    }

    scheduleCapture();
    checkAutoSweep(650);
  }

  function onStorageChanged(changes, area) {
    if (area !== 'local') return;
    if (changes[SHARED_SETTINGS_KEY]?.newValue) {
      applySettings(changes[SHARED_SETTINGS_KEY].newValue, true);
    }
    if (changes[CAPTURE_PAUSED_KEY]) {
      applyPausedState(changes[CAPTURE_PAUSED_KEY].newValue);
    }
    if (changes[MERGE_SESSION_KEY]) {
      updateSessionState(changes[MERGE_SESSION_KEY].newValue || null);
    }
  }

  function teardown() {
    sweepAbort = true;
    isSweeping = false;
    clearTimeout(t1);
    clearTimeout(t2);
    clearTimeout(mutTimer);
    clearTimeout(sweepCheckTimer);
    clearTimeout(hoverOpenTimer);
    clearTimeout(hoverCloseTimer);
    clearTimeout(copyFlashTimer);
    stopObserver();
    removeFloatBar();
    document.removeEventListener('click', onDocClick, true);
    window.removeEventListener('resize', onWinResize);
    try { chrome.storage.onChanged.removeListener(onStorageChanged); } catch {}
    window.__clsHisWatcherCleanup = null;
  }
  window.__clsHisWatcherCleanup = teardown;

  try {
    chrome.storage.local.get([SHARED_SETTINGS_KEY, MERGE_SESSION_KEY, CAPTURE_PAUSED_KEY], (data) => {
      if (chrome.runtime.lastError) return;
      capturePaused = Boolean(data?.[CAPTURE_PAUSED_KEY]);
      applySettings(data?.[SHARED_SETTINGS_KEY] || {}, false);
      updateSessionState(data?.[MERGE_SESSION_KEY] || null);
      checkAutoSweep(500);
    });
    chrome.storage.onChanged.addListener(onStorageChanged);
  } catch {}

  document.addEventListener('click', onDocClick, true);
  window.addEventListener('resize', onWinResize, { passive: true });
})();