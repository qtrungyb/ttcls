/* =========================================================
   HIS WATCHER — Gộp ngầm từng nhóm XN/CĐHA + Tạm dừng ⏸/▶
                 + Popover xem trước + Dark Mode
   ========================================================= */
(function() {
  if (window.__clsHisWatcherCleanup) {
    try { window.__clsHisWatcherCleanup(); } catch {}
  }

  const SHARED_SETTINGS_KEY = 'cls_shared_settings';
  const MERGE_SESSION_KEY = 'cls_merge_session_v1';
  const CAPTURE_PAUSED_KEY = 'cls_capture_paused';
  const FLOAT_BAR_ID = 'cls-ext-float-bar';
  const POPOVER_ID = 'cls-ext-popover';
  const FLOAT_UI_KEY = 'cls_his_float_ui_v1';
  const SVG_NS = 'http://www.w3.org/2000/svg';

  let mergeEnabled = true;
  let capturePaused = false;
  let isDark = true;
  let mergedCount = 0;
  let popoverOpen = false;
  let previewData = null;

  let t1 = null;
  let t2 = null;
  let mutTimer = null;
  let hoverOpenTimer = null;
  let hoverCloseTimer = null;
  let copyFlashTimer = null;
  let observer = null;

  let uiPrefs = loadUiPrefs();

  function loadUiPrefs() {
    try {
      const parsed = JSON.parse(localStorage.getItem(FLOAT_UI_KEY) || '{}');
      return {
        right: typeof parsed.right === 'number' ? parsed.right : 24,
        bottom: typeof parsed.bottom === 'number' ? parsed.bottom : 18,
        collapsed: Boolean(parsed.collapsed)
      };
    } catch {
      return { right: 24, bottom: 18, collapsed: false };
    }
  }

  function saveUiPrefs() {
    try { localStorage.setItem(FLOAT_UI_KEY, JSON.stringify(uiPrefs)); } catch {}
  }

  function getPalette() {
    if (isDark) {
      return {
        barBg: 'rgba(28, 25, 23, 0.94)',
        barBorder: 'rgba(255, 255, 255, 0.13)',
        popBg: '#1c1917',
        popSub: '#24201e',
        popBorder: '#35312e',
        text: '#f5f5f4',
        muted: '#a8a29e',
        hover: 'rgba(255, 255, 255, 0.1)',
        primary: '#14b8a6',
        primaryText: '#5eead4',
        primarySoft: 'rgba(20, 184, 166, 0.18)',
        warnBg: 'rgba(245, 158, 11, 0.22)',
        warnText: '#fcd34d',
        dangerBg: 'rgba(239, 68, 68, 0.2)',
        dangerText: '#fca5a5',
        shadow: '0 10px 28px rgba(0, 0, 0, 0.45)',
        chips: {
          ctm:   { bg: '#4c111d', bd: '#9f1239', tx: '#fda4af' },
          shm:   { bg: '#083836', bd: '#115e59', tx: '#5eead4' },
          tptnt: { bg: '#422a08', bd: '#92400e', tx: '#fcd34d' },
          img:   { bg: '#142a4f', bd: '#1d4ed8', tx: '#93c5fd' },
          other: { bg: '#2e1852', bd: '#6d28d9', tx: '#c4b5fd' }
        }
      };
    }
    return {
      barBg: 'rgba(255, 255, 255, 0.96)',
      barBorder: '#d6d3d1',
      popBg: '#ffffff',
      popSub: '#fafaf9',
      popBorder: '#e7e5e4',
      text: '#1c1917',
      muted: '#57534e',
      hover: 'rgba(28, 25, 23, 0.06)',
      primary: '#0d9488',
      primaryText: '#0f766e',
      primarySoft: '#f0fdfa',
      warnBg: '#fef3c7',
      warnText: '#b45309',
      dangerBg: '#fef2f2',
      dangerText: '#b91c1c',
      shadow: '0 10px 28px rgba(15, 23, 42, 0.16)',
      chips: {
        ctm:   { bg: '#ffe4e6', bd: '#fda4af', tx: '#be123c' },
        shm:   { bg: '#ccfbf1', bd: '#5eead4', tx: '#0f766e' },
        tptnt: { bg: '#fef3c7', bd: '#fcd34d', tx: '#b45309' },
        img:   { bg: '#dbeafe', bd: '#93c5fd', tx: '#1d4ed8' },
        other: { bg: '#ede9fe', bd: '#c4b5fd', tx: '#6d28d9' }
      }
    };
  }

  function getChipKey(label) {
    const k = String(label || '').toUpperCase();
    if (k === 'CTM' || k === 'VSS') return 'ctm';
    if (k === 'SHM' || k === 'ĐGĐ') return 'shm';
    if (k === 'TPTNT') return 'tptnt';
    if (k === 'CĐHA' || k === 'TDCN') return 'img';
    return 'other';
  }

  function createSvg(paths, size = 13) {
    const svg = document.createElementNS(SVG_NS, 'svg');
    svg.setAttribute('viewBox', '0 0 24 24');
    svg.setAttribute('width', String(size));
    svg.setAttribute('height', String(size));
    svg.setAttribute('fill', 'none');
    svg.setAttribute('stroke', 'currentColor');
    svg.setAttribute('stroke-width', '1.9');
    svg.setAttribute('stroke-linecap', 'round');
    svg.setAttribute('stroke-linejoin', 'round');
    for (const def of paths) {
      const node = document.createElementNS(SVG_NS, def.tag);
      for (const [k, v] of Object.entries(def.attrs)) node.setAttribute(k, v);
      svg.appendChild(node);
    }
    return svg;
  }

  function isContextAlive() {
    try { return Boolean(chrome.runtime && chrome.runtime.id); } catch { return false; }
  }

  function stopObserver() {
    if (observer) {
      observer.disconnect();
      observer = null;
    }
  }

  function removePopover() {
    popoverOpen = false;
    const old = document.getElementById(POPOVER_ID);
    if (old) old.remove();
  }

  function removeFloatBar() {
    removePopover();
    const old = document.getElementById(FLOAT_BAR_ID);
    if (old) old.remove();
  }

  function clampBarPosition(bar) {
    if (!bar) return;
    const rect = bar.getBoundingClientRect();
    const maxR = Math.max(8, window.innerWidth - Math.max(rect.width, 60) - 8);
    const maxB = Math.max(8, window.innerHeight - Math.max(rect.height, 34) - 8);
    uiPrefs.right = Math.min(maxR, Math.max(8, Math.round(uiPrefs.right)));
    uiPrefs.bottom = Math.min(maxB, Math.max(8, Math.round(uiPrefs.bottom)));
    bar.style.right = uiPrefs.right + 'px';
    bar.style.bottom = uiPrefs.bottom + 'px';
    positionPopover();
  }

  function positionPopover() {
    const bar = document.getElementById(FLOAT_BAR_ID);
    const pop = document.getElementById(POPOVER_ID);
    if (!bar || !pop) return;

    const br = bar.getBoundingClientRect();
    const popW = Math.min(350, window.innerWidth - 20);
    pop.style.width = popW + 'px';

    let rightPx = window.innerWidth - br.right;
    rightPx = Math.max(10, Math.min(window.innerWidth - popW - 10, rightPx));
    pop.style.right = Math.round(rightPx) + 'px';

    if (br.top >= 220) {
      pop.style.top = 'auto';
      pop.style.bottom = Math.round(window.innerHeight - br.top + 8) + 'px';
    } else {
      pop.style.bottom = 'auto';
      pop.style.top = Math.round(br.bottom + 8) + 'px';
    }
  }

  function updatePauseButton(pauseBtn) {
    if (!pauseBtn) return;
    const p = getPalette();
    pauseBtn.textContent = '';
    if (capturePaused) {
      pauseBtn.appendChild(createSvg([
        { tag: 'polygon', attrs: { points: '7 5 19 12 7 19 7 5', fill: 'currentColor' } }
      ], 11));
      pauseBtn.title = 'Đang tạm dừng gộp — bấm để tiếp tục tự động gộp';
      pauseBtn.style.background = p.warnBg;
      pauseBtn.style.color = p.warnText;
    } else {
      pauseBtn.appendChild(createSvg([
        { tag: 'line', attrs: { x1: '9', y1: '5', x2: '9', y2: '19' } },
        { tag: 'line', attrs: { x1: '15', y1: '5', x2: '15', y2: '19' } }
      ], 11));
      pauseBtn.title = 'Tạm dừng tự động gộp (khi cần xem lại lịch sử cũ)';
      pauseBtn.style.background = p.hover;
      pauseBtn.style.color = p.muted;
    }
  }

  function applyBarTheme(bar) {
    if (!bar) return;
    const p = getPalette();
    bar.style.background = p.barBg;
    bar.style.borderColor = capturePaused ? '#d97706' : p.barBorder;
    bar.style.color = p.text;
    bar.style.boxShadow = p.shadow;

    const grip = bar.querySelector('#cls-ext-float-grip');
    if (grip) grip.style.color = p.muted;

    const dot = bar.querySelector('#cls-ext-float-dot');
    if (dot) dot.style.background = capturePaused ? '#f59e0b' : '#14b8a6';

    const copyBtn = bar.querySelector('#cls-ext-float-copy');
    if (copyBtn) copyBtn.style.color = p.text;

    updatePauseButton(bar.querySelector('#cls-ext-float-pause'));

    const collapseBtn = bar.querySelector('#cls-ext-float-collapse');
    if (collapseBtn) {
      collapseBtn.style.background = p.hover;
      collapseBtn.style.color = p.muted;
    }

    const clearBtn = bar.querySelector('#cls-ext-float-clear');
    if (clearBtn) {
      clearBtn.style.background = p.dangerBg;
      clearBtn.style.color = p.dangerText;
    }
  }

  function renderPopoverContent() {
    const pop = document.getElementById(POPOVER_ID);
    if (!pop) return;
    const p = getPalette();

    pop.style.background = p.popBg;
    pop.style.borderColor = p.popBorder;
    pop.style.color = p.text;
    pop.style.boxShadow = p.shadow;
    pop.textContent = '';

    const head = document.createElement('div');
    head.style.cssText = [
      'display:flex',
      'align-items:center',
      'justify-content:space-between',
      'gap:8px',
      'padding:8px 10px',
      `border-bottom:1px solid ${p.popBorder}`,
      `background:${p.popSub}`
    ].join(';');

    const title = document.createElement('div');
    const pt = previewData?.patient;
    const bn = pt?.name && pt?.id ? `${pt.name} (${pt.id})` : (pt?.name || pt?.id || `Bộ gộp (${mergedCount} phiếu)`);
    title.textContent = capturePaused ? `${bn} — Tạm dừng` : bn;
    title.title = bn;
    title.style.cssText = [
      'font-size:11.5px',
      'font-weight:700',
      `color:${capturePaused ? p.warnText : p.primaryText}`,
      'white-space:nowrap',
      'overflow:hidden',
      'text-overflow:ellipsis',
      'min-width:0'
    ].join(';');

    const headActs = document.createElement('div');
    headActs.style.cssText = 'display:inline-flex;align-items:center;gap:5px;flex-shrink:0;';

    const copyNowBtn = document.createElement('button');
    copyNowBtn.type = 'button';
    copyNowBtn.style.cssText = [
      'display:inline-flex',
      'align-items:center',
      'gap:4px',
      'border:none',
      `background:${p.primary}`,
      'color:#ffffff',
      'padding:3px 9px',
      'border-radius:6px',
      'font:600 11px/1.2 system-ui,-apple-system,Segoe UI,sans-serif',
      'cursor:pointer'
    ].join(';');
    copyNowBtn.appendChild(createSvg([
      { tag: 'rect', attrs: { x: '9', y: '9', width: '13', height: '13', rx: '2' } },
      { tag: 'path', attrs: { d: 'M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1' } }
    ], 11));
    const copyLbl = document.createElement('span');
    copyLbl.textContent = 'Copy';
    copyNowBtn.appendChild(copyLbl);
    copyNowBtn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      if (!isContextAlive()) return teardown();
      chrome.runtime.sendMessage({ type: 'CLS_COPY_MERGED' }, (res) => {
        void chrome.runtime.lastError;
        if (res?.ok) {
          copyLbl.textContent = 'Đã copy';
          setTimeout(() => { copyLbl.textContent = 'Copy'; }, 1200);
        }
      });
    });

    const closeBtn = document.createElement('button');
    closeBtn.type = 'button';
    closeBtn.title = 'Đóng xem trước';
    closeBtn.style.cssText = [
      'width:20px',
      'height:20px',
      'border-radius:6px',
      'border:none',
      'background:transparent',
      `color:${p.muted}`,
      'display:inline-flex',
      'align-items:center',
      'justify-content:center',
      'cursor:pointer'
    ].join(';');
    closeBtn.appendChild(createSvg([
      { tag: 'line', attrs: { x1: '18', y1: '6', x2: '6', y2: '18' } },
      { tag: 'line', attrs: { x1: '6', y1: '6', x2: '18', y2: '18' } }
    ], 12));
    closeBtn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      removePopover();
    });

    headActs.appendChild(copyNowBtn);
    headActs.appendChild(closeBtn);
    head.appendChild(title);
    head.appendChild(headActs);
    pop.appendChild(head);

    const sheets = Array.isArray(previewData?.sheets) ? previewData.sheets : [];
    if (sheets.length) {
      const chipWrap = document.createElement('div');
      chipWrap.style.cssText = [
        'display:flex',
        'flex-wrap:wrap',
        'gap:5px',
        'padding:7px 10px',
        `border-bottom:1px solid ${p.popBorder}`
      ].join(';');

      sheets.forEach((s, idx) => {
        const c = p.chips[getChipKey(s.label)] || p.chips.other;
        const chip = document.createElement('span');
        chip.title = [s.serviceName || s.label, s.resultTime].filter(Boolean).join(' — ');
        chip.style.cssText = [
          'display:inline-flex',
          'align-items:center',
          'gap:4px',
          'max-width:100%',
          'padding:2px 5px 2px 8px',
          'border-radius:999px',
          `background:${c.bg} !important`,
          `border:1px solid ${c.bd} !important`,
          `color:${c.tx} !important`,
          'font:600 11px/1.25 system-ui,-apple-system,Segoe UI,sans-serif'
        ].join(';');

        const isImg = s.label === 'CĐHA' || s.label === 'TDCN';
        const txt = document.createElement('span');
        txt.textContent = isImg && s.displayName
          ? s.displayName
          : `${s.label}${s.count ? ` (${s.count})` : ''}`;
        txt.style.cssText = 'max-width:220px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;display:inline-block;';

        const del = document.createElement('button');
        del.type = 'button';
        del.textContent = '×';
        del.title = 'Bỏ riêng phiếu này';
        del.style.cssText = [
          'border:none',
          'background:transparent',
          'color:inherit',
          'width:15px',
          'height:15px',
          'border-radius:50%',
          'display:inline-flex',
          'align-items:center',
          'justify-content:center',
          'font-size:12px',
          'line-height:1',
          'cursor:pointer',
          'opacity:0.75',
          'flex-shrink:0'
        ].join(';');
        del.addEventListener('mouseenter', () => {
          del.style.background = '#dc2626';
          del.style.color = '#ffffff';
          del.style.opacity = '1';
        });
        del.addEventListener('mouseleave', () => {
          del.style.background = 'transparent';
          del.style.color = 'inherit';
          del.style.opacity = '0.75';
        });
        del.addEventListener('click', (e) => {
          e.preventDefault();
          e.stopPropagation();
          if (!isContextAlive()) return teardown();
          clearTimeout(t1);
          clearTimeout(t2);
          clearTimeout(mutTimer);
          mutTimer = null;
          chrome.runtime.sendMessage({ type: 'CLS_REMOVE_SHEET', index: idx }, (res) => {
            void chrome.runtime.lastError;
            if (res?.ok) {
              previewData = res;
              if (!res.sheets?.length) removePopover();
              else renderPopoverContent();
            }
          });
        });

        chip.appendChild(txt);
        chip.appendChild(del);
        chipWrap.appendChild(chip);
      });
      pop.appendChild(chipWrap);
    }

    const body = document.createElement('div');
    body.style.cssText = [
      'padding:9px 10px',
      'max-height:165px',
      'overflow-y:auto',
      'font:500 11.5px/1.6 ui-monospace,Cascadia Mono,Consolas,monospace',
      'white-space:pre-wrap',
      'word-break:break-word',
      `color:${p.text}`
    ].join(';');
    body.textContent = previewData
      ? (previewData.plain || 'Không có chỉ số nào khớp bộ lọc hiện tại.')
      : 'Đang tải xem trước…';
    pop.appendChild(body);

    positionPopover();
  }

  function fetchPreviewAndRender() {
    if (!isContextAlive()) return teardown();
    chrome.runtime.sendMessage({ type: 'CLS_GET_MERGED_PREVIEW' }, (res) => {
      void chrome.runtime.lastError;
      if (res?.ok) {
        previewData = res;
        if (popoverOpen) renderPopoverContent();
      }
    });
  }

  function openPopover() {
    if (window !== window.top || !document.body || mergedCount <= 0) return;
    clearTimeout(hoverCloseTimer);

    let pop = document.getElementById(POPOVER_ID);
    if (!pop) {
      pop = document.createElement('div');
      pop.id = POPOVER_ID;
      pop.style.cssText = [
        'position:fixed',
        'z-index:2147483646',
        'border-radius:12px',
        'border:1px solid transparent',
        'overflow:hidden',
        'font-family:system-ui,-apple-system,Segoe UI,sans-serif'
      ].join(';');

      pop.addEventListener('mouseenter', () => clearTimeout(hoverCloseTimer));
      pop.addEventListener('mouseleave', scheduleClosePopover);
      document.body.appendChild(pop);
    }

    popoverOpen = true;
    renderPopoverContent();
    fetchPreviewAndRender();
  }

  function scheduleClosePopover() {
    clearTimeout(hoverOpenTimer);
    clearTimeout(hoverCloseTimer);
    hoverCloseTimer = setTimeout(removePopover, 240);
  }

  function updateBarText(bar) {
    if (!bar) return;
    const labelEl = bar.querySelector('#cls-ext-float-label');
    const pauseBtn = bar.querySelector('#cls-ext-float-pause');
    const clearBtn = bar.querySelector('#cls-ext-float-clear');
    const collapseBtn = bar.querySelector('#cls-ext-float-collapse');
    const grip = bar.querySelector('#cls-ext-float-grip');

    if (uiPrefs.collapsed) {
      if (labelEl) labelEl.textContent = capturePaused ? (mergedCount > 0 ? `${mergedCount} ⏸` : '⏸') : String(mergedCount);
      if (pauseBtn) pauseBtn.style.display = capturePaused ? 'inline-flex' : 'none';
      if (clearBtn) clearBtn.style.display = 'none';
      if (grip) grip.style.display = 'none';
      if (collapseBtn) {
        collapseBtn.style.display = 'inline-flex';
        collapseBtn.textContent = '◂';
        collapseBtn.title = 'Mở rộng thanh CLS';
      }
    } else {
      if (labelEl) {
        labelEl.textContent = mergedCount > 0 ? `CLS: ${mergedCount} phiếu` : 'CLS: Tạm dừng';
      }
      if (pauseBtn) pauseBtn.style.display = 'inline-flex';
      if (clearBtn) clearBtn.style.display = mergedCount > 0 ? 'inline-flex' : 'none';
      if (grip) grip.style.display = 'inline-flex';
      if (collapseBtn) {
        collapseBtn.style.display = 'inline-flex';
        collapseBtn.textContent = '–';
        collapseBtn.title = 'Thu gọn thanh CLS';
      }
    }
    applyBarTheme(bar);
    clampBarPosition(bar);
  }

  function renderFloatBar() {
    if (window !== window.top || !document.body) return;

    if (!mergeEnabled || (mergedCount <= 0 && !capturePaused)) {
      removeFloatBar();
      return;
    }

    let bar = document.getElementById(FLOAT_BAR_ID);
    if (!bar) {
      bar = document.createElement('div');
      bar.id = FLOAT_BAR_ID;
      bar.style.cssText = [
        'position:fixed',
        `bottom:${uiPrefs.bottom}px`,
        `right:${uiPrefs.right}px`,
        'z-index:2147483646',
        'display:inline-flex',
        'align-items:center',
        'gap:5px',
        'padding:5px 7px 5px 8px',
        'border-radius:999px',
        'border:1px solid transparent',
        'font:600 12px/1.2 system-ui,-apple-system,Segoe UI,sans-serif',
        'backdrop-filter:blur(8px)',
        'user-select:none'
      ].join(';');

      const grip = document.createElement('span');
      grip.id = 'cls-ext-float-grip';
      grip.title = 'Kéo để di chuyển thanh nổi';
      grip.style.cssText = 'display:inline-flex;align-items:center;padding:2px;cursor:grab;opacity:0.65;';
      grip.appendChild(createSvg([
        { tag: 'circle', attrs: { cx: '9', cy: '6', r: '1.2', fill: 'currentColor', stroke: 'none' } },
        { tag: 'circle', attrs: { cx: '15', cy: '6', r: '1.2', fill: 'currentColor', stroke: 'none' } },
        { tag: 'circle', attrs: { cx: '9', cy: '12', r: '1.2', fill: 'currentColor', stroke: 'none' } },
        { tag: 'circle', attrs: { cx: '15', cy: '12', r: '1.2', fill: 'currentColor', stroke: 'none' } },
        { tag: 'circle', attrs: { cx: '9', cy: '18', r: '1.2', fill: 'currentColor', stroke: 'none' } },
        { tag: 'circle', attrs: { cx: '15', cy: '18', r: '1.2', fill: 'currentColor', stroke: 'none' } }
      ], 12));

      const copyBtn = document.createElement('button');
      copyBtn.type = 'button';
      copyBtn.id = 'cls-ext-float-copy';
      copyBtn.title = 'Bấm để copy nhanh — Di chuột để xem trước & xóa lẻ phiếu';
      copyBtn.style.cssText = [
        'display:inline-flex',
        'align-items:center',
        'gap:6px',
        'border:none',
        'background:transparent',
        'padding:3px 7px',
        'border-radius:999px',
        'font:600 12px/1.2 system-ui,-apple-system,Segoe UI,sans-serif',
        'cursor:pointer',
        'transition:background 120ms ease'
      ].join(';');

      const dot = document.createElement('span');
      dot.id = 'cls-ext-float-dot';
      dot.style.cssText = 'width:7px;height:7px;border-radius:50%;background:#14b8a6;flex-shrink:0;';

      const label = document.createElement('span');
      label.id = 'cls-ext-float-label';

      copyBtn.appendChild(dot);
      copyBtn.appendChild(label);

      copyBtn.addEventListener('mouseenter', () => {
        copyBtn.style.background = getPalette().primarySoft;
        if (mergedCount > 0) {
          clearTimeout(hoverCloseTimer);
          hoverOpenTimer = setTimeout(openPopover, 160);
        }
      });
      copyBtn.addEventListener('mouseleave', () => {
        copyBtn.style.background = 'transparent';
        clearTimeout(hoverOpenTimer);
        scheduleClosePopover();
      });
      copyBtn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        if (!isContextAlive()) return teardown();
        if (mergedCount <= 0) return;
        chrome.runtime.sendMessage({ type: 'CLS_COPY_MERGED' }, (res) => {
          void chrome.runtime.lastError;
          if (res?.ok && label) {
            clearTimeout(copyFlashTimer);
            label.textContent = uiPrefs.collapsed ? '✓' : '✓ Đã copy';
            copyFlashTimer = setTimeout(() => updateBarText(bar), 1200);
          }
        });
      });

      const pauseBtn = document.createElement('button');
      pauseBtn.type = 'button';
      pauseBtn.id = 'cls-ext-float-pause';
      pauseBtn.style.cssText = [
        'border:none',
        'width:22px',
        'height:22px',
        'border-radius:50%',
        'display:inline-flex',
        'align-items:center',
        'justify-content:center',
        'cursor:pointer',
        'transition:background 120ms ease,color 120ms ease'
      ].join(';');
      pauseBtn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        if (!isContextAlive()) return teardown();
        clearTimeout(t1);
        clearTimeout(t2);
        clearTimeout(mutTimer);
        mutTimer = null;
        chrome.runtime.sendMessage({ type: 'CLS_TOGGLE_PAUSE' }, () => {
          void chrome.runtime.lastError;
        });
      });

      const collapseBtn = document.createElement('button');
      collapseBtn.type = 'button';
      collapseBtn.id = 'cls-ext-float-collapse';
      collapseBtn.style.cssText = [
        'border:none',
        'width:20px',
        'height:20px',
        'border-radius:50%',
        'display:inline-flex',
        'align-items:center',
        'justify-content:center',
        'font:700 12px/1 system-ui,sans-serif',
        'cursor:pointer',
        'transition:opacity 120ms ease'
      ].join(';');
      collapseBtn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        uiPrefs.collapsed = !uiPrefs.collapsed;
        saveUiPrefs();
        updateBarText(bar);
      });

      const clearBtn = document.createElement('button');
      clearBtn.type = 'button';
      clearBtn.id = 'cls-ext-float-clear';
      clearBtn.title = 'Xóa toàn bộ bộ gộp (Alt+Shift+X)';
      clearBtn.style.cssText = [
        'display:inline-flex',
        'align-items:center',
        'gap:3px',
        'border:none',
        'padding:3px 8px',
        'border-radius:999px',
        'font:600 11.5px/1.2 system-ui,-apple-system,Segoe UI,sans-serif',
        'cursor:pointer',
        'transition:background 120ms ease,color 120ms ease'
      ].join(';');
      clearBtn.appendChild(createSvg([
        { tag: 'line', attrs: { x1: '18', y1: '6', x2: '6', y2: '18' } },
        { tag: 'line', attrs: { x1: '6', y1: '6', x2: '18', y2: '18' } }
      ], 11));
      const clrTxt = document.createElement('span');
      clrTxt.textContent = 'Xóa';
      clearBtn.appendChild(clrTxt);

      clearBtn.addEventListener('mouseenter', () => {
        clearBtn.style.background = '#dc2626';
        clearBtn.style.color = '#ffffff';
      });
      clearBtn.addEventListener('mouseleave', () => {
        const pal = getPalette();
        clearBtn.style.background = pal.dangerBg;
        clearBtn.style.color = pal.dangerText;
      });
      clearBtn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        if (!isContextAlive()) return teardown();
        clearTimeout(t1);
        clearTimeout(t2);
        clearTimeout(mutTimer);
        mutTimer = null;
        removePopover();
        chrome.runtime.sendMessage({ type: 'CLS_CLEAR_MERGE' }, () => {
          void chrome.runtime.lastError;
        });
      });

      let dragState = null;
      grip.addEventListener('pointerdown', (e) => {
        e.preventDefault();
        e.stopPropagation();
        grip.setPointerCapture(e.pointerId);
        grip.style.cursor = 'grabbing';
        dragState = {
          startX: e.clientX,
          startY: e.clientY,
          origRight: uiPrefs.right,
          origBottom: uiPrefs.bottom
        };
      });
      grip.addEventListener('pointermove', (e) => {
        if (!dragState) return;
        uiPrefs.right = dragState.origRight - (e.clientX - dragState.startX);
        uiPrefs.bottom = dragState.origBottom - (e.clientY - dragState.startY);
        clampBarPosition(bar);
      });
      const finishDrag = (e) => {
        if (!dragState) return;
        try { grip.releasePointerCapture(e.pointerId); } catch {}
        grip.style.cursor = 'grab';
        dragState = null;
        saveUiPrefs();
      };
      grip.addEventListener('pointerup', finishDrag);
      grip.addEventListener('pointercancel', finishDrag);

      bar.appendChild(grip);
      bar.appendChild(copyBtn);
      bar.appendChild(pauseBtn);
      bar.appendChild(collapseBtn);
      bar.appendChild(clearBtn);
      document.body.appendChild(bar);
    }

    updateBarText(bar);
  }

  function onWinResize() {
    const bar = document.getElementById(FLOAT_BAR_ID);
    if (bar) clampBarPosition(bar);
  }

  function updateSessionState(session) {
    const sheets = Array.isArray(session?.sheets) ? session.sheets : [];
    mergedCount = sheets.length;
    if (mergedCount <= 0) {
      previewData = null;
      removePopover();
    }
    renderFloatBar();
    if (popoverOpen && mergedCount > 0) fetchPreviewAndRender();
  }

  function isOwnNode(node) {
    if (!node) return false;
    const elem = node.nodeType === 1 ? node : node.parentElement;
    if (!elem) return false;
    return Boolean(
      elem.id === 'cls-ext-page-toast' ||
      elem.id === 'cls-ext-copy-tmp' ||
      elem.id === FLOAT_BAR_ID ||
      elem.id === POPOVER_ID ||
      elem.closest?.(`#${FLOAT_BAR_ID}, #${POPOVER_ID}, #cls-ext-page-toast`)
    );
  }

  function isRelevantMutation(m) {
    if (isOwnNode(m.target)) return false;
    const added = Array.from(m.addedNodes || []);
    const removed = Array.from(m.removedNodes || []);
    if ((added.length || removed.length) && [...added, ...removed].every(isOwnNode)) {
      return false;
    }
    return true;
  }

  function triggerCapture() {
    if (!mergeEnabled || capturePaused) return;
    if (!isContextAlive()) return teardown();
    try {
      chrome.runtime.sendMessage({ type: 'CLS_BG_AUTO_CAPTURE' }, () => {
        void chrome.runtime.lastError;
      });
    } catch {
      teardown();
    }
  }

  function scheduleCapture() {
    if (!mergeEnabled || capturePaused) return;
    clearTimeout(t1);
    clearTimeout(t2);
    t1 = setTimeout(triggerCapture, 650);
    t2 = setTimeout(triggerCapture, 1800);
  }

  function startObserver() {
    if (observer || !document.body) return;
    observer = new MutationObserver((mutations) => {
      if (!mergeEnabled || capturePaused) return;
      if (!mutations.some(isRelevantMutation)) return;
      if (!mutTimer) {
        mutTimer = setTimeout(() => {
          mutTimer = null;
          triggerCapture();
        }, 550);
      }
    });
    observer.observe(document.body, { childList: true, subtree: true, characterData: true });
  }

  function syncObserverState() {
    if (mergeEnabled && !capturePaused) {
      startObserver();
    } else {
      clearTimeout(t1);
      clearTimeout(t2);
      clearTimeout(mutTimer);
      mutTimer = null;
      stopObserver();
    }
  }

  function applySettings(settings, triggerIfJustOn = false) {
    const wasOn = mergeEnabled;
    mergeEnabled = settings?.mergeEnabled !== false;
    isDark = settings?.darkMode !== false;

    syncObserverState();
    if (mergeEnabled && !capturePaused && triggerIfJustOn && !wasOn && window === window.top) {
      setTimeout(triggerCapture, 250);
    }
    renderFloatBar();
    if (popoverOpen) fetchPreviewAndRender();
  }

  function applyPausedState(paused) {
    capturePaused = Boolean(paused);
    syncObserverState();
    renderFloatBar();
    if (popoverOpen) renderPopoverContent();
  }

  function onDocClick(e) {
    if (!isContextAlive()) return teardown();
    if (!e.isTrusted) return;
    if (isOwnNode(e.target)) return;

    if (popoverOpen) removePopover();
    if (!mergeEnabled || capturePaused) return;

    const target = e.target;
    const tag = (target?.tagName || '').toUpperCase();
    if (
      (tag === 'TEXTAREA' || (tag === 'INPUT' && target.type !== 'checkbox' && target.type !== 'radio')) &&
      !target.readOnly && !target.disabled
    ) {
      return;
    }

    scheduleCapture();
  }

  function onStorageChanged(changes, area) {
    if (area !== 'local') return;
    if (changes[SHARED_SETTINGS_KEY]?.newValue) {
      applySettings(changes[SHARED_SETTINGS_KEY].newValue, true);
    }
    if (changes[CAPTURE_PAUSED_KEY]) {
      applyPausedState(changes[CAPTURE_PAUSED_KEY].newValue);
    }
    if (changes[MERGE_SESSION_KEY]) {
      updateSessionState(changes[MERGE_SESSION_KEY].newValue || null);
    }
  }

  function teardown() {
    clearTimeout(t1);
    clearTimeout(t2);
    clearTimeout(mutTimer);
    mutTimer = null;
    clearTimeout(hoverOpenTimer);
    clearTimeout(hoverCloseTimer);
    clearTimeout(copyFlashTimer);
    stopObserver();
    removeFloatBar();
    document.removeEventListener('click', onDocClick, true);
    window.removeEventListener('resize', onWinResize);
    try { chrome.storage.onChanged.removeListener(onStorageChanged); } catch {}
    window.__clsHisWatcherCleanup = null;
  }
  window.__clsHisWatcherCleanup = teardown;

  try {
    chrome.storage.local.get([SHARED_SETTINGS_KEY, MERGE_SESSION_KEY, CAPTURE_PAUSED_KEY], (data) => {
      if (chrome.runtime.lastError) return;
      capturePaused = Boolean(data?.[CAPTURE_PAUSED_KEY]);
      applySettings(data?.[SHARED_SETTINGS_KEY] || {}, false);
      updateSessionState(data?.[MERGE_SESSION_KEY] || null);
    });
    chrome.storage.onChanged.addListener(onStorageChanged);
  } catch {}

  document.addEventListener('click', onDocClick, true);
  window.addEventListener('resize', onWinResize, { passive: true });
})();