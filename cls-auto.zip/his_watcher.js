/* =========================================================
   HIS WATCHER — Gộp ngầm HIS + Chống rớt AJAX + Thanh nổi nâng cấp
   ========================================================= */
(function() {
  if (window.__clsHisWatcherCleanup) {
    try { window.__clsHisWatcherCleanup(); } catch {}
  }

  const SHARED_SETTINGS_KEY = 'cls_shared_settings';
  const MERGE_SESSION_KEY = 'cls_merge_session_v1';
  const FLOAT_BAR_ID = 'cls-ext-float-bar';
  const FLOAT_UI_KEY = 'cls_his_float_ui_v1';

  let mergeEnabled = true;
  let mergedCount = 0;
  let mergedTooltip = '';
  let t1 = null;
  let t2 = null;
  let mutTimer = null;
  let copyFlashTimer = null;
  let observer = null;

  let uiPrefs = loadUiPrefs();

  function loadUiPrefs() {
    try {
      const parsed = JSON.parse(localStorage.getItem(FLOAT_UI_KEY) || '{}');
      return {
        right: typeof parsed.right === 'number' ? parsed.right : 24,
        bottom: typeof parsed.bottom === 'number' ? parsed.bottom : 18,
        collapsed: Boolean(parsed.collapsed)
      };
    } catch {
      return { right: 24, bottom: 18, collapsed: false };
    }
  }

  function saveUiPrefs() {
    try { localStorage.setItem(FLOAT_UI_KEY, JSON.stringify(uiPrefs)); } catch {}
  }

  function clampBarPosition(bar) {
    if (!bar) return;
    const rect = bar.getBoundingClientRect();
    const maxR = Math.max(8, window.innerWidth - Math.max(rect.width, 60) - 8);
    const maxB = Math.max(8, window.innerHeight - Math.max(rect.height, 34) - 8);
    uiPrefs.right = Math.min(maxR, Math.max(8, Math.round(uiPrefs.right)));
    uiPrefs.bottom = Math.min(maxB, Math.max(8, Math.round(uiPrefs.bottom)));
    bar.style.right = uiPrefs.right + 'px';
    bar.style.bottom = uiPrefs.bottom + 'px';
  }

  function isContextAlive() {
    try {
      return Boolean(chrome.runtime && chrome.runtime.id);
    } catch {
      return false;
    }
  }

  function stopObserver() {
    if (observer) {
      observer.disconnect();
      observer = null;
    }
  }

  function removeFloatBar() {
    const old = document.getElementById(FLOAT_BAR_ID);
    if (old) old.remove();
  }

  function updateBarText(bar) {
    if (!bar) return;
    const copyBtn = bar.querySelector('#cls-ext-float-copy');
    const labelEl = bar.querySelector('#cls-ext-float-label');
    const clearBtn = bar.querySelector('#cls-ext-float-clear');
    const collapseBtn = bar.querySelector('#cls-ext-float-collapse');
    const grip = bar.querySelector('#cls-ext-float-grip');

    const tip = (mergedTooltip ? mergedTooltip + ' — ' : '') + 'Bấm để copy lại (Ctrl+V)';
    if (copyBtn) copyBtn.title = tip;

    if (uiPrefs.collapsed) {
      if (labelEl) labelEl.textContent = String(mergedCount);
      if (clearBtn) clearBtn.style.display = 'none';
      if (grip) grip.style.display = 'none';
      if (collapseBtn) {
        collapseBtn.textContent = '◂';
        collapseBtn.title = 'Mở rộng thanh CLS';
      }
      bar.style.padding = '5px 7px 5px 9px';
    } else {
      if (labelEl) labelEl.textContent = `CLS: ${mergedCount} phiếu`;
      if (clearBtn) clearBtn.style.display = 'inline-flex';
      if (grip) grip.style.display = 'inline-flex';
      if (collapseBtn) {
        collapseBtn.textContent = '–';
        collapseBtn.title = 'Thu gọn thanh CLS';
      }
      bar.style.padding = '5px 7px 5px 8px';
    }
    clampBarPosition(bar);
  }

  function renderFloatBar() {
    if (window !== window.top || !document.body) return;

    if (!mergeEnabled || mergedCount <= 0) {
      removeFloatBar();
      return;
    }

    let bar = document.getElementById(FLOAT_BAR_ID);
    if (!bar) {
      bar = document.createElement('div');
      bar.id = FLOAT_BAR_ID;
      bar.style.cssText = [
        'position:fixed',
        `bottom:${uiPrefs.bottom}px`,
        `right:${uiPrefs.right}px`,
        'z-index:2147483646',
        'display:inline-flex',
        'align-items:center',
        'gap:6px',
        'padding:5px 7px 5px 8px',
        'border-radius:999px',
        'background:rgba(15, 23, 42, 0.92)',
        'color:#f8fafc',
        'font:600 12px/1.2 system-ui,-apple-system,Segoe UI,sans-serif',
        'box-shadow:0 6px 20px rgba(0,0,0,0.24)',
        'border:1px solid rgba(255,255,255,0.14)',
        'backdrop-filter:blur(6px)',
        'user-select:none'
      ].join(';');

      // Tay nắm kéo vị trí
      const grip = document.createElement('span');
      grip.id = 'cls-ext-float-grip';
      grip.textContent = '⋮⋮';
      grip.title = 'Kéo để di chuyển thanh nổi';
      grip.style.cssText = [
        'display:inline-flex',
        'align-items:center',
        'padding:2px 3px',
        'color:rgba(248,250,252,0.45)',
        'cursor:grab',
        'font-size:12px',
        'letter-spacing:-1px'
      ].join(';');

      // Nút Copy lại ngay (chấm xanh + số phiếu)
      const copyBtn = document.createElement('button');
      copyBtn.type = 'button';
      copyBtn.id = 'cls-ext-float-copy';
      copyBtn.style.cssText = [
        'display:inline-flex',
        'align-items:center',
        'gap:6px',
        'border:none',
        'background:transparent',
        'color:#f8fafc',
        'padding:3px 6px',
        'border-radius:999px',
        'font:600 12px/1.2 system-ui,-apple-system,Segoe UI,sans-serif',
        'cursor:pointer',
        'transition:background 120ms ease'
      ].join(';');

      const dot = document.createElement('span');
      dot.style.cssText = 'width:7px;height:7px;border-radius:50%;background:#14b8a6;flex-shrink:0;';

      const label = document.createElement('span');
      label.id = 'cls-ext-float-label';

      copyBtn.appendChild(dot);
      copyBtn.appendChild(label);

      copyBtn.addEventListener('mouseenter', () => {
        copyBtn.style.background = 'rgba(20, 184, 166, 0.22)';
      });
      copyBtn.addEventListener('mouseleave', () => {
        copyBtn.style.background = 'transparent';
      });
      copyBtn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        if (!isContextAlive()) return teardown();
        chrome.runtime.sendMessage({ type: 'CLS_COPY_MERGED' }, (res) => {
          void chrome.runtime.lastError;
          if (res?.ok && label) {
            clearTimeout(copyFlashTimer);
            label.textContent = uiPrefs.collapsed ? '✓' : '✓ Đã copy';
            copyFlashTimer = setTimeout(() => updateBarText(bar), 1100);
          }
        });
      });

      // Nút thu gọn / mở rộng
      const collapseBtn = document.createElement('button');
      collapseBtn.type = 'button';
      collapseBtn.id = 'cls-ext-float-collapse';
      collapseBtn.style.cssText = [
        'border:none',
        'background:rgba(255,255,255,0.1)',
        'color:#cbd5e1',
        'width:20px',
        'height:20px',
        'border-radius:50%',
        'display:inline-flex',
        'align-items:center',
        'justify-content:center',
        'font:700 12px/1 system-ui,sans-serif',
        'cursor:pointer',
        'transition:background 120ms ease,color 120ms ease'
      ].join(';');
      collapseBtn.addEventListener('mouseenter', () => {
        collapseBtn.style.background = 'rgba(255,255,255,0.22)';
        collapseBtn.style.color = '#ffffff';
      });
      collapseBtn.addEventListener('mouseleave', () => {
        collapseBtn.style.background = 'rgba(255,255,255,0.1)';
        collapseBtn.style.color = '#cbd5e1';
      });
      collapseBtn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        uiPrefs.collapsed = !uiPrefs.collapsed;
        saveUiPrefs();
        updateBarText(bar);
      });

      // Nút xóa nhanh bộ gộp
      const clearBtn = document.createElement('button');
      clearBtn.type = 'button';
      clearBtn.id = 'cls-ext-float-clear';
      clearBtn.textContent = '× Xóa';
      clearBtn.title = 'Xóa toàn bộ bộ gộp (Alt+Shift+X)';
      clearBtn.style.cssText = [
        'border:none',
        'background:rgba(239, 68, 68, 0.2)',
        'color:#fca5a5',
        'padding:3px 8px',
        'border-radius:999px',
        'font:600 11.5px/1.2 system-ui,-apple-system,Segoe UI,sans-serif',
        'cursor:pointer',
        'align-items:center',
        'transition:background 120ms ease,color 120ms ease'
      ].join(';');
      clearBtn.addEventListener('mouseenter', () => {
        clearBtn.style.background = '#dc2626';
        clearBtn.style.color = '#ffffff';
      });
      clearBtn.addEventListener('mouseleave', () => {
        clearBtn.style.background = 'rgba(239, 68, 68, 0.2)';
        clearBtn.style.color = '#fca5a5';
      });
      clearBtn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        if (!isContextAlive()) return teardown();
        clearTimeout(t1);
        clearTimeout(t2);
        clearTimeout(mutTimer);
        chrome.runtime.sendMessage({ type: 'CLS_CLEAR_MERGE' }, () => {
          void chrome.runtime.lastError;
        });
      });

      // Kéo thả thanh nổi bằng Pointer Events
      let dragState = null;
      grip.addEventListener('pointerdown', (e) => {
        e.preventDefault();
        e.stopPropagation();
        grip.setPointerCapture(e.pointerId);
        grip.style.cursor = 'grabbing';
        dragState = {
          startX: e.clientX,
          startY: e.clientY,
          origRight: uiPrefs.right,
          origBottom: uiPrefs.bottom
        };
      });
      grip.addEventListener('pointermove', (e) => {
        if (!dragState) return;
        uiPrefs.right = dragState.origRight - (e.clientX - dragState.startX);
        uiPrefs.bottom = dragState.origBottom - (e.clientY - dragState.startY);
        clampBarPosition(bar);
      });
      const finishDrag = (e) => {
        if (!dragState) return;
        try { grip.releasePointerCapture(e.pointerId); } catch {}
        grip.style.cursor = 'grab';
        dragState = null;
        saveUiPrefs();
      };
      grip.addEventListener('pointerup', finishDrag);
      grip.addEventListener('pointercancel', finishDrag);

      bar.appendChild(grip);
      bar.appendChild(copyBtn);
      bar.appendChild(collapseBtn);
      bar.appendChild(clearBtn);
      document.body.appendChild(bar);
    }

    updateBarText(bar);
  }

  function onWinResize() {
    const bar = document.getElementById(FLOAT_BAR_ID);
    if (bar) clampBarPosition(bar);
  }

  function updateSessionState(session) {
    const sheets = Array.isArray(session?.sheets) ? session.sheets : [];
    mergedCount = sheets.length;
    const bn = session?.patient?.name || session?.patient?.id || '';
    const labels = sheets.map((s) => s.serviceName || s.label).filter(Boolean).join(', ');
    mergedTooltip = [bn ? `BN: ${bn}` : '', labels].filter(Boolean).join(' — ');
    renderFloatBar();
  }

  function isOwnNode(node) {
    if (!node) return false;
    const elem = node.nodeType === 1 ? node : node.parentElement;
    if (!elem) return false;
    return Boolean(
      elem.id === 'cls-ext-page-toast' ||
      elem.id === 'cls-ext-copy-tmp' ||
      elem.id === FLOAT_BAR_ID ||
      elem.closest?.(`#${FLOAT_BAR_ID}, #cls-ext-page-toast`)
    );
  }

  function isRelevantMutation(m) {
    if (isOwnNode(m.target)) return false;
    const added = Array.from(m.addedNodes || []);
    const removed = Array.from(m.removedNodes || []);
    if ((added.length || removed.length) && [...added, ...removed].every(isOwnNode)) {
      return false;
    }
    return true;
  }

  function triggerCapture() {
    if (!mergeEnabled) return;
    if (!isContextAlive()) return teardown();
    try {
      chrome.runtime.sendMessage({ type: 'CLS_BG_AUTO_CAPTURE' }, () => {
        void chrome.runtime.lastError;
      });
    } catch {
      teardown();
    }
  }

  function scheduleCapture() {
    if (!mergeEnabled) return;
    clearTimeout(t1);
    clearTimeout(t2);
    t1 = setTimeout(triggerCapture, 650);
    t2 = setTimeout(triggerCapture, 1800);
  }

  function startObserver() {
    if (observer || !document.body) return;
    observer = new MutationObserver((mutations) => {
      if (!mergeEnabled) return;
      if (!mutations.some(isRelevantMutation)) return;
      clearTimeout(mutTimer);
      mutTimer = setTimeout(triggerCapture, 550);
    });
    observer.observe(document.body, { childList: true, subtree: true, characterData: true });
  }

  function applyMergeFlag(next, triggerIfJustOn = false) {
    const wasOn = mergeEnabled;
    mergeEnabled = next !== false;
    if (mergeEnabled) {
      startObserver();
      if (triggerIfJustOn && !wasOn && window === window.top) {
        setTimeout(triggerCapture, 250);
      }
    } else {
      clearTimeout(t1);
      clearTimeout(t2);
      clearTimeout(mutTimer);
      stopObserver();
    }
    renderFloatBar();
  }

  function onDocClick(e) {
    if (!mergeEnabled) return;
    if (!isContextAlive()) return teardown();
    if (isOwnNode(e.target)) return;

    const target = e.target;
    const tag = (target?.tagName || '').toUpperCase();
    if (
      (tag === 'TEXTAREA' || (tag === 'INPUT' && target.type !== 'checkbox' && target.type !== 'radio')) &&
      !target.readOnly && !target.disabled
    ) {
      return;
    }
    scheduleCapture();
  }

  function onStorageChanged(changes, area) {
    if (area !== 'local') return;
    if (changes[SHARED_SETTINGS_KEY]?.newValue) {
      applyMergeFlag(changes[SHARED_SETTINGS_KEY].newValue.mergeEnabled, true);
    }
    if (changes[MERGE_SESSION_KEY]) {
      updateSessionState(changes[MERGE_SESSION_KEY].newValue || null);
    }
  }

  function teardown() {
    clearTimeout(t1);
    clearTimeout(t2);
    clearTimeout(mutTimer);
    clearTimeout(copyFlashTimer);
    stopObserver();
    removeFloatBar();
    document.removeEventListener('click', onDocClick, true);
    window.removeEventListener('resize', onWinResize);
    try { chrome.storage.onChanged.removeListener(onStorageChanged); } catch {}
    window.__clsHisWatcherCleanup = null;
  }
  window.__clsHisWatcherCleanup = teardown;

  try {
    chrome.storage.local.get([SHARED_SETTINGS_KEY, MERGE_SESSION_KEY], (data) => {
      if (chrome.runtime.lastError) return;
      applyMergeFlag(data?.[SHARED_SETTINGS_KEY]?.mergeEnabled, false);
      updateSessionState(data?.[MERGE_SESSION_KEY] || null);
    });
    chrome.storage.onChanged.addListener(onStorageChanged);
  } catch {}

  document.addEventListener('click', onDocClick, true);
  window.addEventListener('resize', onWinResize, { passive: true });
})();