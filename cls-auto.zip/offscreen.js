chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (!msg || msg.target !== 'offscreen' || msg.type !== 'COPY_TO_CLIPBOARD') return;
  const ta = document.getElementById('cls-copy-box');
  let ok = false;
  try {
    ta.value = String(msg.text || '');
    ta.focus();
    ta.select();
    ta.setSelectionRange(0, ta.value.length);
    ok = document.execCommand('copy');
  } catch {}
  sendResponse({ ok });
});