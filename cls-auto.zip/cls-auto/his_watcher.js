/* =========================================================
   HIS WATCHER — Tự động gộp ngầm khi click chuyển phiếu HIS
   ========================================================= */
(function() {
  const SHARED_SETTINGS_KEY = 'cls_shared_settings';
  let mergeEnabled = false;
  let t1 = null;
  let t2 = null;

  function loadFlag() {
    try {
      chrome.storage.local.get(SHARED_SETTINGS_KEY, (data) => {
        if (chrome.runtime.lastError) return;
        mergeEnabled = Boolean(data?.[SHARED_SETTINGS_KEY]?.mergeEnabled);
      });
    } catch {}
  }

  function triggerCapture() {
    if (!mergeEnabled) return;
    try {
      chrome.runtime.sendMessage({ type: 'CLS_BG_AUTO_CAPTURE' }, () => {
        void chrome.runtime.lastError;
      });
    } catch {}
  }

  function scheduleCapture() {
    if (!mergeEnabled) return;
    clearTimeout(t1);
    clearTimeout(t2);
    // Quét ở 650ms (HIS tải nhanh) và 1500ms (HIS tải AJAX chậm); trùng nội dung sẽ tự bỏ qua
    t1 = setTimeout(triggerCapture, 650);
    t2 = setTimeout(triggerCapture, 1500);
  }

  loadFlag();

  try {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === 'local' && changes[SHARED_SETTINGS_KEY]?.newValue) {
        const next = Boolean(changes[SHARED_SETTINGS_KEY].newValue.mergeEnabled);
        const justTurnedOn = next && !mergeEnabled;
        mergeEnabled = next;
        // Vừa bật Gộp khi đang đứng sẵn ở 1 bảng XN -> gộp luôn phiếu đang mở
        if (justTurnedOn && window === window.top) {
          setTimeout(triggerCapture, 250);
        }
      }
    });
  } catch {}

  document.addEventListener('click', (e) => {
    if (!mergeEnabled) return;
    const tag = (e.target?.tagName || '').toUpperCase();
    // Bỏ qua khi đang bấm vào ô nhập liệu để dán kết quả
    if (tag === 'TEXTAREA' || (tag === 'INPUT' && e.target.type !== 'checkbox' && e.target.type !== 'radio')) {
      return;
    }
    scheduleCapture();
  }, true);
})();