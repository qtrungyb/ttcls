/* =========================================================
   BACKGROUND — Quét CLS + Gộp ngầm HIS + Alt+Q + Chèn HIS
   ========================================================= */
const CLS_WEB_URL = 'https://qtrungyb.github.io/ttcls/';
const ABBR_ENDPOINT = 'https://tomtatcls-default-rtdb.asia-southeast1.firebasedatabase.app/abbreviations.json';
const SHARED_SETTINGS_KEY = 'cls_shared_settings';
const MERGE_SESSION_KEY = 'cls_merge_session_v1';
const ABBR_CACHE_KEY = 'cls_abbr_cache';

const BG_MERGE_PRIORITY = {
  CTM: 1, SHM: 2, ĐGĐ: 3, MD: 4, TPTNT: 5, ĐM: 6, KM: 7, VS: 8, XN: 9
};

const BG_SPECIAL_NAMES = [
  'Số lượng hồng cầu', 'Huyết sắc tố', 'Hematocrit',
  'Số lượng tiểu cầu', 'Số lượng bạch cầu', 'Tỷ lệ bạch cầu GR'
];
const BG_DEFAULT_ABBR = {
  'Số lượng hồng cầu': 'HC',
  'Huyết sắc tố': 'Hb',
  'Hematocrit': 'HTC',
  'Số lượng tiểu cầu': 'TC',
  'Số lượng bạch cầu': 'BC',
  'Tỷ lệ bạch cầu GR': 'N%'
};
const BG_SEP_INNER = { T3: ': ', T4: ': ', TSH: ': ', Tg: ': ' };
const BG_VALID_KEEP = ['inr', 'bệnh/ chứng r', 'bệnh/chứng r', 'alt', 'ast'];

const BG_RANGE_RE = /(\d+[.,]?\d*)\s*[-–]\s*(\d+[.,]?\d*)/;
const BG_LE_RE = /(<=|≤)\s*(\d+[.,]?\d*)/;
const BG_L_RE = /<\s*(\d+[.,]?\d*)/;
const BG_GE_RE = /(>=|≥)\s*(\d+[.,]?\d*)/;
const BG_G_RE = />\s*(\d+[.,]?\d*)/;

chrome.action.onClicked.addListener(async () => {
  const tabs = await chrome.tabs.query({ url: 'https://qtrungyb.github.io/*' });
  if (tabs.length) {
    await chrome.tabs.update(tabs[0].id, { active: true });
    await chrome.windows.update(tabs[0].windowId, { focused: true });
  } else {
    await chrome.tabs.create({ url: CLS_WEB_URL });
  }
});

function isScannableUrl(url) {
  if (typeof url !== 'string') return false;
  if (!/^https?:\/\//i.test(url)) return false;
  if (/^https?:\/\/qtrungyb\.github\.io\b/i.test(url)) return false;
  return true;
}

function withTimeout(promise, ms, msg) {
  return Promise.race([
    promise,
    new Promise((_, reject) => setTimeout(() => reject(new Error(msg)), ms))
  ]);
}

async function refreshMergeBadge() {
  try {
    const data = await chrome.storage.local.get([SHARED_SETTINGS_KEY, MERGE_SESSION_KEY]);
    const mergeOn = Boolean(data?.[SHARED_SETTINGS_KEY]?.mergeEnabled);
    const count = Array.isArray(data?.[MERGE_SESSION_KEY]?.sheets)
      ? data[MERGE_SESSION_KEY].sheets.length
      : 0;

    if (mergeOn && count > 0) {
      await chrome.action.setBadgeText({ text: String(count) });
      await chrome.action.setBadgeBackgroundColor({ color: '#0d9488' });
    } else if (mergeOn) {
      await chrome.action.setBadgeText({ text: '+' });
      await chrome.action.setBadgeBackgroundColor({ color: '#0d9488' });
    } else {
      await chrome.action.setBadgeText({ text: '' });
    }
  } catch {}
}

chrome.runtime.onInstalled.addListener(() => refreshMergeBadge());
chrome.runtime.onStartup.addListener(() => refreshMergeBadge());
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && (changes[SHARED_SETTINGS_KEY] || changes[MERGE_SESSION_KEY])) {
    refreshMergeBadge();
  }
});
refreshMergeBadge();

async function findTargetTabForScan(senderTabId) {
  try {
    const win = await chrome.windows.getLastFocused({ populate: true, windowTypes: ['normal'] });
    const active = win?.tabs?.find(
      (t) => t.active && !t.discarded && t.id !== senderTabId && isScannableUrl(t.url)
    );
    if (active) return active;
  } catch {}

  try {
    const activeTabs = await chrome.tabs.query({ active: true });
    const validActive = activeTabs
      .filter((t) => t.id && !t.discarded && t.id !== senderTabId && isScannableUrl(t.url))
      .sort((a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0));
    if (validActive.length) return validActive[0];

    const allTabs = await chrome.tabs.query({});
    const validAll = allTabs
      .filter((t) => t.id && !t.discarded && t.id !== senderTabId && isScannableUrl(t.url))
      .sort((a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0));
    if (validAll.length) return validAll[0];
  } catch {}

  return null;
}

function extractDataFromHIS() {
  const clean = (s) => String(s || '').replace(/\s+/g, ' ').trim();

  function isVisible(node) {
    if (!node || !node.getBoundingClientRect) return false;
    const style = window.getComputedStyle(node);
    if (style.display === 'none' || style.visibility === 'hidden' || parseFloat(style.opacity) === 0) {
      return false;
    }
    const rect = node.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  }

  function getCellText(cell) {
    if (!cell) return '';
    const field = cell.querySelector('input:not([type="checkbox"]):not([type="radio"]), textarea, select');
    if (field) {
      if (field.tagName === 'SELECT') {
        return clean(field.options[field.selectedIndex]?.text || '');
      }
      return clean(field.value);
    }
    return clean(cell.innerText || cell.textContent);
  }

  function extractHISMetadata() {
    let patientName = '';
    let patientId = '';

    const headerNodes = Array.from(document.querySelectorAll('div, span, header, h1, h2, h3, h4, p, td'));
    let bestHeaderText = '';
    for (const node of headerNodes) {
      if (!isVisible(node)) continue;
      const txt = clean(node.innerText || node.textContent);
      if (txt.length < 15 || txt.length > 350) continue;
      if (/người bệnh\s*:/i.test(txt) && /mã\s*:/i.test(txt)) {
        if (!bestHeaderText || txt.length < bestHeaderText.length) {
          bestHeaderText = txt;
        }
      }
    }

    if (bestHeaderText) {
      const mName = bestHeaderText.match(/người bệnh\s*:\s*([^|\n\r]+)/i);
      const mId = bestHeaderText.match(/mã(?:\s*(?:bn|bệnh nhân|người bệnh))?\s*:\s*([^\s|\n\r]+)/i);
      if (mName) patientName = clean(mName[1]);
      if (mId) patientId = clean(mId[1]);
    }

    function findFieldByLabel(patterns) {
      const ignoredLabels = [
        'loại dịch vụ', 'loại xét nghiệm', 'nhóm dịch vụ', 'tên dịch vụ',
        'thời gian trả kết quả', 'ngày trả kết quả', 'tg trả kết quả',
        'thời gian thực hiện', 'người thực hiện', 'nơi thực hiện', 'danh sách chỉ số'
      ];

      function isAnotherLabel(val) {
        const low = val.toLowerCase().replace(/:$/, '').trim();
        return ignoredLabels.includes(low);
      }

      const nodes = Array.from(document.querySelectorAll('label, div, span, td, th, p'));
      for (const node of nodes) {
        if (!isVisible(node)) continue;
        if (node.querySelector('input, textarea, select')) continue;
        const txt = clean(node.innerText || node.textContent).toLowerCase().replace(/:$/, '').trim();
        if (!txt || txt.length > 40) continue;
        if (!patterns.some((p) => txt === p)) continue;

        const candidates = [
          node.nextElementSibling,
          node.parentElement,
          node.parentElement?.nextElementSibling
        ].filter(Boolean);

        for (const box of candidates) {
          const field = box.matches?.('input, textarea, select')
            ? box
            : box.querySelector?.('input:not([type="checkbox"]):not([type="radio"]):not([type="hidden"]), textarea, select');
          if (field && isVisible(field)) {
            const val = field.tagName === 'SELECT'
              ? clean(field.options[field.selectedIndex]?.text || '')
              : clean(field.value);
            if (val) return val;
          }
        }

        const next = node.nextElementSibling;
        if (next && isVisible(next)) {
          const val = clean(next.innerText || next.textContent);
          if (val && val.length <= 120 && !isAnotherLabel(val)) return val;
        }

        const parent = node.parentElement;
        if (parent) {
          const parentText = clean(parent.innerText || parent.textContent);
          if (parentText.toLowerCase().replace(/:$/, '').trim() === txt) {
            const pNext = parent.nextElementSibling;
            if (pNext && isVisible(pNext)) {
              const val = clean(pNext.innerText || pNext.textContent);
              if (val && val.length <= 120 && !isAnotherLabel(val)) return val;
            }
          } else if (parentText.length > txt.length && parentText.length <= 140) {
            const stripped = clean(parentText.replace(new RegExp('^' + txt.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\s*:?\\s*', 'i'), ''));
            if (stripped && stripped.length <= 100 && !isAnotherLabel(stripped)) return stripped;
          }
        }
      }
      return '';
    }

    const serviceName = findFieldByLabel(['loại dịch vụ', 'loại xét nghiệm', 'nhóm dịch vụ', 'tên dịch vụ']);
    const resultTime = findFieldByLabel([
      'thời gian trả kết quả',
      'ngày trả kết quả',
      'tg trả kết quả',
      'thời gian thực hiện'
    ]);

    return { patientName, patientId, serviceName, resultTime };
  }

  function mapHeaderRow(row) {
    const map = { stt: -1, name: -1, value: -1, ref: -1, unit: -1 };
    const cells = Array.from(row.cells || []);

    cells.forEach((cell, idx) => {
      const h = getCellText(cell).toLowerCase();
      if (!h) return;

      if (map.stt === -1 && /^(stt|tt|#)$/.test(h)) {
        map.stt = idx;
      } else if (
        map.name === -1 &&
        !h.includes('loại xét nghiệm') &&
        (h === 'chỉ số' || h.includes('chỉ số') || h.includes('tên xét nghiệm') ||
         h.includes('tên xn') || h.includes('thông số'))
      ) {
        map.name = idx;
      } else if (
        map.value === -1 &&
        !h.includes('tiền sử') && !h.includes('cũ') && !h.includes('trước') &&
        (h === 'kết quả' || h.includes('kết quả') || h === 'kq' || h === 'giá trị' || h === 'result')
      ) {
        map.value = idx;
      } else if (
        map.ref === -1 &&
        (h.includes('tham chiếu') || h.includes('trị số') || h.includes('bình thường') ||
         h.includes('csbt') || h.includes('ngưỡng') || h.includes('reference'))
      ) {
        map.ref = idx;
      } else if (
        map.unit === -1 &&
        (h.includes('đơn vị') || h === 'đv' || h === 'unit')
      ) {
        map.unit = idx;
      }
    });

    let score = 0;
    if (map.name !== -1) score += 3;
    if (map.value !== -1) score += 3;
    if (map.ref !== -1) score += 2;
    if (map.unit !== -1) score += 1;
    if (map.stt !== -1) score += 1;

    return { map, score, colCount: cells.length };
  }

  function findPairedBodyTable(headerTable, expectedCols) {
    let container = headerTable.parentElement;
    for (let depth = 0; depth < 3 && container && container !== document.body; depth++) {
      const candidates = Array.from(container.querySelectorAll('table')).filter((t) => {
        if (t === headerTable || !isVisible(t)) return false;
        if (!(headerTable.compareDocumentPosition(t) & Node.DOCUMENT_POSITION_FOLLOWING)) return false;
        const rows = t.tBodies.length ? Array.from(t.tBodies[0].rows) : Array.from(t.rows);
        return rows.length > 0;
      });

      if (candidates.length) {
        const exact = candidates.find((t) => {
          const firstRow = (t.tBodies[0]?.rows[0]) || t.rows[0];
          return firstRow && firstRow.cells.length === expectedCols;
        });
        return exact || candidates[0];
      }
      container = container.parentElement;
    }
    return null;
  }

  const meta = extractHISMetadata();

  const selection = window.getSelection()?.toString() || '';
  if (selection.trim() && /[\t\n]/.test(selection) && /\d/.test(selection)) {
    return { type: 'selection', text: selection.trim(), meta };
  }

  const visibleTables = Array.from(document.querySelectorAll('table')).filter(isVisible);
  let bestCls = null;

  for (const table of visibleTables) {
    const headerCandidates = table.tHead
      ? Array.from(table.tHead.rows)
      : Array.from(table.rows).slice(0, 2);

    let bestHeader = null;
    let headerRowRef = null;
    for (const hRow of headerCandidates) {
      const res = mapHeaderRow(hRow);
      if (!bestHeader || res.score > bestHeader.score) {
        bestHeader = res;
        headerRowRef = hRow;
      }
    }

    if (!bestHeader || bestHeader.map.name === -1 || bestHeader.map.value === -1) continue;

    let dataRows = [];
    if (table.tBodies && table.tBodies.length) {
      for (const tb of table.tBodies) dataRows.push(...Array.from(tb.rows));
    } else {
      dataRows = Array.from(table.rows);
    }
    dataRows = dataRows.filter((r) => r !== headerRowRef && isVisible(r));

    if (!dataRows.length) {
      const bodyTable = findPairedBodyTable(table, bestHeader.colCount);
      if (bodyTable) {
        const bodyRows = bodyTable.tBodies?.length
          ? Array.from(bodyTable.tBodies[0].rows)
          : Array.from(bodyTable.rows);
        dataRows = bodyRows.filter(isVisible);
      }
    }

    const { map } = bestHeader;
    const lines = [];
    let autoStt = 1;

    for (const row of dataRows) {
      const cells = Array.from(row.cells || []);
      if (cells.length <= Math.max(map.name, map.value)) continue;

      const name = getCellText(cells[map.name]);
      const value = getCellText(cells[map.value]);
      if (!name || !value) continue;

      const nameLower = name.toLowerCase();
      if (nameLower === 'chỉ số' || nameLower === 'tên xét nghiệm') continue;

      let stt = map.stt !== -1 && cells[map.stt] ? getCellText(cells[map.stt]) : '';
      if (!/^\d+$/.test(stt)) stt = String(autoStt);
      autoStt++;

      const ref = map.ref !== -1 && cells[map.ref] ? getCellText(cells[map.ref]) : '';
      const unit = map.unit !== -1 && cells[map.unit] ? getCellText(cells[map.unit]) : '';

      lines.push([stt, name, value, ref || '—', unit].join('\t'));
    }

    if (lines.length > 0) {
      const candidate = {
        type: 'cls_table',
        score: bestHeader.score,
        rowCount: lines.length,
        text: lines.join('\n'),
        meta
      };
      if (
        !bestCls ||
        candidate.score > bestCls.score ||
        (candidate.score === bestCls.score && candidate.rowCount > bestCls.rowCount)
      ) {
        bestCls = candidate;
      }
    }
  }

  if (bestCls) return bestCls;

  if (visibleTables.length > 0) {
    let bestTable = visibleTables[0];
    for (const t of visibleTables) {
      if ((t.innerText || '').length > (bestTable.innerText || '').length) {
        bestTable = t;
      }
    }
    let resultText = '';
    for (const row of bestTable.rows) {
      if (!isVisible(row)) continue;
      resultText += Array.from(row.cells).map(getCellText).join('\t') + '\n';
    }
    return { type: 'table', text: resultText.trim(), meta };
  }

  if (meta.patientId || meta.patientName || meta.serviceName) {
    return { type: 'meta_only', text: '', meta };
  }

  return null;
}

function pickBestResult(results, mode = 'manual') {
  const validResults = (results || []).map((r) => r.result).filter(Boolean);
  const clsTableHit = validResults
    .filter((r) => r.type === 'cls_table' && r.text.trim())
    .sort((a, b) => (b.score - a.score) || (b.rowCount - a.rowCount))[0];

  if (mode === 'auto') {
    return clsTableHit || null;
  }

  const selectionHit = validResults.find((r) => r.type === 'selection' && r.text.trim());
  const fallbackTableHit = validResults
    .filter((r) => r.type === 'table' && r.text.trim())
    .sort((a, b) => b.text.length - a.text.length)[0];

  return selectionHit || clsTableHit || fallbackTableHit || null;
}

function mergeMeta(primary, fallback) {
  const a = primary || {};
  const b = fallback || {};
  return {
    patientName: a.patientName || b.patientName || '',
    patientId: a.patientId || b.patientId || '',
    serviceName: a.serviceName || b.serviceName || '',
    resultTime: a.resultTime || b.resultTime || ''
  };
}

async function scanSpecificTab(tab, mode = 'manual') {
  if (!tab || !tab.id) {
    if (mode === 'auto') return { ok: true, empty: true };
    return { ok: false, error: 'Không tìm thấy tab trang bệnh án (HIS) đang mở.' };
  }

  let mainHit = null;
  let mainMeta = null;
  try {
    const mainRes = await withTimeout(
      chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: extractDataFromHIS
      }),
      mode === 'auto' ? 1500 : 2500,
      'Quét khung chính quá thời gian.'
    );
    mainMeta = mainRes?.[0]?.result?.meta || null;
    mainHit = pickBestResult(mainRes, mode);
  } catch (err) {
    if (mode === 'auto') return { ok: true, empty: true };
    return { ok: false, error: `Không đọc được tab "${tab.title || tab.url}": ${err.message}` };
  }

  if (mainHit && (mainHit.type === 'selection' || mainHit.type === 'cls_table')) {
    return { ok: true, tabId: tab.id, text: mainHit.text, type: mainHit.type, meta: mergeMeta(mainHit.meta, mainMeta) };
  }

  let frameHit = null;
  try {
    const frameRes = await withTimeout(
      chrome.scripting.executeScript({
        target: { tabId: tab.id, allFrames: true },
        func: extractDataFromHIS
      }),
      mode === 'auto' ? 2000 : 3000,
      'iframe phản hồi chậm.'
    );
    frameHit = pickBestResult(frameRes, mode);
  } catch {}

  const best = (frameHit && (frameHit.type === 'selection' || frameHit.type === 'cls_table'))
    ? frameHit
    : (mainHit || frameHit);

  if (best && best.text && best.text.trim()) {
    return { ok: true, tabId: tab.id, text: best.text, type: best.type, meta: mergeMeta(best.meta, mainMeta) };
  }

  if (mode === 'auto') return { ok: true, empty: true };
  return { ok: false, tabId: tab.id, error: `Không thấy bảng xét nghiệm ở tab: ${tab.title || tab.url}` };
}

async function handleScanHIS(senderTabId, mode = 'manual') {
  const tab = await findTargetTabForScan(senderTabId);
  return scanSpecificTab(tab, mode);
}

function copyTextInPage(text) {
  const ta = document.createElement('textarea');
  ta.value = text;
  ta.setAttribute('readonly', '');
  ta.style.cssText = 'position:fixed;top:0;left:0;opacity:0;pointer-events:none;';
  document.body.appendChild(ta);
  ta.focus({ preventScroll: true });
  ta.select();
  ta.setSelectionRange(0, text.length);
  let ok = false;
  try { ok = document.execCommand('copy'); } catch {}
  ta.remove();
  return ok;
}

function insertTextInPage(text) {
  function getDeepActiveElement(root) {
    let active = root.activeElement;
    while (active && active.shadowRoot && active.shadowRoot.activeElement) {
      active = active.shadowRoot.activeElement;
    }
    return active;
  }

  const target = getDeepActiveElement(document);
  if (!target || target === document.body || target === document.documentElement) {
    return { ok: false };
  }

  const tag = (target.tagName || '').toUpperCase();
  const isTextInput =
    tag === 'TEXTAREA' ||
    (tag === 'INPUT' && ['text', 'search', 'url', 'tel', 'email', ''].includes((target.type || 'text').toLowerCase()));
  const isEditable = Boolean(target.isContentEditable);

  if ((!isTextInput && !isEditable) || target.disabled || target.readOnly) {
    return { ok: false };
  }

  target.focus({ preventScroll: true });

  let inserted = false;
  try {
    inserted = document.execCommand('insertText', false, text);
  } catch {}

  if (!inserted && isTextInput) {
    const start = typeof target.selectionStart === 'number' ? target.selectionStart : target.value.length;
    const end = typeof target.selectionEnd === 'number' ? target.selectionEnd : target.value.length;
    const nextVal = target.value.slice(0, start) + text + target.value.slice(end);
    const proto = tag === 'TEXTAREA' ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
    if (setter) setter.call(target, nextVal);
    else target.value = nextVal;

    try {
      target.setSelectionRange(start + text.length, start + text.length);
    } catch {}
    target.dispatchEvent(new Event('input', { bubbles: true }));
    target.dispatchEvent(new Event('change', { bubbles: true }));
    inserted = true;
  } else if (!inserted && isEditable) {
    const sel = window.getSelection();
    if (sel && sel.rangeCount) {
      const range = sel.getRangeAt(0);
      range.deleteContents();
      const node = document.createTextNode(text);
      range.insertNode(node);
      range.setStartAfter(node);
      range.collapse(true);
      sel.removeAllRanges();
      sel.addRange(range);
      target.dispatchEvent(new Event('input', { bubbles: true }));
      inserted = true;
    }
  }

  return { ok: Boolean(inserted) };
}

function showPageToast(message, isError = false) {
  const id = 'cls-ext-page-toast';
  const old = document.getElementById(id);
  if (old) old.remove();

  const el = document.createElement('div');
  el.id = id;
  el.textContent = message;
  el.style.cssText = [
    'position:fixed',
    'bottom:24px',
    'right:24px',
    'z-index:2147483647',
    'padding:10px 16px',
    'border-radius:10px',
    'font:600 13px/1.4 system-ui,-apple-system,Segoe UI,sans-serif',
    'color:#ffffff',
    `background:${isError ? '#dc2626' : '#0f766e'}`,
    'box-shadow:0 8px 24px rgba(0,0,0,0.22)',
    'transition:opacity 220ms ease',
    'pointer-events:none'
  ].join(';');
  document.body.appendChild(el);

  setTimeout(() => { el.style.opacity = '0'; }, 2200);
  setTimeout(() => { el.remove(); }, 2500);
}

async function notifyTab(tabId, message, isError = false) {
  if (!tabId) return;
  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      func: showPageToast,
      args: [message, isError]
    });
  } catch {}
}

async function handleCopyInActiveTab(senderTabId, text) {
  const tab = await findTargetTabForScan(senderTabId);
  if (!tab || !tab.id) return { ok: false };
  try {
    const res = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: copyTextInPage,
      args: [text]
    });
    return { ok: Boolean(res?.[0]?.result) };
  } catch {
    return { ok: false };
  }
}

async function handleInsertToHIS(senderTabId, text) {
  const tab = await findTargetTabForScan(senderTabId);
  if (!tab || !tab.id) {
    return { ok: false, error: 'Không tìm thấy tab HIS đang mở.' };
  }

  try {
    const mainRes = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: insertTextInPage,
      args: [text]
    });
    if (mainRes?.[0]?.result?.ok) return { ok: true };

    const frameRes = await chrome.scripting.executeScript({
      target: { tabId: tab.id, allFrames: true },
      func: insertTextInPage,
      args: [text]
    });
    if ((frameRes || []).some((r) => r?.result?.ok)) return { ok: true };

    return { ok: false, error: 'Hãy click đặt con trỏ vào ô văn bản trên HIS trước khi bấm Chèn.' };
  } catch (err) {
    return { ok: false, error: 'Không thể chèn vào trang này: ' + (err?.message || err) };
  }
}

/* ---------- Xử lý tóm tắt & gộp ngầm trong Background ---------- */
function bgParseNumber(str) {
  const m = str && String(str).replace(/,/g, '.').replace(/\s+/g, '').match(/-?\d+(?:\.\d+)?/);
  return m ? parseFloat(m[0]) : NaN;
}

function bgCleanName(raw) {
  if (!raw) return '';
  const str = raw.trim().replace(/^["']|["']$/g, '');
  const m = str.match(/^\([^)]+\)\s*(.*)/);
  let name = m ? m[1].trim() : str;
  name = name.replace(/\s*\(([^)]+)\)/g, (match, inner) =>
    BG_VALID_KEEP.includes(inner.trim().toLowerCase()) ? match : ''
  );
  return name.trim();
}

function bgGetStatus(valStr, rangeStr) {
  const val = bgParseNumber(valStr);
  if (isNaN(val) || !rangeStr) return 'unknown';
  let m;
  if ((m = rangeStr.match(BG_RANGE_RE))) return (val < bgParseNumber(m[1]) || val > bgParseNumber(m[2])) ? 'abnormal' : 'normal';
  if ((m = rangeStr.match(BG_LE_RE)))    return val <= bgParseNumber(m[2]) ? 'normal' : 'abnormal';
  if ((m = rangeStr.match(BG_L_RE)))     return val <  bgParseNumber(m[1]) ? 'normal' : 'abnormal';
  if ((m = rangeStr.match(BG_GE_RE)))    return val >= bgParseNumber(m[2]) ? 'normal' : 'abnormal';
  if ((m = rangeStr.match(BG_G_RE)))     return val >  bgParseNumber(m[1]) ? 'normal' : 'abnormal';
  return 'unknown';
}

function bgParseInputToRows(rawText) {
  const lines = String(rawText || '').split(/\r?\n/);
  const rows = [];
  for (const line of lines) {
    if (!line.trim()) continue;
    const cols = line.split('\t').map((c) => c.trim()).filter(Boolean);
    if (cols.length >= 3 && /^\d+$/.test(cols[0])) {
      const refRange = cols[3] || '';
      rows.push({
        stt: cols[0],
        cleanName: bgCleanName(cols[1]),
        value: cols[2],
        refRange,
        unit: cols[4] || '',
        _status: bgGetStatus(cols[2], refRange)
      });
    }
  }
  return rows;
}

function bgRowOverlapRatio(rowsA, rowsB) {
  if (!rowsA?.length || !rowsB?.length) return 0;
  const setA = new Set(rowsA.map((r) => r.cleanName.toLowerCase()));
  const setB = new Set(rowsB.map((r) => r.cleanName.toLowerCase()));
  let common = 0;
  for (const n of setA) if (setB.has(n)) common++;
  return common / Math.min(setA.size, setB.size);
}

function bgShortLabel(serviceName, rows) {
  const names = (rows || []).map((r) => r.cleanName.toLowerCase()).join(' | ');
  const svc = String(serviceName || '').toLowerCase();

  if (svc.includes('nước tiểu') || svc.includes('tptnt') || names.includes('tỷ trọng') || names.includes('urobilinogen') || names.includes('nitrit') || names.includes('cetonic') || names.includes('keton')) return 'TPTNT';
  if (names.includes('huyết sắc tố') || names.includes('hematocrit') || names.includes('số lượng hồng cầu') || names.includes('số lượng tiểu cầu') || names.includes('số lượng bạch cầu') || names.includes('thể tích trung bình hồng cầu') || /\bmcv\b|\bmch\b|\bmchc\b/.test(names)) return 'CTM';
  if (/\binr\b|\baptt\b/.test(names) || names.includes('fibrinogen') || names.includes('prothrombin') || names.includes('d-dimer')) return 'ĐM';
  if (/\bpco2\b|\bpo2\b|\bhco3\b/.test(names)) return 'KM';
  if (svc.includes('miễn dịch') || names.includes('ferritin') || names.includes('procalcitonin') || names.includes('troponin') || names.includes('pro-bnp') || names.includes('hbsag') || names.includes('anti-hbs') || names.includes('anti-hcv') || names.includes('dengue') || names.includes('beta-hcg') || names.includes('cortisol') || names.includes('insulin') || names.includes('vitamin d') || names.includes('vitamin b12') || names.includes('acid folic') || /\b(tsh|ft3|ft4|afp|cea|psa|hiv|ns1|ige|igg|igm|aso|anti-ccp)\b/.test(names)) return 'MD';
  if (names.includes('sgpt') || names.includes('sgot') || /\b(alt|ast|ggt|crp|hdl|ldl|ldh|ck-mb|alp|tibc|nh3)\b/.test(names) || names.includes('creatinin') || names.includes('urê') || names.includes('urea') || names.includes('glucose') || names.includes('cholesterol') || names.includes('triglycerid') || names.includes('acid uric') || names.includes('hba1c') || names.includes('amylase') || names.includes('lipase') || names.includes('albumin') || names.includes('protein') || names.includes('bilirubin') || names.includes('sắt huyết thanh') || names.includes('định lượng sắt') || names.includes('transferrin') || names.includes('canxi') || names.includes('calcium') || names.includes('magie') || names.includes('phospho') || names.includes('lactat')) return 'SHM';
  if (svc.includes('điện giải') || names.includes('natri') || names.includes('kali') || names.includes('clo') || names.includes('na+') || names.includes('k+')) return 'ĐGĐ';
  if (svc.includes('huyết học') || svc.includes('công thức máu') || svc.includes('tế bào máu')) return 'CTM';
  if (svc.includes('hóa sinh') || svc.includes('sinh hóa')) return 'SHM';
  if (svc.includes('đông máu')) return 'ĐM';
  if (svc.includes('vi sinh')) return 'VS';
  if (svc.includes('khí máu')) return 'KM';
  if (serviceName) return serviceName.replace(/^xét nghiệm\s+/i, '').trim().slice(0, 18);
  return 'XN';
}

function bgFilterRows(rows, filterName) {
  if (filterName === 'abnormal') return rows.filter((r) => r._status === 'abnormal');
  if (filterName === 'all') return rows;
  const main = rows.filter((r) => BG_SPECIAL_NAMES.includes(r.cleanName));
  return main.length ? main : rows;
}

function bgFormatRows(rows, settings, abbrMap) {
  const showUnit = Boolean(settings?.showUnit);
  const showAbbr = settings?.showAbbr !== false;
  const copyFormat = settings?.copyFormat || 'comma';
  const parts = [];
  for (const r of rows) {
    if (!r.value || r.value.trim().toLowerCase() === '- neg') continue;
    const name = (showAbbr && abbrMap[r.cleanName]) ? abbrMap[r.cleanName] : r.cleanName;
    const sep = BG_SEP_INNER[name] || ' ';
    const unit = (showUnit && r.unit) ? ' ' + r.unit : '';
    parts.push(`${name}${sep}${r.value}${unit}`);
  }
  const joiner = copyFormat === 'newline' ? '\n' : (copyFormat === 'semicolon' ? '; ' : ', ');
  return { plain: parts.join(joiner), count: parts.length };
}

function bgFormatMergedSheets(sheets, settings, abbrMap) {
  const filterName = settings?.mergeFilter || 'main';
  const copyFormat = settings?.copyFormat || 'comma';
  const outputGroups = [];

  for (const sheet of sheets) {
    const rows = bgParseInputToRows(sheet.rawText);
    const filtered = bgFilterRows(rows, filterName);
    if (!filtered.length) continue;

    const target = outputGroups.find(
      (g) => g.label === sheet.label && bgRowOverlapRatio(g.rows, filtered) === 0
    );
    if (target) target.rows.push(...filtered);
    else outputGroups.push({ label: sheet.label, rows: [...filtered] });
  }

  const blocks = [];
  for (const g of outputGroups) {
    const { plain } = bgFormatRows(g.rows, settings, abbrMap);
    if (!plain) continue;
    blocks.push(copyFormat === 'newline' ? `- ${g.label}:\n${plain}` : `- ${g.label}: ${plain}`);
  }
  return blocks.join('\n');
}

async function getAbbrMapForBackground() {
  const stored = await chrome.storage.local.get(ABBR_CACHE_KEY);
  if (stored?.[ABBR_CACHE_KEY] && Object.keys(stored[ABBR_CACHE_KEY]).length) {
    return stored[ABBR_CACHE_KEY];
  }
  try {
    const res = await withTimeout(fetch(ABBR_ENDPOINT, { cache: 'no-store' }), 2000, 'timeout');
    if (res.ok) {
      const data = await res.json();
      const map = {};
      Object.values(data || {}).forEach((item) => {
        if (item && item.raw != null && item.short != null) map[item.raw] = item.short;
      });
      if (Object.keys(map).length) {
        await chrome.storage.local.set({ [ABBR_CACHE_KEY]: map });
        return map;
      }
    }
  } catch {}
  return { ...BG_DEFAULT_ABBR };
}

async function upsertMergeInBackground(rawText, meta, settings, abbrMap, forceNotify = false) {
  const rows = bgParseInputToRows(rawText);
  if (!rows.length) return { empty: true };

  const stored = await chrome.storage.local.get(MERGE_SESSION_KEY);
  const session = stored?.[MERGE_SESSION_KEY] || { patient: { id: '', name: '' }, sheets: [] };
  let patient = { id: session.patient?.id || '', name: session.patient?.name || '' };
  let sheets = Array.isArray(session.sheets) ? [...session.sheets] : [];

  const incomingId = meta?.patientId || '';
  const incomingName = meta?.patientName || '';
  let patientSwitched = false;

  if (incomingId && patient.id && incomingId !== patient.id) {
    sheets = [];
    patientSwitched = true;
  }

  // Nếu phiếu này đã nằm nguyên xi trong bộ gộp hiện tại -> bỏ qua khi tự động quét ngầm
  if (!patientSwitched && !forceNotify && sheets.some((s) => s.rawText === rawText)) {
    return { unchanged: true };
  }

  if (incomingId) patient.id = incomingId;
  if (incomingName) patient.name = incomingName;

  const label = bgShortLabel(meta?.serviceName, rows);
  const resultTime = (meta?.resultTime || '').trim();
  const sig = rows.slice(0, 3).map((r) => r.cleanName.toLowerCase()).join('|');
  const key = [label.toLowerCase(), resultTime, sig].filter(Boolean).join('__');

  const sheetObj = {
    key,
    label,
    serviceName: meta?.serviceName || label,
    resultTime,
    rawText
  };

  let existingIdx = sheets.findIndex((s) => s.rawText === rawText);
  if (existingIdx === -1) {
    existingIdx = sheets.findIndex((s) => {
      if (s.label !== label) return false;
      if (s.resultTime && resultTime && s.resultTime !== resultTime) return false;
      return bgRowOverlapRatio(bgParseInputToRows(s.rawText), rows) >= 0.5;
    });
  }

  const isUpdated = existingIdx !== -1;
  if (isUpdated) {
    if (!sheetObj.resultTime && sheets[existingIdx].resultTime) {
      sheetObj.resultTime = sheets[existingIdx].resultTime;
    }
    sheets[existingIdx] = sheetObj;
  } else {
    sheets.push(sheetObj);
  }

  sheets.sort((a, b) => (BG_MERGE_PRIORITY[a.label] || 9) - (BG_MERGE_PRIORITY[b.label] || 9));

  const nextSession = { patient, sheets, updatedAt: Date.now() };
  await chrome.storage.local.set({ [MERGE_SESSION_KEY]: nextSession });

  const plain = bgFormatMergedSheets(sheets, settings, abbrMap);
  return { plain, label, isUpdated, patientSwitched, patient, count: sheets.length };
}

let bgCaptureBusy = false;
async function handleBackgroundAutoCapture(tab) {
  if (bgCaptureBusy || !tab || !tab.id || !isScannableUrl(tab.url)) return { ok: true };
  bgCaptureBusy = true;
  try {
    const stored = await chrome.storage.local.get(SHARED_SETTINGS_KEY);
    const settings = stored?.[SHARED_SETTINGS_KEY] || {};
    if (!settings.mergeEnabled) return { ok: true };

    const scanRes = await scanSpecificTab(tab, 'auto');
    if (!scanRes.ok || scanRes.empty || !scanRes.text?.trim()) return { ok: true };

    const abbrMap = await getAbbrMapForBackground();
    const res = await upsertMergeInBackground(scanRes.text.trim(), scanRes.meta, settings, abbrMap, false);
    if (res.empty || res.unchanged || !res.plain) return { ok: true };

    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: copyTextInPage,
      args: [res.plain]
    }).catch(() => {});

    const toastMsg = res.patientSwitched
      ? `✓ Đổi BN ${res.patient.name || res.patient.id} — gộp mới (${res.label})`
      : (res.isUpdated
        ? `✓ Cập nhật ${res.label} (${res.count} phiếu) & copy`
        : `✓ Đã gộp +${res.label} (${res.count} phiếu) & copy`);

    await notifyTab(tab.id, toastMsg, false);
    return { ok: true };
  } finally {
    bgCaptureBusy = false;
  }
}

async function handleQuickScanCommand() {
  const scanRes = await handleScanHIS(null, 'manual');
  if (!scanRes.ok || !scanRes.text?.trim()) {
    const tab = await findTargetTabForScan(null);
    await notifyTab(tab?.id, scanRes.error || 'Không tìm thấy bảng xét nghiệm trên trang này', true);
    return;
  }

  const stored = await chrome.storage.local.get(SHARED_SETTINGS_KEY);
  const settings = stored?.[SHARED_SETTINGS_KEY] || {};
  const abbrMap = await getAbbrMapForBackground();

  if (settings.mergeEnabled) {
    const res = await upsertMergeInBackground(scanRes.text.trim(), scanRes.meta, settings, abbrMap, true);
    if (!res.plain) {
      await notifyTab(scanRes.tabId, 'Không có chỉ số hợp lệ để gộp', true);
      return;
    }
    const copied = await chrome.scripting.executeScript({
      target: { tabId: scanRes.tabId },
      func: copyTextInPage,
      args: [res.plain]
    }).then((r) => Boolean(r?.[0]?.result)).catch(() => false);

    await notifyTab(
      scanRes.tabId,
      copied ? `✓ Đã gộp ${res.label} (${res.count} phiếu) & copy` : 'Đã gộp nhưng không copy được',
      !copied
    );
    return;
  }

  const rows = bgParseInputToRows(scanRes.text);
  const picked = bgFilterRows(rows, 'main');
  const { plain, count } = bgFormatRows(picked, settings, abbrMap);

  if (!plain) {
    await notifyTab(scanRes.tabId, 'Không có chỉ số hợp lệ để tóm tắt', true);
    return;
  }

  const copied = await chrome.scripting.executeScript({
    target: { tabId: scanRes.tabId },
    func: copyTextInPage,
    args: [plain]
  }).then((r) => Boolean(r?.[0]?.result)).catch(() => false);

  await notifyTab(
    scanRes.tabId,
    copied ? `✓ Đã quét & copy (${count} chỉ số)` : 'Đã quét xong nhưng không copy được',
    !copied
  );
}

chrome.commands.onCommand.addListener((command) => {
  if (command === 'quick-scan-copy') {
    handleQuickScanCommand().catch(() => {});
  }
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg) return;

  if (msg.type === 'CLS_BG_AUTO_CAPTURE') {
    handleBackgroundAutoCapture(sender?.tab)
      .then((res) => sendResponse(res))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }

  if (msg.type === 'CLS_SCAN_HIS') {
    handleScanHIS(sender?.tab?.id, msg.mode || 'manual')
      .then((res) => sendResponse(res))
      .catch((err) => sendResponse({ ok: false, error: err?.message || String(err) }));
    return true;
  }

  if (msg.type === 'CLS_COPY_TEXT' && msg.text) {
    handleCopyInActiveTab(sender?.tab?.id, msg.text)
      .then((res) => sendResponse(res))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }

  if (msg.type === 'CLS_INSERT_HIS' && msg.text) {
    handleInsertToHIS(sender?.tab?.id, msg.text)
      .then((res) => sendResponse(res))
      .catch((err) => sendResponse({ ok: false, error: err?.message || String(err) }));
    return true;
  }
});