@echo off
chcp 65001 >nul
setlocal
title Cap nhat Tien ich Tom tat CLS

set "TARGET_DIR=%~dp0"
echo ============================================
echo   CAP NHAT TIEN ICH TOM TAT CLS (1 CHAM)
echo ============================================
echo.
echo Dang tai ban moi nhat tu GitHub...

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ErrorActionPreference = 'Stop'; " ^
  "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; " ^
  "$target = $env:TARGET_DIR.TrimEnd('\'); " ^
  "$zip = Join-Path $env:TEMP ('cls-auto-' + (Get-Date).Ticks + '.zip'); " ^
  "$tmp = Join-Path $env:TEMP ('cls-auto-ext-' + (Get-Date).Ticks); " ^
  "$url = 'https://qtrungyb.github.io/ttcls/cls-auto.zip?t=' + (Get-Date).Ticks; " ^
  "try { " ^
  "  $oldVer = ''; " ^
  "  $oldMf = Join-Path $target 'manifest.json'; " ^
  "  if (Test-Path $oldMf) { $oldVer = (Get-Content $oldMf -Raw -Encoding UTF8 | ConvertFrom-Json).version }; " ^
  "  Invoke-WebRequest -Uri $url -OutFile $zip -UseBasicParsing; " ^
  "  Expand-Archive -Path $zip -DestinationPath $tmp -Force; " ^
  "  $mf = Get-ChildItem -Path $tmp -Filter 'manifest.json' -Recurse | Select-Object -First 1; " ^
  "  if (-not $mf) { throw 'Khong tim thay manifest.json trong file zip!' }; " ^
  "  Get-ChildItem -Path $mf.DirectoryName | Where-Object { $_.Name -ne 'CapNhat_CLS.bat' } | Copy-Item -Destination $target -Recurse -Force; " ^
  "  $newVer = (Get-Content (Join-Path $target 'manifest.json') -Raw -Encoding UTF8 | ConvertFrom-Json).version; " ^
  "  Write-Host ''; " ^
  "  if ($oldVer -and ($oldVer -eq $newVer)) { " ^
  "    Write-Host ('[OK] Da cap nhat lai ban moi nhat (v' + $newVer + ')') -ForegroundColor Green; " ^
  "  } elseif ($oldVer) { " ^
  "    Write-Host ('[OK] Da nang cap thanh cong: v' + $oldVer + ' -> v' + $newVer) -ForegroundColor Green; " ^
  "  } else { " ^
  "    Write-Host ('[OK] Da cap nhat thanh cong len phien ban v' + $newVer) -ForegroundColor Green; " ^
  "  }; " ^
  "  $chrome = @($env:ProgramFiles, ${env:ProgramFiles(x86)}, $env:LOCALAPPDATA) | Where-Object { $_ } | ForEach-Object { Join-Path $_ 'Google\Chrome\Application\chrome.exe' } | Where-Object { Test-Path $_ } | Select-Object -First 1; " ^
  "  if ($chrome) { Start-Process $chrome 'chrome://extensions/' }; " ^
  "} catch { " ^
  "  Write-Host ('[LOI] ' + $_.Exception.Message) -ForegroundColor Red; " ^
  "  exit 1; " ^
  "} finally { " ^
  "  Remove-Item $zip, $tmp -Recurse -Force -ErrorAction SilentlyContinue; " ^
  "}"

if errorlevel 1 (
  echo.
  echo Cap nhat that bai. Kiem tra ket noi mang roi thu lai.
  pause
  exit /b 1
)

echo.
echo Buoc cuoi: Bam nut Tai lai (vong tron) tren the "Tom tat CLS" trong Chrome.
timeout /t 4 >nul